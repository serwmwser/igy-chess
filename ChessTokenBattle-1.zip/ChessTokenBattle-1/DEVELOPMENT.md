# Руководство по разработке IGY Chess

Это руководство поможет вам настроить окружение для разработки приложения IGY Chess.

## Предварительные требования

- Node.js версии 20 или выше
- npm версии 10 или выше
- Git

## Настройка окружения разработки

### 1. Клонирование репозитория

```bash
git clone https://github.com/your-username/igy-chess.git
cd igy-chess
```

### 2. Установка зависимостей

```bash
npm install
```

### 3. Запуск в режиме разработки

```bash
npm run dev
```

Это запустит:
- Клиент на Vite
- Сервер Express
- WebSocket сервер для реального времени

Приложение будет доступно по адресу `http://localhost:5000`.

## Структура проекта

```
.
├── client/                  # Клиентский код (React, TypeScript)
│   ├── src/
│   │   ├── components/      # React компоненты
│   │   ├── context/         # React контекст
│   │   ├── hooks/           # React хуки
│   │   ├── lib/             # Вспомогательные библиотеки
│   │   ├── pages/           # Страницы приложения
│   │   ├── types/           # TypeScript типы
│   │   ├── App.tsx          # Главный компонент приложения
│   │   ├── main.tsx         # Точка входа React
│   │   └── index.css        # Глобальные стили
│   └── index.html           # HTML шаблон
├── server/                  # Серверный код (Node.js, Express)
│   ├── index.ts             # Точка входа сервера
│   ├── routes.ts            # API маршруты
│   ├── storage.ts           # Интерфейс хранилища данных
│   ├── vite.ts              # Интеграция с Vite
│   ├── tournament.ts        # Логика турниров
│   ├── websocket.ts         # Основной WebSocket сервер
│   └── websocket-tournament.ts # WebSocket для турниров
├── shared/                  # Общий код между клиентом и сервером
│   └── schema.ts            # Схемы данных и типы
└── ...                      # Конфигурационные файлы
```

## Основные технологии

### Фронтенд
- React 18
- TypeScript
- TanStack Query для управления состоянием и API-запросами
- Tailwind CSS и Shadcn/UI для стилизации
- Wouter для маршрутизации
- Zod для валидации форм

### Бэкенд
- Node.js с Express
- WebSocket для реального времени
- In-memory хранилище данных (MemStorage)

### Блокчейн интеграция
- Web3Modal
- Ethers.js
- WalletConnect для аутентификации

## Рабочие процессы разработки

### Добавление новой функциональности
1. Определите схему данных в `shared/schema.ts`
2. Обновите интерфейс хранилища (`IStorage`) в `server/storage.ts`
3. Реализуйте функциональность в `MemStorage`
4. Добавьте новые маршруты в `server/routes.ts` если необходимо
5. Реализуйте соответствующие компоненты на фронтенде

### Работа с WebSocket
Для добавления новых типов сообщений WebSocket:
1. Расширьте соответствующий обработчик в `server/websocket.ts` или `server/websocket-tournament.ts`
2. Обновите клиентский код для отправки и получения новых типов сообщений

## Сборка для продакшна

```bash
npm run build
```

Это создаст:
- Клиентские файлы в `dist/public/`
- Серверные файлы в `dist/`

## Дополнительные ресурсы

- [React документация](https://react.dev/)
- [TypeScript документация](https://www.typescriptlang.org/docs/)
- [Express документация](https://expressjs.com/)
- [TanStack Query документация](https://tanstack.com/query/latest)
- [Tailwind CSS документация](https://tailwindcss.com/docs)
- [Shadcn/UI документация](https://ui.shadcn.com/)