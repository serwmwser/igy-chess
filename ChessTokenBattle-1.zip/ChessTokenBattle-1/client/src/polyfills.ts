// Polyfills for Node.js modules used in browser
window.global = window;
window.process = window.process || { env: {} };

// Mock buffer
class BufferMock {
  static from(data: any, encoding?: string) {
    return { data, encoding };
  }
  static isBuffer() { return false; }
  static concat() { return {}; }
}
window.Buffer = BufferMock as any;

// Define a global 'self' reference if needed
if (typeof self === 'undefined') {
  (window as any).self = window;
}

// Mock util module
window.util = {
  inherits: function(ctor: any, superCtor: any) {
    if (superCtor) {
      ctor.super_ = superCtor;
      Object.setPrototypeOf(ctor.prototype, superCtor.prototype);
    }
  },
  debuglog: function() { return function() {}; },
  inspect: function() { return ''; },
};

// Mock stream
window.stream = {
  Transform: class Transform {}
};

// Mock http and https
window.http = { globalAgent: {} };
window.https = { globalAgent: {} };