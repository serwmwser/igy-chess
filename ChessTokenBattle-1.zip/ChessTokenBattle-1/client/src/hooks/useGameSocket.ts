import { useEffect, useState, useRef } from "react";
import { useWallet } from "@/context/WalletContext";

export function useGameSocket() {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const { walletAddress } = useWallet();
  const reconnectAttemptsRef = useRef(0);
  const maxReconnectAttempts = 5;

  useEffect(() => {
    if (!walletAddress) return;

    // Create WebSocket connection
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const ws = new WebSocket(wsUrl);
    
    const handleOpen = () => {
      console.log("WebSocket connected");
      reconnectAttemptsRef.current = 0;
      
      // Send authentication message with wallet address
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'authenticate',
          address: walletAddress
        }));
      }
    };
    
    const handleClose = (event: CloseEvent) => {
      console.log("WebSocket disconnected", event);
      
      // Try to reconnect if not a normal closure
      if (event.code !== 1000 && reconnectAttemptsRef.current < maxReconnectAttempts) {
        reconnectAttemptsRef.current += 1;
        const timeout = Math.min(1000 * 2 ** reconnectAttemptsRef.current, 30000);
        
        console.log(`Attempting to reconnect in ${timeout}ms (attempt ${reconnectAttemptsRef.current})`);
        setTimeout(() => {
          const newWs = new WebSocket(wsUrl);
          setSocket(newWs);
        }, timeout);
      }
    };
    
    const handleError = (error: Event) => {
      console.error("WebSocket error:", error);
    };
    
    ws.addEventListener('open', handleOpen);
    ws.addEventListener('close', handleClose);
    ws.addEventListener('error', handleError);
    
    setSocket(ws);
    
    // Clean up on unmount
    return () => {
      ws.removeEventListener('open', handleOpen);
      ws.removeEventListener('close', handleClose);
      ws.removeEventListener('error', handleError);
      
      if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
        ws.close();
      }
    };
  }, [walletAddress]);

  return socket;
}
