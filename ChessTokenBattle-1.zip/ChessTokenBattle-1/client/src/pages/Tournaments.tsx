import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useWallet } from "@/context/WalletContext";
import { useLanguage } from "@/context/LanguageContext";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { formatTime, formatDate } from "@/lib/utils";
import { FaClock, FaTrophy, FaUsers, FaCoins, FaChessKnight, FaChessBoard, FaCalendarAlt } from "react-icons/fa";
import PuzzleTournament from "@/components/PuzzleTournament";

// Тип для информации о списке турниров
type TournamentSummary = {
  id: string;
  name: string;
  status: "scheduled" | "active" | "completed";
  startTime: number;
  endTime?: number;
  timeLimit: number; // в секундах
  entryFee: number;
  puzzleCount: number;
  participantCount: number;
  prizePool: number;
  winner?: string;
};

// Тип для истории турниров пользователя
type UserTournamentHistory = {
  id: string;
  tournamentId: string;
  tournamentName: string;
  date: number;
  position: number;
  score: number;
  tokensWon: number;
  puzzlesSolved: number;
};

export default function Tournaments() {
  const { t } = useLanguage();
  const { isConnected, walletAddress } = useWallet();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const [activeTournaments, setActiveTournaments] = useState<TournamentSummary[]>([]);
  const [upcomingTournaments, setUpcomingTournaments] = useState<TournamentSummary[]>([]);
  const [completedTournaments, setCompletedTournaments] = useState<TournamentSummary[]>([]);
  const [userHistory, setUserHistory] = useState<UserTournamentHistory[]>([]);
  const [loading, setLoading] = useState(true);
  const [joinedTournamentId, setJoinedTournamentId] = useState<string | null>(null);
  
  // Если не подключен, перенаправить на главную
  useEffect(() => {
    if (!isConnected) {
      navigate("/");
    }
  }, [isConnected, navigate]);
  
  // Загрузка данных о турнирах
  useEffect(() => {
    if (!isConnected || !walletAddress) return;
    
    const fetchTournaments = async () => {
      setLoading(true);
      try {
        // В реальном приложении здесь был бы запрос к API
        // Симуляция загрузки данных
        setTimeout(() => {
          // Пример данных о турнирах
          const mockActiveTournaments: TournamentSummary[] = [
            {
              id: "tour1",
              name: "Скоростные тактики",
              status: "active",
              startTime: Date.now() - 600000, // 10 минут назад
              timeLimit: 1800, // 30 минут
              entryFee: 1,
              puzzleCount: 10,
              participantCount: 12,
              prizePool: 12
            }
          ];
          
          const mockUpcomingTournaments: TournamentSummary[] = [
            {
              id: "tour2",
              name: "Мастера эндшпиля",
              status: "scheduled",
              startTime: Date.now() + 3600000, // через 1 час
              timeLimit: 2700, // 45 минут
              entryFee: 2,
              puzzleCount: 15,
              participantCount: 8,
              prizePool: 16
            },
            {
              id: "tour3",
              name: "Блиц-тактики",
              status: "scheduled",
              startTime: Date.now() + 7200000, // через 2 часа
              timeLimit: 900, // 15 минут
              entryFee: 1,
              puzzleCount: 5,
              participantCount: 24,
              prizePool: 24
            }
          ];
          
          const mockCompletedTournaments: TournamentSummary[] = [
            {
              id: "tour4",
              name: "Дебютные ловушки",
              status: "completed",
              startTime: Date.now() - 86400000, // вчера
              endTime: Date.now() - 84600000,
              timeLimit: 1800,
              entryFee: 1,
              puzzleCount: 10,
              participantCount: 16,
              prizePool: 16,
              winner: "0x742d35Cc6634C0532925a3b844Bc454e4438f44e"
            }
          ];
          
          const mockUserHistory: UserTournamentHistory[] = [
            {
              id: "hist1",
              tournamentId: "tour4",
              tournamentName: "Дебютные ловушки",
              date: Date.now() - 86400000,
              position: 3,
              score: 850,
              tokensWon: 0,
              puzzlesSolved: 8
            }
          ];
          
          setActiveTournaments(mockActiveTournaments);
          setUpcomingTournaments(mockUpcomingTournaments);
          setCompletedTournaments(mockCompletedTournaments);
          setUserHistory(mockUserHistory);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error("Error fetching tournaments:", error);
        toast({
          title: t("errors.error"),
          description: t("errors.failedToLoadTournaments"),
          variant: "destructive"
        });
        setLoading(false);
      }
    };
    
    fetchTournaments();
  }, [isConnected, walletAddress, toast, t]);
  
  // Присоединиться к турниру
  const joinTournament = (tournamentId: string) => {
    setJoinedTournamentId(tournamentId);
  };
  
  // Если не подключен, не показывать страницу
  if (!isConnected) {
    return null;
  }
  
  // Если пользователь уже присоединился к турниру
  if (joinedTournamentId) {
    return (
      <div className="min-h-screen flex flex-col bg-neutral-light font-poppins text-neutral-dark">
        <Header />
        
        <div className="container mx-auto px-4 py-6 flex-grow">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">{t("tournament.puzzleTournament")}</h1>
            <Button 
              variant="outline" 
              onClick={() => setJoinedTournamentId(null)}
            >
              {t("tournament.backToList")}
            </Button>
          </div>
          
          <PuzzleTournament />
        </div>
        
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-neutral-light font-poppins text-neutral-dark">
      <Header />
      
      <div className="container mx-auto px-4 py-6 flex-grow">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2">{t("tournament.tournamentCenter")}</h1>
          <p className="text-gray-600">{t("tournament.description")}</p>
        </div>
        
        <Tabs defaultValue="active">
          <TabsList className="mb-6">
            <TabsTrigger value="active">{t("tournament.active")}</TabsTrigger>
            <TabsTrigger value="upcoming">{t("tournament.upcoming")}</TabsTrigger>
            <TabsTrigger value="completed">{t("tournament.completed")}</TabsTrigger>
            <TabsTrigger value="history">{t("tournament.myHistory")}</TabsTrigger>
          </TabsList>
          
          {/* Активные турниры */}
          <TabsContent value="active">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {loading ? (
                Array(3).fill(0).map((_, i) => (
                  <Card key={i}>
                    <CardHeader>
                      <Skeleton className="h-5 w-[80%] mb-1" />
                      <Skeleton className="h-4 w-[60%]" />
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-[70%]" />
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Skeleton className="h-10 w-full" />
                    </CardFooter>
                  </Card>
                ))
              ) : activeTournaments.length > 0 ? (
                activeTournaments.map(tournament => (
                  <Card key={tournament.id}>
                    <CardHeader>
                      <CardTitle>{tournament.name}</CardTitle>
                      <CardDescription>
                        <div className="flex items-center">
                          <FaChessBoard className="mr-2" />
                          <span>{tournament.puzzleCount} {t("tournament.puzzles")}</span>
                        </div>
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center text-sm">
                            <FaClock className="mr-2 text-gray-600" />
                            <span>{formatTime(tournament.timeLimit)}</span>
                          </div>
                          <div className="flex items-center text-sm">
                            <FaCoins className="mr-2 text-amber-500" />
                            <span>{tournament.entryFee} IGY</span>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <div className="flex items-center text-sm">
                            <FaUsers className="mr-2 text-gray-600" />
                            <span>{tournament.participantCount} {t("tournament.players")}</span>
                          </div>
                          <div className="flex items-center text-sm">
                            <FaTrophy className="mr-2 text-amber-500" />
                            <span>{tournament.prizePool} IGY</span>
                          </div>
                        </div>
                        
                        <div className="bg-green-50 text-green-600 text-sm py-1 px-2 rounded flex items-center mt-2">
                          <FaCalendarAlt className="mr-2" />
                          <span>{t("tournament.inProgress")}</span>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button 
                        className="w-full" 
                        onClick={() => joinTournament(tournament.id)}
                      >
                        {t("tournament.joinNow")}
                      </Button>
                    </CardFooter>
                  </Card>
                ))
              ) : (
                <div className="col-span-3 text-center py-12">
                  <FaChessKnight className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-xl font-semibold mb-2">{t("tournament.noActiveTournaments")}</h3>
                  <p className="text-gray-600">{t("tournament.checkBackLater")}</p>
                </div>
              )}
            </div>
          </TabsContent>
          
          {/* Предстоящие турниры */}
          <TabsContent value="upcoming">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {loading ? (
                Array(3).fill(0).map((_, i) => (
                  <Card key={i}>
                    <CardHeader>
                      <Skeleton className="h-5 w-[80%] mb-1" />
                      <Skeleton className="h-4 w-[60%]" />
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-[70%]" />
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Skeleton className="h-10 w-full" />
                    </CardFooter>
                  </Card>
                ))
              ) : upcomingTournaments.length > 0 ? (
                upcomingTournaments.map(tournament => (
                  <Card key={tournament.id}>
                    <CardHeader>
                      <CardTitle>{tournament.name}</CardTitle>
                      <CardDescription>
                        <div className="flex items-center">
                          <FaChessBoard className="mr-2" />
                          <span>{tournament.puzzleCount} {t("tournament.puzzles")}</span>
                        </div>
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center text-sm">
                            <FaClock className="mr-2 text-gray-600" />
                            <span>{formatTime(tournament.timeLimit)}</span>
                          </div>
                          <div className="flex items-center text-sm">
                            <FaCoins className="mr-2 text-amber-500" />
                            <span>{tournament.entryFee} IGY</span>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <div className="flex items-center text-sm">
                            <FaUsers className="mr-2 text-gray-600" />
                            <span>{tournament.participantCount} {t("tournament.players")}</span>
                          </div>
                          <div className="flex items-center text-sm">
                            <FaTrophy className="mr-2 text-amber-500" />
                            <span>{tournament.prizePool} IGY</span>
                          </div>
                        </div>
                        
                        <div className="bg-blue-50 text-blue-600 text-sm py-1 px-2 rounded flex items-center mt-2">
                          <FaCalendarAlt className="mr-2" />
                          <span>{formatDate(new Date(tournament.startTime))}</span>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button 
                        variant="outline"
                        className="w-full"
                        disabled
                      >
                        {t("tournament.opensLater")}
                      </Button>
                    </CardFooter>
                  </Card>
                ))
              ) : (
                <div className="col-span-3 text-center py-12">
                  <FaChessKnight className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-xl font-semibold mb-2">{t("tournament.noUpcomingTournaments")}</h3>
                  <p className="text-gray-600">{t("tournament.checkBackLater")}</p>
                </div>
              )}
            </div>
          </TabsContent>
          
          {/* Завершенные турниры */}
          <TabsContent value="completed">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {loading ? (
                Array(3).fill(0).map((_, i) => (
                  <Card key={i}>
                    <CardHeader>
                      <Skeleton className="h-5 w-[80%] mb-1" />
                      <Skeleton className="h-4 w-[60%]" />
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-[70%]" />
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : completedTournaments.length > 0 ? (
                completedTournaments.map(tournament => (
                  <Card key={tournament.id}>
                    <CardHeader>
                      <CardTitle>{tournament.name}</CardTitle>
                      <CardDescription>
                        <div className="flex items-center">
                          <FaChessBoard className="mr-2" />
                          <span>{tournament.puzzleCount} {t("tournament.puzzles")}</span>
                        </div>
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center text-sm">
                            <FaClock className="mr-2 text-gray-600" />
                            <span>{formatTime(tournament.timeLimit)}</span>
                          </div>
                          <div className="flex items-center text-sm">
                            <FaCoins className="mr-2 text-amber-500" />
                            <span>{tournament.entryFee} IGY</span>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <div className="flex items-center text-sm">
                            <FaUsers className="mr-2 text-gray-600" />
                            <span>{tournament.participantCount} {t("tournament.players")}</span>
                          </div>
                          <div className="flex items-center text-sm">
                            <FaTrophy className="mr-2 text-amber-500" />
                            <span>{tournament.prizePool} IGY</span>
                          </div>
                        </div>
                        
                        <div className="bg-gray-50 text-gray-600 text-sm py-1 px-2 rounded flex items-center mt-2">
                          <FaCalendarAlt className="mr-2" />
                          <span>{formatDate(new Date(tournament.startTime))}</span>
                        </div>
                        
                        {tournament.winner && (
                          <div className="bg-amber-50 text-amber-700 text-sm py-1 px-2 rounded flex items-center">
                            <FaTrophy className="mr-2" />
                            <span>{t("tournament.winner")}: {tournament.winner.substring(0, 6)}...{tournament.winner.substring(tournament.winner.length - 4)}</span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="col-span-3 text-center py-12">
                  <FaChessKnight className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-xl font-semibold mb-2">{t("tournament.noCompletedTournaments")}</h3>
                  <p className="text-gray-600">{t("tournament.checkBackLater")}</p>
                </div>
              )}
            </div>
          </TabsContent>
          
          {/* История пользователя */}
          <TabsContent value="history">
            {loading ? (
              <div className="space-y-4">
                {Array(2).fill(0).map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow p-4">
                    <Skeleton className="h-6 w-[60%] mb-3" />
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                    </div>
                  </div>
                ))}
              </div>
            ) : userHistory.length > 0 ? (
              <div className="space-y-4">
                {userHistory.map(history => (
                  <div key={history.id} className="bg-white rounded-lg shadow p-4">
                    <h3 className="text-lg font-semibold mb-2">{history.tournamentName}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">{t("tournament.date")}</p>
                        <p className="font-medium">{formatDate(new Date(history.date))}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">{t("tournament.position")}</p>
                        <p className="font-medium">{history.position} {t("tournament.outOf")} {/* участники */}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">{t("tournament.score")}</p>
                        <p className="font-medium">{history.score} {t("tournament.points")}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">{t("tournament.puzzlesSolved")}</p>
                        <p className="font-medium">{history.puzzlesSolved}</p>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-gray-200">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center text-sm">
                          <FaCoins className="mr-2 text-amber-500" />
                          <span>{t("tournament.tokensWon")}: {history.tokensWon} IGY</span>
                        </div>
                        <Button variant="link" size="sm">
                          {t("tournament.viewDetails")}
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <FaChessKnight className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{t("tournament.noHistory")}</h3>
                <p className="text-gray-600">{t("tournament.joinToSee")}</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
      
      <Footer />
    </div>
  );
}