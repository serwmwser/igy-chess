import WalletConnect from "@/components/WalletConnect";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { useWallet } from "@/context/WalletContext";
import { useEffect } from "react";
import { useLocation } from "wouter";
import { Trophy, Sparkles, Clock, Users, Coins, Globe } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

export default function Home() {
  const { isConnected } = useWallet();
  const [, navigate] = useLocation();
  const { t } = useLanguage();
  
  // If already connected, redirect to dashboard
  useEffect(() => {
    if (isConnected) {
      navigate("/dashboard");
    }
  }, [isConnected, navigate]);

  const features = [
    {
      icon: <Trophy className="h-10 w-10 text-purple-500" />,
      title: t("home.feature1.title", "Compete Globally"),
      description: t("home.feature1.description", "Challenge players from around the world and climb the global leaderboard.")
    },
    {
      icon: <Coins className="h-10 w-10 text-amber-500" />,
      title: t("home.feature2.title", "Earn IGY Tokens"),
      description: t("home.feature2.description", "Win matches to earn valuable IGY tokens with real-world value on the Polygon network.")
    },
    {
      icon: <Sparkles className="h-10 w-10 text-blue-500" />,
      title: t("home.feature3.title", "Customize Your Experience"),
      description: t("home.feature3.description", "Unlock premium chess pieces and board themes to personalize your gameplay.")
    },
    {
      icon: <Clock className="h-10 w-10 text-green-500" />,
      title: t("home.feature4.title", "Flexible Time Controls"),
      description: t("home.feature4.description", "Play at your own pace with multiple time control options from blitz to unlimited.")
    },
    {
      icon: <Users className="h-10 w-10 text-pink-500" />,
      title: t("home.feature5.title", "Video Chat"),
      description: t("home.feature5.description", "See and talk to your opponent in real-time while playing for a more immersive experience.")
    },
    {
      icon: <Globe className="h-10 w-10 text-indigo-500" />,
      title: t("home.feature6.title", "Multilingual Support"),
      description: t("home.feature6.description", "Enjoy our platform in your preferred language with support for multiple languages.")
    }
  ];

  return (
    <div className="min-h-screen flex flex-col font-poppins text-neutral-dark">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="py-10 md:py-16">
          <div className="container px-4 mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div className="order-2 md:order-1">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6">
                  {t("home.hero.title", "Play Chess, Earn Crypto")}
                </h1>
                <p className="text-lg md:text-xl mb-8 text-gray-700 max-w-lg">
                  {t("home.hero.subtitle", "The next generation chess platform where skill meets blockchain technology. Connect your wallet to start playing and earning today.")}
                </p>
                <div className="mb-8">
                  <WalletConnect />
                </div>
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <div className="flex items-center">
                    <Trophy className="h-4 w-4 mr-1 text-purple-500" />
                    <span>{t("home.stats.players", "10,000+ Players")}</span>
                  </div>
                  <div className="flex items-center">
                    <Coins className="h-4 w-4 mr-1 text-amber-500" />
                    <span>{t("home.stats.tokens", "100,000+ IGY Tokens")}</span>
                  </div>
                </div>
              </div>
              
              <div className="order-1 md:order-2 relative">
                <div className="rounded-lg overflow-hidden shadow-xl bg-white p-4 border border-gray-100 relative z-10">
                  <div className="aspect-w-1 aspect-h-1 bg-gray-100 rounded-md">
                    <div className="p-2 grid grid-cols-8 grid-rows-8 gap-0">
                      {Array.from({ length: 64 }).map((_, index) => {
                        const row = Math.floor(index / 8);
                        const col = index % 8;
                        const isBlack = (row + col) % 2 === 1;
                        return (
                          <div 
                            key={index} 
                            className={`${isBlack ? 'bg-primary/80' : 'bg-primary/20'} aspect-w-1 aspect-h-1`}
                          />
                        );
                      })}
                    </div>
                  </div>
                </div>
                <div className="absolute -top-6 -right-6 w-32 h-32 bg-blue-100 rounded-full opacity-70 z-0 blur-xl"></div>
                <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-purple-100 rounded-full opacity-70 z-0 blur-xl"></div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Features Section */}
        <section className="py-12 bg-gray-50">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold game-section-header mb-4">
                {t("home.features.title", "Why Choose IGY Chess")}
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                {t("home.features.subtitle", "Experience the future of chess with these innovative features")}
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <div key={index} className="card card-gradient p-6">
                  <div className="mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
        
        {/* Mini Games Section */}
        <section className="py-12 bg-gradient-to-br from-amber-50 to-yellow-50">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-amber-600 to-yellow-500">
                {t("home.minigames.title", "Play Mini Games & Earn IGY Tokens")}
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                {t("home.minigames.description", "Take a break from chess and try our mini games. Reach high scores to earn IGY tokens that you can use in your chess matches!")}
              </p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
              <div className="order-2 lg:order-1">
                <div className="bg-gradient-to-r from-amber-500 to-yellow-500 text-white p-6 rounded-xl shadow-xl">
                  <h3 className="text-2xl font-bold mb-4">2048</h3>
                  <div className="space-y-4">
                    <p>
                      {t("home.minigames.2048.description", "Combine the numbers to reach the 2048 tile! This addictive puzzle game is now available on our platform with a twist - when you reach 2048, you earn IGY tokens!")}
                    </p>
                    <div className="bg-white bg-opacity-20 p-4 rounded-lg">
                      <div className="flex items-center mb-2">
                        <Trophy className="h-5 w-5 mr-2 text-yellow-200" />
                        <span className="font-medium">
                          {t("home.minigames.2048.reward", "Reward: 5 IGY tokens for reaching 2048")}
                        </span>
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-5 w-5 mr-2 text-yellow-200" />
                        <span className="font-medium">
                          {t("home.minigames.2048.time", "Average time: 10-15 minutes")}
                        </span>
                      </div>
                    </div>
                    {!isConnected && (
                      <p className="text-yellow-100 italic">
                        {t("home.minigames.connectToPlay", "Connect your wallet to play mini games and earn tokens")}
                      </p>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="order-1 lg:order-2">
                <div className="bg-white p-3 rounded-xl shadow-xl border-4 border-amber-400">
                  <div className="grid grid-cols-4 gap-3 aspect-square">
                    {[2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 0, 0, 0, 0, 0].map((value, index) => {
                      let bgColor = 'bg-gray-200';
                      let textColor = 'text-gray-800';
                      let fontSize = 'text-2xl';
                      
                      if (value === 2) bgColor = 'bg-amber-100';
                      else if (value === 4) bgColor = 'bg-amber-200';
                      else if (value === 8) bgColor = 'bg-orange-300';
                      else if (value === 16) bgColor = 'bg-orange-400';
                      else if (value === 32) bgColor = 'bg-orange-500';
                      else if (value === 64) bgColor = 'bg-orange-600';
                      else if (value === 128) bgColor = 'bg-yellow-300';
                      else if (value === 256) bgColor = 'bg-yellow-400';
                      else if (value === 512) bgColor = 'bg-yellow-500';
                      else if (value === 1024) {
                        bgColor = 'bg-yellow-600';
                        fontSize = 'text-xl';
                      }
                      else if (value === 2048) {
                        bgColor = 'bg-yellow-700';
                        fontSize = 'text-xl';
                      }

                      if (value >= 8) textColor = 'text-white';
                      
                      return (
                        <div 
                          key={index}
                          className={`${bgColor} ${textColor} rounded-md flex items-center justify-center font-bold ${fontSize} shadow-md`}
                        >
                          {value !== 0 ? value : ''}
                        </div>
                      );
                    })}
                  </div>
                  <div className="mt-4 flex justify-center">
                    <div className="text-center text-sm text-gray-500">
                      {t("home.minigames.2048.instructions", "Use arrow keys or swipe to merge tiles with the same number")}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-10 text-center">
              <p className="font-medium text-lg text-amber-700 mb-2">
                {t("home.minigames.comingSoon", "More mini games coming soon!")}
              </p>
              <p className="text-gray-600">
                {t("home.minigames.futurePlans", "We're working on adding more fun mini games where you can earn IGY tokens, including puzzle chess, memory games, and more.")}
              </p>
            </div>
          </div>
        </section>
        
        {/* Token Section */}
        <section className="py-12 bg-gradient-to-br from-indigo-50 to-purple-50">
          <div className="container px-4 mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-500">
                {t("home.token.title", "IGY Token Economy")}
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                {t("home.token.description", "The IGY token powers the entire ecosystem, enabling players to stake on games, purchase custom themes, and earn rewards.")}
              </p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Token Logo and Details Card */}
              <div className="bg-white rounded-xl shadow-xl overflow-hidden transform hover:scale-105 transition-transform duration-300">
                <div className="flex justify-center p-6 bg-gradient-to-r from-indigo-900 to-purple-900">
                  <img src="/token-logo.svg" alt="IGY Token" className="h-40" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{t("home.token.aboutToken", "About IGY Token")}</h3>
                  <p className="text-gray-600 mb-4">
                    {t("home.token.tokenDescription", "IGY is a utility token built on the Polygon blockchain that powers the IGY Chess platform.")}
                  </p>
                  <div className="flex items-center text-sm font-mono bg-gray-100 rounded p-2 mb-4 overflow-hidden">
                    <span className="truncate">0x6d278Ec8Bb6FC8d06c081e4688759546CC73eaB8</span>
                  </div>
                  <div className="border-t border-gray-100 pt-4">
                    <div className="flex items-center mb-2">
                      <div className="w-5 h-5 bg-green-500 rounded-full mr-2"></div>
                      <span className="text-sm text-gray-600">{t("home.token.walletVisibility", "Visible in crypto wallets")}</span>
                    </div>
                    <div className="flex items-center">
                      <div className="w-5 h-5 bg-blue-500 rounded-full mr-2"></div>
                      <span className="text-sm text-gray-600">{t("home.token.polygonscanVisibility", "Verified on Polygonscan")}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Token Use Cases */}
              <div className="bg-white rounded-xl shadow-xl overflow-hidden lg:col-span-2">
                <div className="p-6 border-b border-gray-100">
                  <h3 className="text-xl font-bold mb-2">{t("home.token.useCases", "Token Use Cases")}</h3>
                  <p className="text-gray-600">
                    {t("home.token.useCasesDescription", "IGY token has multiple utilities within our ecosystem:")}
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-gray-100">
                  <div className="p-6">
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <Coins className="h-5 w-5 text-purple-500 mr-2 mt-0.5" />
                        <span>{t("home.token.useCase1", "Stake in chess games")}</span>
                      </li>
                      <li className="flex items-start">
                        <Trophy className="h-5 w-5 text-purple-500 mr-2 mt-0.5" />
                        <span>{t("home.token.useCase2", "Enter tournaments")}</span>
                      </li>
                      <li className="flex items-start">
                        <Sparkles className="h-5 w-5 text-purple-500 mr-2 mt-0.5" />
                        <span>{t("home.token.useCase3", "Purchase premium themes")}</span>
                      </li>
                    </ul>
                  </div>
                  <div className="p-6">
                    <div className="space-y-4">
                      <div>
                        <div className="font-semibold mb-1">{t("home.token.supply", "Total Supply")}</div>
                        <div className="text-2xl font-bold text-amber-500">10,000,000 IGY</div>
                      </div>
                      <div>
                        <div className="font-semibold mb-1">{t("home.token.circulation", "Tokens in Circulation")}</div>
                        <div className="text-2xl font-bold text-blue-500">2,500,000 IGY</div>
                        <div className="text-xs text-gray-500 mt-1">25% of total supply</div>
                      </div>
                      <div>
                        <div className="font-semibold mb-1">{t("home.token.ratio", "Exchange Ratio")}</div>
                        <div className="text-2xl font-bold text-amber-500">1 IGY = 1 POL</div>
                      </div>
                      <div>
                        <div className="font-semibold mb-1">{t("home.token.listing", "Exchange Listing")}</div>
                        <div className="text-2xl font-bold text-amber-500">2025/2026</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Token Roadmap */}
              <div className="bg-white rounded-xl shadow-xl overflow-hidden lg:col-span-3">
                <div className="p-6 border-b border-gray-100">
                  <h3 className="text-xl font-bold mb-2">{t("home.token.roadmap", "Token Roadmap")}</h3>
                </div>
                
                <div className="p-6 overflow-x-auto">
                  <div className="flex min-w-max">
                    <div className="px-6 text-center">
                      <div className="w-10 h-10 rounded-full bg-green-100 text-green-600 flex items-center justify-center mx-auto mb-2">1</div>
                      <div className="font-medium">{t("home.token.phase1", "Platform Launch")}</div>
                      <div className="text-sm text-gray-500">2023 Q4</div>
                    </div>
                    <div className="flex-1 pt-5">
                      <div className="h-0.5 bg-gray-200 relative">
                        <div className="absolute w-1/4 h-0.5 bg-green-500"></div>
                      </div>
                    </div>
                    <div className="px-6 text-center">
                      <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto mb-2">2</div>
                      <div className="font-medium">{t("home.token.phase2", "Community Growth")}</div>
                      <div className="text-sm text-gray-500">2024 Q2</div>
                    </div>
                    <div className="flex-1 pt-5">
                      <div className="h-0.5 bg-gray-200"></div>
                    </div>
                    <div className="px-6 text-center">
                      <div className="w-10 h-10 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center mx-auto mb-2">3</div>
                      <div className="font-medium">{t("home.token.phase3", "100,000 Users")}</div>
                      <div className="text-sm text-gray-500">2025 Q3</div>
                    </div>
                    <div className="flex-1 pt-5">
                      <div className="h-0.5 bg-gray-200"></div>
                    </div>
                    <div className="px-6 text-center">
                      <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto mb-2">4</div>
                      <div className="font-medium">{t("home.token.phase4", "Exchange Listing")}</div>
                      <div className="text-sm text-gray-500">2025/2026</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
