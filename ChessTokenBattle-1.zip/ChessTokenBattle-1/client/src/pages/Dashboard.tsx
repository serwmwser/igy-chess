import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import UserProfile from "@/components/UserProfile";
import ChessBoard from "@/components/ChessBoard";
import GameChat from "@/components/GameChat";
import GameInfo from "@/components/GameInfo";
import Leaderboard from "@/components/Leaderboard";
import GameControls from "@/components/GameControls";
import VideoChat from "@/components/VideoChat";
import TokenInfo from "@/components/TokenInfo";
import StartGameModal from "@/components/modals/StartGameModal";
import Game2048 from "@/components/Game2048";
import { useWallet } from "@/context/WalletContext";
import { useGame } from "@/context/GameContext";
import { Button } from "@/components/ui/button";
import { FaPlay, FaDice } from "react-icons/fa";
import { useLanguage } from "@/context/LanguageContext";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function Dashboard() {
  const { isConnected } = useWallet();
  const { gameState } = useGame();
  const { t } = useLanguage();
  const [, navigate] = useLocation();
  const [showStartGameModal, setShowStartGameModal] = useState(false);
  
  // If not connected, redirect to home
  useEffect(() => {
    if (!isConnected) {
      navigate("/");
    }
  }, [isConnected, navigate]);

  if (!isConnected) {
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col bg-neutral-light font-poppins text-neutral-dark">
      <Header />
      
      <div className="container mx-auto px-4 py-6 flex-grow">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Sidebar - User Profile */}
          <UserProfile />
          
          {/* Main Content - Game Area */}
          <div className="lg:col-span-6">
            {gameState ? (
              <>
                <ChessBoard />
                <GameControls />
                <GameChat />
              </>
            ) : (
              <div className="bg-white rounded-lg shadow-md p-6">
                <Tabs defaultValue="chess">
                  <TabsList className="grid w-full grid-cols-2 mb-6">
                    <TabsTrigger value="chess" className="flex items-center justify-center">
                      <FaPlay className="mr-2" />
                      {t("dashboard.chessTab", "Шахматы")}
                    </TabsTrigger>
                    <TabsTrigger value="minigames" className="flex items-center justify-center">
                      <FaDice className="mr-2" />
                      {t("dashboard.minigamesTab", "Мини-игры")}
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="chess" className="mt-0">
                    <div className="flex flex-col items-center justify-center text-center p-4">
                      <h2 className="text-2xl font-montserrat font-bold mb-4">{t("dashboard.noActiveGame")}</h2>
                      <p className="text-gray-600 mb-6">{t("dashboard.startGameDesc")}</p>
                      <Button 
                        size="lg" 
                        className="bg-accent hover:bg-accent/90"
                        onClick={() => setShowStartGameModal(true)}
                      >
                        <FaPlay className="mr-2" />
                        {t("dashboard.startNewGame")}
                      </Button>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="minigames" className="mt-0">
                    <div className="p-2">
                      <Game2048 />
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            )}
          </div>
          
          {/* Right Sidebar - Game Info & Leaderboard */}
          <div className="lg:col-span-3">
            {gameState ? (
              <GameInfo />
            ) : (
              <div className="bg-white rounded-lg shadow-md p-4 mb-6">
                <h3 className="font-montserrat font-semibold mb-3">{t("dashboard.gameInfo")}</h3>
                <p className="text-gray-500 text-sm">{t("dashboard.noActiveGameInfo")}</p>
                <Button 
                  className="w-full mt-4"
                  onClick={() => setShowStartGameModal(true)}
                >
                  {t("dashboard.startGame")}
                </Button>
              </div>
            )}
            
            <TokenInfo />
            
            <Leaderboard />
          </div>
        </div>
      </div>
      
      <Footer />
      
      {/* Start Game Modal */}
      <StartGameModal 
        isOpen={showStartGameModal} 
        onClose={() => setShowStartGameModal(false)} 
      />
      
      {/* Video Chat (will only show if game has videoEnabled=true) */}
      {gameState && <VideoChat />}
    </div>
  );
}
