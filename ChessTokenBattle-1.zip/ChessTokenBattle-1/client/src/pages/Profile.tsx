import { useEffect, useState } from 'react';
import { useWallet } from '@/context/WalletContext';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { CoinsIcon, TrophyIcon, UserIcon, XIcon, CheckIcon } from 'lucide-react';
import DailyTasks from '@/components/DailyTasks';
import ThemeSelector from '@/components/ThemeSelector';
import TokenBalance from '@/components/TokenBalance';
import TokenRoadmap from '@/components/TokenRoadmap';
import { useIsMobile } from '@/hooks/use-mobile';
import { useLanguage } from '@/context/LanguageContext';

type UserProfile = {
  id: number;
  walletAddress: string;
  username: string | null;
  wins: number;
  losses: number;
  draws: number;
  igyBalance: number;
  preferences?: {
    boardTheme: string;
    pieceTheme: string;
    soundEnabled: boolean;
  };
};

export default function Profile() {
  const { walletAddress, igyBalance } = useWallet();
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const { t } = useLanguage();
  
  const [isLoading, setIsLoading] = useState(false);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [username, setUsername] = useState('');
  const [saving, setSaving] = useState(false);

  // Fetch user profile
  useEffect(() => {
    const fetchProfile = async () => {
      if (!walletAddress) return;
      
      setIsLoading(true);
      try {
        const userData = await apiRequest<UserProfile>(`/api/users/${walletAddress}`);
        setUser(userData);
        setUsername(userData.username || '');
      } catch (error) {
        console.error('Error fetching profile:', error);
        toast({
          title: 'Error',
          description: 'Failed to load user profile. Please try again.',
          variant: 'destructive'
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchProfile();
  }, [walletAddress, toast]);

  // Update username
  const updateUsername = async () => {
    if (!walletAddress || !username.trim()) return;
    
    setSaving(true);
    try {
      // This would be an API call to update the username
      /*
      await apiRequest(`/api/users/${walletAddress}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username })
      });
      */
      
      setUser(prev => prev ? { ...prev, username } : null);
      
      toast({
        title: 'Profile Updated',
        description: 'Your username has been updated successfully.',
        variant: 'default'
      });
    } catch (error) {
      console.error('Error updating profile:', error);
      toast({
        title: 'Update Failed',
        description: 'Failed to update username. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  // Calculate win rate
  const calculateWinRate = () => {
    if (!user) return 0;
    const totalGames = user.wins + user.losses + user.draws;
    if (totalGames === 0) return 0;
    return Math.round((user.wins / totalGames) * 100);
  };

  if (!walletAddress) {
    return (
      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>User Profile</CardTitle>
              <CardDescription>Connect your wallet to view your profile</CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="max-w-4xl mx-auto">
        {isLoading ? (
          <div className="py-20 text-center">Loading profile...</div>
        ) : (
          <>
            <div className="mb-8">
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-4">
                    <Avatar className="h-20 w-20 border-2 border-primary">
                      <AvatarFallback className="text-2xl">
                        <UserIcon className="h-8 w-8" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-2xl">{user?.username || 'Anonymous Player'}</CardTitle>
                      <CardDescription className="mt-1">
                        {walletAddress.slice(0, 6)}...{walletAddress.slice(-4)}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card>
                        <CardHeader className="py-2">
                          <CardTitle className="text-sm text-muted-foreground">IGY Balance</CardTitle>
                        </CardHeader>
                        <CardContent className="py-2">
                          <div className="flex items-center">
                            <CoinsIcon className="h-5 w-5 mr-2 text-amber-500" />
                            <span className="text-2xl font-bold">{igyBalance}</span>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="py-2">
                          <CardTitle className="text-sm text-muted-foreground">Win Rate</CardTitle>
                        </CardHeader>
                        <CardContent className="py-2">
                          <div className="flex items-center">
                            <TrophyIcon className="h-5 w-5 mr-2 text-yellow-500" />
                            <span className="text-2xl font-bold">{calculateWinRate()}%</span>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="py-2">
                          <CardTitle className="text-sm text-muted-foreground">Record</CardTitle>
                        </CardHeader>
                        <CardContent className="py-2">
                          <div className="flex items-center justify-between">
                            <div className="flex flex-col items-center">
                              <span className="text-xl font-bold text-green-600">{user?.wins || 0}</span>
                              <span className="text-xs">Win</span>
                            </div>
                            <div className="flex flex-col items-center">
                              <span className="text-xl font-bold text-red-600">{user?.losses || 0}</span>
                              <span className="text-xs">Loss</span>
                            </div>
                            <div className="flex flex-col items-center">
                              <span className="text-xl font-bold text-amber-600">{user?.draws || 0}</span>
                              <span className="text-xs">Draw</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-medium mb-2">User Information</h3>
                      <div className="grid grid-cols-1 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="username">Username</Label>
                          <div className="flex gap-2">
                            <Input
                              id="username"
                              placeholder="Enter username"
                              value={username}
                              onChange={(e) => setUsername(e.target.value)}
                            />
                            <Button onClick={updateUsername} disabled={saving}>
                              {saving ? "Saving..." : "Save"}
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Tabs defaultValue="tasks">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="tasks">{t("profile.tabs.dailyTasks") || "Задания"}</TabsTrigger>
                <TabsTrigger value="tokens">{t("profile.tabs.tokens") || "Токены"}</TabsTrigger>
                <TabsTrigger value="roadmap">{t("profile.tabs.roadmap") || "Дорожная карта"}</TabsTrigger>
                <TabsTrigger value="themes">{t("profile.tabs.themes") || "Темы"}</TabsTrigger>
              </TabsList>
              
              <TabsContent value="tasks" className="mt-4">
                <DailyTasks />
              </TabsContent>
              
              <TabsContent value="tokens" className="mt-4">
                <TokenBalance />
              </TabsContent>
              
              <TabsContent value="roadmap" className="mt-4">
                <TokenRoadmap />
              </TabsContent>
              
              <TabsContent value="themes" className="mt-4">
                <ThemeSelector />
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </div>
  );
}