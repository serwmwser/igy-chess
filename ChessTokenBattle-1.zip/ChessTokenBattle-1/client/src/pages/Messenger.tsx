import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  MessageSquare, 
  Users, 
  UserPlus, 
  Send, 
  PaperclipIcon, 
  Camera, 
  Smile, 
  Heart,
  Search
} from "lucide-react";
import { useLocalStorage } from "../hooks/use-local-storage";
import { useAuth } from "../context/AuthContext";

export default function Messenger() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { isAuthenticated, walletAddress } = useAuth();
  const [activeConversation, setActiveConversation] = useState<string | null>(null);
  const [messageText, setMessageText] = useState("");
  const [fileToUpload, setFileToUpload] = useState<File | null>(null);
  const [registeringProfile, setRegisteringProfile] = useState(false);
  const [profileName, setProfileName] = useState("");
  const [registrationDone, setRegistrationDone] = useLocalStorage("messenger-registration-done", false);
  const [payingTokens, setPayingTokens] = useState(false);
  const [showDatingFeatures, setShowDatingFeatures] = useState(false);

  // Query to get the user's messenger profile
  // Query to get the user's data, including messenger access information
  const { data: userData, isLoading: userDataLoading } = useQuery({
    queryKey: ['/api/user/details'],
    enabled: isAuthenticated && walletAddress !== null,
  });

  // Query to get the user's messenger profile
  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ['/api/messenger/profile'],
    enabled: isAuthenticated && walletAddress !== null && userData?.hasMessengerAccess,
  });

  // Query to get conversations
  const { data: conversations, isLoading: conversationsLoading } = useQuery({
    queryKey: ['/api/messenger/conversations'],
    enabled: isAuthenticated && walletAddress !== null && profile !== undefined,
  });

  // Query to get the active conversation messages
  const { data: messages, isLoading: messagesLoading } = useQuery({
    queryKey: ['/api/messenger/messages', activeConversation],
    enabled: isAuthenticated && walletAddress !== null && activeConversation !== null,
  });

  // Query to get the user's friends
  const { data: friends, isLoading: friendsLoading } = useQuery({
    queryKey: ['/api/messenger/friends'],
    enabled: isAuthenticated && walletAddress !== null && profile !== undefined,
  });

  // Function to pay one token for messenger access
  const payForMessengerAccess = async () => {
    try {
      setPayingTokens(true);
      
      // Make API call to deduct 1 token from user balance
      const response = await fetch('/api/messenger/pay-for-access', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ walletAddress }),
      });
      
      if (!response.ok) {
        throw new Error(t("messenger.errors.insufficientTokens"));
      }
      
      // Invalidate user data query to refresh access status
      window.location.reload(); // For now we'll just reload the page
      
      toast({
        title: t("messenger.accessGranted"),
        description: t("messenger.accessGrantedDesc"),
      });
    } catch (error) {
      toast({
        title: t("messenger.errors.paymentFailed"),
        description: String(error),
        variant: "destructive",
      });
    } finally {
      setPayingTokens(false);
    }
  };

  // Function to register a messenger profile
  const registerProfile = async () => {
    if (!profileName.trim()) {
      toast({
        title: t("messenger.errors.nameRequired"),
        description: t("messenger.errors.pleaseEnterName"),
        variant: "destructive",
      });
      return;
    }

    try {
      setRegisteringProfile(true);
      
      // In real implementation, this would call the API to register a profile
      const response = await fetch('/api/messenger/create-profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          displayName: profileName,
          userId: userData?.id, 
        }),
      });
      
      if (!response.ok) {
        throw new Error(await response.text());
      }
      
      setRegistrationDone(true);
      toast({
        title: t("messenger.profileCreated"),
        description: t("messenger.profileCreatedDesc"),
      });
    } catch (error) {
      toast({
        title: t("messenger.errors.profileCreationFailed"),
        description: String(error),
        variant: "destructive",
      });
    } finally {
      setRegisteringProfile(false);
    }
  };

  // Function to send a message
  const sendMessage = async () => {
    if (!messageText.trim() && !fileToUpload) {
      return;
    }

    try {
      // In real implementation, this would call the API to send a message
      // But for now, we'll just simulate it with a delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setMessageText("");
      setFileToUpload(null);
      
      toast({
        title: t("messenger.messageSent"),
      });
    } catch (error) {
      toast({
        title: t("messenger.errors.messageFailed"),
        description: String(error),
        variant: "destructive",
      });
    }
  };

  // Handle file selection
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFileToUpload(e.target.files[0]);
    }
  };

  useEffect(() => {
    // Scroll to bottom of messages when new messages arrive
    const messagesContainer = document.getElementById("messages-container");
    if (messagesContainer) {
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
  }, [messages]);

  // If not authenticated, show login message
  if (!isAuthenticated) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="w-full max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              {t("messenger.title")} CHESS_GO
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p>{t("messenger.pleaseConnectWallet")}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // If user data is loading, show loading state
  if (userDataLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="w-full max-w-3xl mx-auto">
          <CardContent className="text-center py-8">
            {t("common.loading")}
          </CardContent>
        </Card>
      </div>
    );
  }

  // If user doesn't have messenger access yet, show access options
  if (!userData?.hasMessengerAccess) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="w-full max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              {t("messenger.accessTitle")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="text-center">
                <p className="mb-2">{t("messenger.accessDescription")}</p>
                <p className="text-sm text-muted-foreground mb-4">{t("messenger.dataPolicy")}</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Option 1: Invite friends */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <UserPlus className="h-5 w-5 mr-2" />
                      {t("messenger.inviteFriends")}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm mb-4">{t("messenger.inviteFriendsDesc")}</p>
                    <div className="bg-secondary/50 p-2 rounded-lg mb-4">
                      <div className="flex justify-between items-center">
                        <span>{t("messenger.invitesProgress")}</span>
                        <span className="font-medium">{userData?.paidInvites || 0}/3</span>
                      </div>
                      <div className="w-full bg-secondary mt-2 rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full" 
                          style={{ width: `${Math.min(100, ((userData?.paidInvites || 0) / 3) * 100)}%` }} 
                        />
                      </div>
                    </div>
                    <Button variant="outline" className="w-full" disabled={!isAuthenticated}>
                      {t("messenger.copyInviteLink")}
                    </Button>
                  </CardContent>
                </Card>
                
                {/* Option 2: Pay tokens */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <MessageSquare className="h-5 w-5 mr-2" />
                      {t("messenger.payForAccess")}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm mb-4">{t("messenger.payForAccessDesc")}</p>
                    <div className="bg-secondary/50 p-2 rounded-lg mb-4">
                      <p className="text-center font-medium">1 IGY Token</p>
                    </div>
                    <Button 
                      variant="default" 
                      className="w-full" 
                      onClick={payForMessengerAccess}
                      disabled={payingTokens}
                    >
                      {payingTokens ? t("common.loading") : t("messenger.payNow")}
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // If profile registration needed
  if (!profile && !registrationDone) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="w-full max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              {t("messenger.registerProfile")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-center">{t("messenger.registrationDesc")}</p>
              <p className="text-center text-sm text-muted-foreground">{t("messenger.dataPolicy")}</p>
              <p className="text-center text-sm font-medium text-primary">{t("messenger.registrationFee")}</p>
              
              <div className="flex flex-col space-y-2">
                <label htmlFor="displayName">{t("messenger.displayName")}</label>
                <Input 
                  id="displayName" 
                  value={profileName} 
                  onChange={(e) => setProfileName(e.target.value)}
                  placeholder={t("messenger.displayNamePlaceholder")}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full" 
              onClick={registerProfile} 
              disabled={registeringProfile}
            >
              {registeringProfile ? t("common.loading") : t("messenger.createProfile")}
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  // Loading state
  if (profileLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="w-full max-w-3xl mx-auto">
          <CardContent className="text-center py-8">
            {t("common.loading")}
          </CardContent>
        </Card>
      </div>
    );
  }

  // Main messenger interface
  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="w-full max-w-6xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent flex items-center">
            <MessageSquare className="mr-2 h-6 w-6" />
            {t("messenger.title")} CHESS_GO
          </CardTitle>
          <p className="text-sm text-muted-foreground">{t("messenger.dataPolicy")}</p>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="conversations">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="conversations" className="flex items-center">
                <MessageSquare className="mr-2 h-4 w-4" />
                {t("messenger.conversations")}
              </TabsTrigger>
              <TabsTrigger value="contacts" className="flex items-center">
                <Users className="mr-2 h-4 w-4" />
                {t("messenger.contacts")}
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="conversations" className="mt-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Conversations List */}
                <div className="border rounded-lg p-2">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-medium">{t("messenger.yourConversations")}</h3>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MessageSquare className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>{t("messenger.newConversation")}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <p>{t("messenger.selectContact")}</p>
                          {/* Contact selector would go here */}
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                  
                  <ScrollArea className="h-[calc(70vh-120px)]">
                    <div className="space-y-2">
                      {conversationsLoading ? (
                        <p className="text-center text-sm text-muted-foreground py-4">
                          {t("common.loading")}
                        </p>
                      ) : conversations && conversations.length > 0 ? (
                        conversations.map((conversation: any) => (
                          <div 
                            key={conversation.id}
                            className={`p-2 rounded-lg cursor-pointer hover:bg-secondary/80 
                              ${activeConversation === conversation.id ? 'bg-secondary' : ''}`}
                            onClick={() => setActiveConversation(conversation.id)}
                          >
                            <div className="flex items-center space-x-2">
                              <Avatar>
                                <AvatarImage src={conversation.avatarUrl} />
                                <AvatarFallback>{conversation.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1">
                                <div className="font-medium">{conversation.name}</div>
                                <div className="text-xs text-muted-foreground">
                                  {conversation.lastMessage || t("messenger.noMessages")}
                                </div>
                              </div>
                              {conversation.unread && (
                                <Badge className="bg-primary">{conversation.unread}</Badge>
                              )}
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-center text-sm text-muted-foreground py-4">
                          {t("messenger.noConversations")}
                        </p>
                      )}
                    </div>
                  </ScrollArea>
                </div>
                
                {/* Active Conversation */}
                <div className="border rounded-lg p-2 md:col-span-2">
                  {activeConversation ? (
                    <>
                      <div className="flex items-center space-x-2 p-2 border-b">
                        <Avatar>
                          <AvatarImage src="" />
                          <AvatarFallback>U</AvatarFallback>
                        </Avatar>
                        <div className="font-medium">User Name</div>
                      </div>
                      
                      <div id="messages-container" className="h-[calc(70vh-200px)] overflow-y-auto p-2">
                        {messagesLoading ? (
                          <p className="text-center text-sm text-muted-foreground py-4">
                            {t("common.loading")}
                          </p>
                        ) : messages && messages.length > 0 ? (
                          messages.map((message: any) => (
                            <div 
                              key={message.id}
                              className={`mb-2 max-w-[80%] ${message.senderId === walletAddress 
                                ? 'ml-auto bg-primary text-primary-foreground' 
                                : 'bg-secondary'} rounded-lg p-2`}
                            >
                              {message.messageType === 'text' ? (
                                <p>{message.content}</p>
                              ) : message.messageType === 'image' ? (
                                <img 
                                  src={message.content} 
                                  alt="Image" 
                                  className="max-w-full rounded" 
                                />
                              ) : (
                                <div className="flex items-center space-x-2">
                                  <PaperclipIcon className="h-4 w-4" />
                                  <span>{message.fileName}</span>
                                </div>
                              )}
                              <span className="text-xs opacity-70 block text-right">
                                {new Date(message.sentAt).toLocaleTimeString()}
                              </span>
                            </div>
                          ))
                        ) : (
                          <p className="text-center text-sm text-muted-foreground py-4">
                            {t("messenger.startConversation")}
                          </p>
                        )}
                      </div>
                      
                      <div className="p-2 border-t">
                        {fileToUpload && (
                          <div className="mb-2 p-1 border rounded flex items-center justify-between">
                            <span className="text-sm truncate">{fileToUpload.name}</span>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => setFileToUpload(null)}
                            >
                              &times;
                            </Button>
                          </div>
                        )}
                        
                        <div className="flex space-x-2">
                          <div className="relative">
                            <Button variant="ghost" size="icon" className="h-10 w-10">
                              <PaperclipIcon className="h-5 w-5" />
                            </Button>
                            <input 
                              type="file" 
                              className="absolute inset-0 opacity-0 cursor-pointer"
                              onChange={handleFileSelect}
                            />
                          </div>
                          
                          <Button variant="ghost" size="icon" className="h-10 w-10">
                            <Camera className="h-5 w-5" />
                          </Button>
                          
                          <Input 
                            value={messageText}
                            onChange={(e) => setMessageText(e.target.value)}
                            placeholder={t("messenger.typePlaceholder")}
                            className="flex-1"
                            onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                          />
                          
                          <Button 
                            onClick={sendMessage} 
                            size="icon"
                            className="h-10 w-10"
                          >
                            <Send className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="flex items-center justify-center h-[calc(70vh-100px)]">
                      <div className="text-center">
                        <MessageSquare className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                        <p>{t("messenger.selectConversation")}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="contacts" className="mt-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Contacts List */}
                <div className="border rounded-lg p-2">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-medium">{t("messenger.friends")}</h3>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <UserPlus className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>{t("messenger.addFriend")}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <Input placeholder={t("messenger.enterWalletAddress")} />
                          <Button className="w-full">{t("messenger.sendRequest")}</Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                  
                  <ScrollArea className="h-[calc(70vh-120px)]">
                    <div className="space-y-2">
                      {friendsLoading ? (
                        <p className="text-center text-sm text-muted-foreground py-4">
                          {t("common.loading")}
                        </p>
                      ) : friends && friends.length > 0 ? (
                        friends.map((friend: any) => (
                          <div 
                            key={friend.id}
                            className="p-2 rounded-lg cursor-pointer hover:bg-secondary/80 flex items-center space-x-2"
                          >
                            <Avatar>
                              <AvatarImage src={friend.avatarUrl} />
                              <AvatarFallback>{friend.displayName.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{friend.displayName}</div>
                              <div className="text-xs text-muted-foreground truncate">
                                {friend.walletAddress}
                              </div>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-center text-sm text-muted-foreground py-4">
                          {t("messenger.noFriends")}
                        </p>
                      )}
                    </div>
                  </ScrollArea>
                </div>
                
                {/* Friend Requests */}
                <div className="border rounded-lg p-2 md:col-span-2">
                  <h3 className="font-medium mb-2">{t("messenger.friendRequests")}</h3>
                  
                  <div className="space-y-2">
                    {/* Mock friend request */}
                    <div className="border rounded-lg p-2">
                      <div className="flex items-center space-x-2">
                        <Avatar>
                          <AvatarImage src="" />
                          <AvatarFallback>C</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="font-medium">ChessMaster</div>
                          <div className="text-xs text-muted-foreground truncate">
                            0x123...abc
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="default">
                            {t("messenger.accept")}
                          </Button>
                          <Button size="sm" variant="outline">
                            {t("messenger.decline")}
                          </Button>
                        </div>
                      </div>
                    </div>
                    
                    <p className="text-center text-sm text-muted-foreground py-4">
                      {t("messenger.noMoreRequests")}
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}