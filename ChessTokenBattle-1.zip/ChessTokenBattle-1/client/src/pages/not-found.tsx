import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FaChessKing, FaChessRook, FaChessPawn, FaChessBishop, FaChessKnight, FaChessQueen } from "react-icons/fa";
import { Home } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

export default function NotFound() {
  const { t } = useLanguage();
  
  const chessPieces = [
    { Icon: FaChessKing, color: "text-purple-500", delay: "150ms" },
    { Icon: FaChessQueen, color: "text-pink-500", delay: "300ms" },
    { Icon: FaChessRook, color: "text-blue-500", delay: "450ms" },
    { Icon: FaChessBishop, color: "text-green-500", delay: "600ms" },
    { Icon: FaChessKnight, color: "text-orange-500", delay: "750ms" },
    { Icon: FaChessPawn, color: "text-red-500", delay: "900ms" }
  ];

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-50 to-white z-0"></div>
      
      {/* Animated Chess Pieces */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        {chessPieces.map((piece, index) => (
          <div 
            key={index}
            className={`absolute text-4xl ${piece.color} animate-float opacity-20`}
            style={{
              top: `${Math.random() * 80 + 10}%`,
              left: `${Math.random() * 80 + 10}%`,
              animationDelay: piece.delay,
              transform: `rotate(${Math.random() * 30 - 15}deg)`
            }}
          >
            <piece.Icon />
          </div>
        ))}
      </div>
      
      {/* Content */}
      <div className="z-10 px-4 max-w-md w-full">
        <Card className="card-gradient border-0 shadow-xl overflow-hidden">
          <div className="bg-white p-6 sm:p-8 text-center">
            <div className="w-24 h-24 mx-auto bg-red-100 rounded-full flex items-center justify-center mb-6">
              <div className="relative">
                <FaChessKing className="text-6xl text-primary opacity-20" />
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-2xl font-bold">
                  404
                </div>
              </div>
            </div>
            
            <h1 className="text-3xl font-bold mb-4 text-gray-800">
              {t("notFound.title", "Page Not Found")}
            </h1>
            
            <p className="text-gray-600 mb-8">
              {t("notFound.message", "The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.")}
            </p>
            
            <Button asChild className="btn-gradient">
              <Link to="/">
                <Home className="mr-2 h-4 w-4" />
                {t("notFound.backHome", "Back to Home")}
              </Link>
            </Button>
          </div>
        </Card>
      </div>
      
      {/* Add custom styling for float animation */}
      <style jsx global>{`
        @keyframes float {
          0% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-15px) rotate(5deg); }
          100% { transform: translateY(0px) rotate(0deg); }
        }
        
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}
