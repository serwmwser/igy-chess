import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useWallet } from "./WalletContext";
import { useGameSocket } from "@/hooks/useGameSocket";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "./LanguageContext";
import { useLocation } from "wouter";

type ChatMessage = {
  id: string;
  sender: string;
  content: string;
  timestamp: number;
};

type LastMove = {
  player: string;
  from: string;
  to: string;
  notation: string;
  timestamp: number;
  whiteTimeLeft?: number;
  blackTimeLeft?: number;
};

type GameState = {
  id: string;
  playerWhite: string;
  playerBlack: string;
  fen: string;
  status: "waiting" | "active" | "completed";
  winner?: string;
  startTime?: number;
  timeLimit: number; // in seconds, 0 means unlimited
  chatMessages: ChatMessage[];
  moveHistory: string[][];
  lastMove?: LastMove;
  drawOfferedBy?: string;
  boardTheme?: string;
  pieceTheme?: string;
  videoEnabled?: boolean;
  stakeAmount?: number; // Количество токенов для ставки
  opponentType?: "random" | "invite" | "ai";
};

type MoveParams = {
  from: string;
  to: string;
  promotion?: string;
  gameId: string;
};

type ChatMessageParams = {
  gameId: string;
  content: string;
};

type CreateGameParams = {
  timeLimit: number;
  isPublic: boolean;
  inviteAddress?: string;
  boardTheme?: string;
  pieceTheme?: string;
  videoEnabled?: boolean;
  opponentMode?: "random" | "invite" | "ai";
  stakeAmount?: number; // Количество токенов для ставки
};

type GameContextType = {
  gameState: GameState | null;
  gameId: string | null;
  isLoading: boolean;
  createGame: (params: CreateGameParams) => Promise<void>;
  joinGame: (gameId: string) => Promise<void>;
  makeMove: (move: MoveParams) => void;
  resignGame: (gameId: string) => void;
  offerDraw: (gameId: string) => void;
  respondToDrawOffer: (gameId: string, accept: boolean) => void;
  sendChatMessage: (params: ChatMessageParams) => void;
};

const GameContext = createContext<GameContextType | undefined>(undefined);

export function GameProvider({ children }: { children: ReactNode }) {
  const { walletAddress, igyBalance, updateBalance } = useWallet();
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [gameId, setGameId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const socket = useGameSocket();
  const { toast } = useToast();
  const { t } = useLanguage();
  const [, navigate] = useLocation();

  // Set up socket event listeners
  useEffect(() => {
    if (!socket) return;
    
    const handleSocketMessage = (event: MessageEvent) => {
      try {
        const data = JSON.parse(event.data);
        
        switch (data.type) {
          case 'gameState':
            setGameState(data.game);
            setGameId(data.game.id);
            
            // If game completed, update balance
            if (data.game.status === 'completed') {
              updateBalance();
              
              // Show game result toast
              if (data.game.winner === walletAddress) {
                toast({
                  title: t("game.youWon"),
                  description: t("game.receivedToken"),
                });
              } else if (data.game.winner === 'draw') {
                toast({
                  title: t("game.gameDraw"),
                  description: t("game.noTokensExchanged"),
                });
              } else if (data.game.winner) {
                toast({
                  title: t("game.youLost"),
                  description: t("game.lostToken"),
                });
              }
            }
            break;
            
          case 'gameJoined':
            setGameId(data.gameId);
            navigate('/dashboard');
            toast({
              title: t("game.gameJoined"),
              description: t("game.waitingForStart"),
            });
            break;
            
          case 'gameCreated':
            setGameId(data.gameId);
            navigate('/dashboard');
            toast({
              title: t("game.gameCreated"),
              description: data.isPublic 
                ? t("game.waitingForPlayer") 
                : t("game.inviteLink"),
            });
            break;
            
          case 'error':
            toast({
              title: t("errors.error"),
              description: data.message,
              variant: "destructive"
            });
            break;
            
          case 'drawOffered':
            toast({
              title: t("game.drawOffered"),
              description: t("game.acceptOrDecline"),
              action: (
                <div className="flex gap-2 mt-2">
                  <button 
                    onClick={() => respondToDrawOffer(data.gameId, true)}
                    className="px-3 py-1 bg-green-500 text-white rounded"
                  >
                    {t("common.accept")}
                  </button>
                  <button 
                    onClick={() => respondToDrawOffer(data.gameId, false)}
                    className="px-3 py-1 bg-red-500 text-white rounded"
                  >
                    {t("common.decline")}
                  </button>
                </div>
              ),
            });
            break;
            
          // WebRTC signaling
          case 'rtcOffer':
            if (gameState && gameState.id === data.gameId) {
              // Forward to VideoChat component via gameState
              window.dispatchEvent(new CustomEvent('rtcSignal', {
                detail: {
                  type: 'offer',
                  offer: data.offer,
                  from: data.from,
                  gameId: data.gameId
                }
              }));
            }
            break;
            
          case 'rtcAnswer':
            if (gameState && gameState.id === data.gameId) {
              window.dispatchEvent(new CustomEvent('rtcSignal', {
                detail: {
                  type: 'answer',
                  answer: data.answer,
                  from: data.from,
                  gameId: data.gameId
                }
              }));
            }
            break;
            
          case 'rtcIceCandidate':
            if (gameState && gameState.id === data.gameId) {
              window.dispatchEvent(new CustomEvent('rtcSignal', {
                detail: {
                  type: 'iceCandidate',
                  candidate: data.candidate,
                  from: data.from,
                  gameId: data.gameId
                }
              }));
            }
            break;
        }
      } catch (error) {
        console.error('Error handling websocket message:', error);
      }
    };
    
    socket.addEventListener('message', handleSocketMessage);
    
    return () => {
      socket.removeEventListener('message', handleSocketMessage);
    };
  }, [socket, walletAddress, toast, t, navigate, updateBalance]);

  // Reconnect to active game if user has one
  useEffect(() => {
    if (!socket || !walletAddress) return;
    
    // Wait until socket is open
    if (socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: 'reconnect',
        address: walletAddress
      }));
    }
  }, [socket, walletAddress]);

  const createGame = async (params: CreateGameParams) => {
    if (!socket || !walletAddress) {
      throw new Error(t("errors.notConnected"));
    }
    
    if (igyBalance < 1) {
      throw new Error(t("errors.insufficientBalance"));
    }
    
    setIsLoading(true);
    
    try {
      socket.send(JSON.stringify({
        type: 'createGame',
        address: walletAddress,
        timeLimit: params.timeLimit,
        isPublic: params.isPublic,
        inviteAddress: params.inviteAddress,
        boardTheme: params.boardTheme,
        pieceTheme: params.pieceTheme,
        videoEnabled: params.videoEnabled || false,
        opponentMode: params.opponentMode || "random",
        stakeAmount: params.stakeAmount || 1
      }));
    } catch (error) {
      console.error('Error creating game:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const joinGame = async (gameId: string) => {
    if (!socket || !walletAddress) {
      throw new Error(t("errors.notConnected"));
    }
    
    if (igyBalance < 1) {
      throw new Error(t("errors.insufficientBalance"));
    }
    
    setIsLoading(true);
    
    try {
      socket.send(JSON.stringify({
        type: 'joinGame',
        address: walletAddress,
        gameId
      }));
    } catch (error) {
      console.error('Error joining game:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const makeMove = (move: MoveParams) => {
    if (!socket || !walletAddress) return;
    
    socket.send(JSON.stringify({
      type: 'makeMove',
      address: walletAddress,
      gameId: move.gameId,
      from: move.from,
      to: move.to,
      promotion: move.promotion
    }));
  };

  const resignGame = (gameId: string) => {
    if (!socket || !walletAddress) return;
    
    socket.send(JSON.stringify({
      type: 'resign',
      address: walletAddress,
      gameId
    }));
  };

  const offerDraw = (gameId: string) => {
    if (!socket || !walletAddress) return;
    
    socket.send(JSON.stringify({
      type: 'offerDraw',
      address: walletAddress,
      gameId
    }));
  };

  const respondToDrawOffer = (gameId: string, accept: boolean) => {
    if (!socket || !walletAddress) return;
    
    socket.send(JSON.stringify({
      type: 'respondToDrawOffer',
      address: walletAddress,
      gameId,
      accept
    }));
  };

  const sendChatMessage = (params: ChatMessageParams) => {
    if (!socket || !walletAddress) return;
    
    socket.send(JSON.stringify({
      type: 'chatMessage',
      address: walletAddress,
      gameId: params.gameId,
      content: params.content
    }));
  };

  return (
    <GameContext.Provider
      value={{
        gameState,
        gameId,
        isLoading,
        createGame,
        joinGame,
        makeMove,
        resignGame,
        offerDraw,
        respondToDrawOffer,
        sendChatMessage
      }}
    >
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error("useGame must be used within a GameProvider");
  }
  return context;
}
