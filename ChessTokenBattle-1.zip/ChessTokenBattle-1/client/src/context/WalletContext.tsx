import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useLocation } from "wouter";
import { connectToWallet, getIGYBalance, disconnectWallet, getProviderAndSigner } from "@/lib/web3";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "./LanguageContext";

type WalletContextType = {
  walletAddress: string | null;
  igyBalance: number;
  isConnected: boolean;
  isConnecting: boolean;
  isDesktopWallet: boolean;
  connectWallet: () => Promise<void>;
  disconnect: () => void;
  updateBalance: () => Promise<void>;
  addTokens: (amount: number, reason: string) => Promise<void>;
};

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [igyBalance, setIgyBalance] = useState<number>(0);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);
  const [isDesktopWallet, setIsDesktopWallet] = useState<boolean>(true);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { t } = useLanguage();

  // Check if wallet is already connected
  useEffect(() => {
    const checkConnection = async () => {
      try {
        const { provider, signer } = await getProviderAndSigner();
        
        if (signer) {
          const address = await signer.getAddress();
          setWalletAddress(address);
          setIsConnected(true);
          
          // Определяем тип подключенного кошелька (десктоп или мобильный)
          // WalletConnect обычно не имеет свойства isMetaMask
          if (provider && typeof provider === 'object') {
            setIsDesktopWallet(!!provider.isMetaMask);
          }
          
          updateBalance();
        }
      } catch (error) {
        console.log("No connected wallet found");
        
        // Проверяем сохраненный адрес (fallback вариант)
        const savedAddress = localStorage.getItem("walletAddress");
        if (savedAddress) {
          setWalletAddress(savedAddress);
          setIsConnected(true);
          updateBalance();
        }
      }
    };
    
    checkConnection();
  }, []);

  const updateBalance = async () => {
    if (!walletAddress) return;
    
    try {
      const balance = await getIGYBalance(walletAddress);
      setIgyBalance(balance);
    } catch (error) {
      console.error("Error fetching balance:", error);
    }
  };

  const connectWallet = async (): Promise<void> => {
    setIsConnecting(true);
    
    try {
      const address = await connectToWallet();
      setWalletAddress(address);
      setIsConnected(true);
      localStorage.setItem("walletAddress", address);
      
      // Проверяем, используется ли десктопный кошелек или мобильный
      // Временно используем User Agent для определения, в будущем 
      // можно добавить более точную логику определения типа кошелька
      const isMobileUserAgent = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
      setIsDesktopWallet(!isMobileUserAgent);
      
      // Get IGY token balance
      await updateBalance();
      
      // Navigate to dashboard after successful connection
      navigate("/dashboard");
      
      toast({
        title: t("wallet.connected"),
        description: t("wallet.walletConnected"),
      });
    } catch (error) {
      console.error("Wallet connection error:", error);
      toast({
        title: t("errors.connectionFailed"),
        description: typeof error === 'string' ? error : t("errors.tryAgain"),
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnect = () => {
    disconnectWallet();
    setWalletAddress(null);
    setIsConnected(false);
    setIgyBalance(0);
    setIsDesktopWallet(true);
    localStorage.removeItem("walletAddress");
    navigate("/");
    
    toast({
      title: t("wallet.disconnected"),
      description: t("wallet.walletDisconnected"),
    });
  };

  // Добавление токенов пользователю (локально и через API)
  const addTokens = async (amount: number, reason: string): Promise<void> => {
    if (!walletAddress) return;
    
    try {
      // Отправляем запрос на бэкенд для добавления токенов
      const response = await fetch('/api/tokens/add', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          walletAddress,
          amount,
          reason
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to add tokens');
      }
      
      // Обновляем локальный баланс
      setIgyBalance(prev => prev + amount);
      
      toast({
        title: t("wallet.tokensAdded"),
        description: t("wallet.tokensAddedDescription", { amount }),
      });
    } catch (error) {
      console.error('Error adding tokens:', error);
      
      // Если API не работает, хотя бы обновим локальный баланс
      // чтобы пользователь увидел изменения
      setIgyBalance(prev => prev + amount);
      
      toast({
        title: t("wallet.tokensAdded"),
        description: t("wallet.tokensAddedDescription", { amount }),
      });
    }
  };

  return (
    <WalletContext.Provider
      value={{
        walletAddress,
        igyBalance,
        isConnected,
        isConnecting,
        isDesktopWallet,
        connectWallet,
        disconnect,
        updateBalance,
        addTokens
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error("useWallet must be used within a WalletProvider");
  }
  return context;
}
