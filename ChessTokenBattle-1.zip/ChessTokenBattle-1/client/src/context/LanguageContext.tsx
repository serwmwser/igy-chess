import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import i18n from "@/lib/i18n";
import { translateWithFallback } from "@/lib/i18n-helper";

type LanguageContextType = {
  currentLanguage: string;
  changeLanguage: (language: string) => void;
  t: (key: string, fallbackOrParams?: string | Record<string, string | number>, params?: Record<string, string | number>) => string;
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [currentLanguage, setCurrentLanguage] = useState<string>("en");

  // Initialize language from localStorage if available
  useEffect(() => {
    const savedLanguage = localStorage.getItem("language");
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
      i18n.changeLanguage(savedLanguage);
    } else {
      // Try to detect browser language
      const browserLang = navigator.language.split("-")[0];
      const supported = ["en", "ru", "es", "zh", "hi", "ja", "fr"];
      
      if (supported.includes(browserLang)) {
        setCurrentLanguage(browserLang);
        i18n.changeLanguage(browserLang);
        localStorage.setItem("language", browserLang);
      }
    }
  }, []);

  const changeLanguage = (language: string) => {
    i18n.changeLanguage(language);
    setCurrentLanguage(language);
    localStorage.setItem("language", language);
  };

  // Use our helper function
  const t = (
    key: string, 
    fallbackOrParams?: string | Record<string, string | number>,
    params?: Record<string, string | number>
  ) => {
    return translateWithFallback(key, fallbackOrParams, params);
  };

  const contextValue: LanguageContextType = {
    currentLanguage,
    changeLanguage,
    t
  };

  return (
    <LanguageContext.Provider value={contextValue}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
