import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

// English translations
const enTranslations = {
  header: {
    home: "Home",
    play: "Play",
    leaderboard: "Leaderboard",
    about: "About"
  },
  home: {
    token: {
      title: "IGY Token Economy",
      description: "The IGY token powers the entire ecosystem, enabling players to stake on games, purchase custom themes, and earn rewards.",
      aboutToken: "About IGY Token",
      tokenDescription: "IGY is a utility token built on the Polygon blockchain that powers the IGY Chess platform.",
      useCases: "Token Use Cases",
      useCasesDescription: "IGY token has multiple utilities within our ecosystem:",
      useCase1: "Stake in chess games",
      useCase2: "Enter tournaments",
      useCase3: "Purchase premium themes",
      supply: "Total Supply",
      circulation: "Tokens in Circulation",
      ratio: "Exchange Ratio",
      listing: "Exchange Listing",
      roadmap: "Token Roadmap",
      phase1: "Platform Launch",
      phase2: "Community Growth",
      phase3: "100,000 Users",
      phase4: "Exchange Listing",
      walletVisibility: "Visible in crypto wallets",
      polygonscanVisibility: "Verified on Polygonscan"
    }
  },
  walletConnect: {
    welcome: "Welcome to IGY Chess",
    subtitle: "Connect your wallet to play blockchain chess and earn IGY tokens",
    connectWallet: "Connect Wallet",
    connecting: "Connecting...",
    info: "Connect with WalletConnect to authenticate and manage your tokens"
  },
  features: {
    playChess: "Play Chess",
    playChessDesc: "Challenge opponents in timed or unlimited matches",
    earnTokens: "Earn Tokens",
    earnTokensDesc: "Win matches to earn IGY tokens from opponents",
    inviteFriends: "Invite Friends",
    inviteFriendsDesc: "Generate referral links to challenge friends",
    climbLeaderboard: "Climb Leaderboard",
    climbLeaderboardDesc: "Compete for top rankings among players"
  },
  profile: {
    walletAddress: "Wallet Address",
    connected: "Connected",
    disconnect: "Disconnect",
    yourBalance: "Your Balance",
    igyTokenAddress: "IGY Token",
    gameStats: "Game Stats",
    wins: "Wins",
    losses: "Losses",
    draws: "Draws",
    viewHistory: "View Full History"
  },
  invite: {
    inviteFriends: "Invite Friends",
    generateLink: "Generate a referral link to invite friends to play",
    copyToClipboard: "Copy to clipboard",
    generateNewLink: "Generate New Link",
    copied: "Copied!",
    copiedDesc: "Invite link copied to clipboard",
    generated: "Generated!",
    generatedDesc: "New invite link created"
  },
  game: {
    opponent: "Opponent",
    gameStatus: "Game Status",
    timer: "Timer",
    yourTurn: "Your Turn",
    opponentTurn: "Opponent's Turn",
    waitingForStart: "Waiting to start",
    waiting: "Waiting for opponent",
    draw: "Draw",
    youWon: "You Won!",
    youLost: "You Lost",
    resign: "Resign",
    offerDraw: "Offer Draw",
    drawOffered: "Draw Offered",
    drawOfferDeclined: "Draw Declined",
    waitingForOpponent: "Waiting for opponent's response",
    acceptOrDecline: "Accept or decline the draw offer",
    gameMode: "Game Mode",
    unlimited: "Unlimited",
    oneHour: "1 Hour",
    gameCreated: "Game Created",
    lookingForOpponent: "Looking for an opponent",
    inviteSent: "Invite link ready to share",
    gameJoined: "Game Joined",
    gameDraw: "Game Draw",
    receivedToken: "You received 1 IGY token",
    lostToken: "You lost 1 IGY token",
    noTokensExchanged: "No tokens were exchanged"
  },
  gameInfo: {
    title: "Game Information",
    stake: "Stake",
    gameMode: "Game Mode",
    gameId: "Game ID",
    started: "Started",
    moveHistory: "Move History",
    unlimitedTime: "Unlimited Time",
    oneHourTimer: "1 Hour Timer",
    noMoves: "No moves yet"
  },
  chat: {
    gameChat: "Game Chat",
    typePlaceholder: "Type a message...",
    you: "You",
    system: "System",
    gameStarted: "Game has started! Good luck!",
    moved: "moved"
  },
  leaderboard: {
    title: "Leaderboard",
    wins: "Wins",
    viewFull: "View Full Leaderboard",
    showLess: "Show Less",
    loading: "Loading leaderboard..."
  },
  startGame: {
    title: "Start New Game",
    gameMode: "Game Mode",
    oneHour: "1 Hour",
    unlimited: "Unlimited",
    gameStake: "Game Stake",
    stakeAmount: "Stake Amount",
    stakeDescription: "Winner receives 1 IGY from the loser. You must have at least 1 IGY token in your wallet.",
    yourBalance: "Your Balance",
    findOpponent: "Find Opponent",
    randomMatch: "Random Match",
    inviteFriend: "Invite Friend",
    startGame: "Start Game"
  },
  wallet: {
    connected: "Wallet Connected",
    walletConnected: "Your wallet has been connected successfully",
    disconnected: "Wallet Disconnected",
    walletDisconnected: "Your wallet has been disconnected"
  },
  footer: {
    tagline: "Play chess on blockchain. Win tokens.",
    igyToken: "IGY Token",
    allRightsReserved: "All rights reserved.",
    terms: "Terms of Service",
    privacy: "Privacy Policy"
  },
  errors: {
    walletConnection: "Wallet Connection Failed",
    walletNotConnected: "Wallet Not Connected",
    connectWalletFirst: "Please connect your wallet first",
    insufficientBalance: "Insufficient Balance",
    needOneIGY: "You need at least 1 IGY token to play",
    gameCreationFailed: "Game Creation Failed",
    cannotResign: "Cannot Resign",
    cannotOfferDraw: "Cannot Offer Draw",
    noActiveGame: "No active game in progress",
    connectionFailed: "Connection Failed",
    notConnected: "Not connected to wallet or game server",
    tryAgain: "Please try again",
    error: "Error"
  },
  time: {
    secondsAgo: "seconds ago",
    minutesAgo: "minutes ago",
    hoursAgo: "hours ago"
  },
  token: {
    igyToken: "IGY Token",
    poweredByPolygon: "Powered by Polygon",
    currentPrice: "Current Price",
    priceTooltip: "IGY token price equals POL price with 1:1 ratio",
    contractInfo: "Contract Information",
    totalSupply: "Total Supply",
    circulatingSupply: "Circulating Supply",
    walletVisibility: "Visible in wallets",
    polygonscanVisibility: "Polygonscan verified",
    buy: "Buy Tokens",
    sell: "Sell Tokens"
  },
  common: {
    cancel: "Cancel",
    accept: "Accept",
    decline: "Decline",
    loading: "Loading..."
  },
  messenger: {
    title: "Messenger",
    registerProfile: "Register Messenger Profile",
    registrationDesc: "Create your messenger profile to chat with other players. It costs 1 IGY token.",
    dataPolicy: "CHESS_GO does not collect or use your personal data.",
    registrationFee: "Registration fee: 1 IGY token",
    displayName: "Display Name",
    displayNamePlaceholder: "Enter your display name",
    createProfile: "Create Profile",
    profileCreated: "Profile Created",
    profileCreatedDesc: "Your messenger profile has been created successfully",
    conversations: "Conversations",
    contacts: "Contacts",
    yourConversations: "Your Conversations",
    newConversation: "New Conversation",
    selectContact: "Select a contact to start a conversation",
    noMessages: "No messages yet",
    noConversations: "No conversations yet",
    startConversation: "Start a conversation by sending a message",
    selectConversation: "Select a conversation",
    typePlaceholder: "Type a message...",
    messageSent: "Message sent",
    friends: "Friends",
    addFriend: "Add Friend",
    enterWalletAddress: "Enter wallet address",
    sendRequest: "Send Friend Request",
    noFriends: "No friends yet",
    friendRequests: "Friend Requests",
    accept: "Accept",
    decline: "Decline",
    noMoreRequests: "No more friend requests",
    pleaseConnectWallet: "Please connect your wallet to use messenger",
    errors: {
      nameRequired: "Name Required",
      pleaseEnterName: "Please enter a display name",
      profileCreationFailed: "Profile Creation Failed",
      messageFailed: "Failed to send message"
    }
  }
};

// Russian translations
const ruTranslations = {
  header: {
    home: "Главная",
    play: "Играть",
    leaderboard: "Рейтинг",
    about: "О проекте"
  },
  home: {
    token: {
      title: "Экономика токена IGY",
      description: "Токен IGY обеспечивает работу всей экосистемы, позволяя игрокам делать ставки в играх, покупать темы оформления и зарабатывать награды.",
      aboutToken: "О токене IGY",
      tokenDescription: "IGY - это утилитарный токен, построенный на блокчейне Polygon, обеспечивающий работу платформы IGY Chess.",
      useCases: "Применение токена",
      useCasesDescription: "Токен IGY имеет множество применений в нашей экосистеме:",
      useCase1: "Ставки в шахматных играх",
      useCase2: "Участие в турнирах",
      useCase3: "Покупка премиальных тем",
      supply: "Общее количество",
      circulation: "Токенов в обращении",
      ratio: "Обменный курс",
      listing: "Листинг на биржах",
      roadmap: "Дорожная карта токена",
      phase1: "Запуск платформы",
      phase2: "Рост сообщества",
      phase3: "100 000 пользователей",
      phase4: "Листинг на биржах",
      walletVisibility: "Виден в криптокошельках",
      polygonscanVisibility: "Проверен на Polygonscan"
    }
  },
  walletConnect: {
    welcome: "Добро пожаловать в IGY Chess",
    subtitle: "Подключите кошелек, чтобы играть в шахматы на блокчейне и зарабатывать токены IGY",
    connectWallet: "Подключить кошелек",
    connecting: "Подключение...",
    info: "Подключите WalletConnect для аутентификации и управления токенами"
  },
  features: {
    playChess: "Играть в шахматы",
    playChessDesc: "Соревнуйтесь с противниками в ограниченных по времени или неограниченных матчах",
    earnTokens: "Зарабатывайте токены",
    earnTokensDesc: "Выигрывайте матчи, чтобы получать токены IGY от противников",
    inviteFriends: "Пригласите друзей",
    inviteFriendsDesc: "Создавайте реферальные ссылки для приглашения друзей",
    climbLeaderboard: "Поднимайтесь в рейтинге",
    climbLeaderboardDesc: "Соревнуйтесь за высшие позиции среди игроков"
  },
  profile: {
    walletAddress: "Адрес кошелька",
    connected: "Подключен",
    disconnect: "Отключиться",
    yourBalance: "Ваш баланс",
    igyTokenAddress: "Токен IGY",
    gameStats: "Статистика игр",
    wins: "Победы",
    losses: "Поражения",
    draws: "Ничьи",
    viewHistory: "Просмотреть полную историю"
  },
  invite: {
    inviteFriends: "Пригласить друзей",
    generateLink: "Создайте реферальную ссылку, чтобы пригласить друзей играть",
    copyToClipboard: "Копировать в буфер обмена",
    generateNewLink: "Создать новую ссылку",
    copied: "Скопировано!",
    copiedDesc: "Ссылка-приглашение скопирована в буфер обмена",
    generated: "Создано!",
    generatedDesc: "Новая ссылка-приглашение создана"
  },
  game: {
    opponent: "Противник",
    gameStatus: "Статус игры",
    timer: "Таймер",
    yourTurn: "Ваш ход",
    opponentTurn: "Ход противника",
    waitingForStart: "Ожидание начала",
    waiting: "Ожидание противника",
    draw: "Ничья",
    youWon: "Вы выиграли!",
    youLost: "Вы проиграли",
    resign: "Сдаться",
    offerDraw: "Предложить ничью",
    drawOffered: "Предложена ничья",
    drawOfferDeclined: "Ничья отклонена",
    waitingForOpponent: "Ожидание ответа противника",
    acceptOrDecline: "Принять или отклонить предложение ничьей",
    gameMode: "Режим игры",
    unlimited: "Без ограничений",
    oneHour: "1 час",
    gameCreated: "Игра создана",
    lookingForOpponent: "Поиск противника",
    inviteSent: "Ссылка-приглашение готова",
    gameJoined: "Вы присоединились к игре",
    gameDraw: "Игра завершилась вничью",
    receivedToken: "Вы получили 1 токен IGY",
    lostToken: "Вы потеряли 1 токен IGY",
    noTokensExchanged: "Токены не были обменены"
  },
  gameInfo: {
    title: "Информация об игре",
    stake: "Ставка",
    gameMode: "Режим игры",
    gameId: "ID игры",
    started: "Начало",
    moveHistory: "История ходов",
    unlimitedTime: "Без ограничения времени",
    oneHourTimer: "Таймер 1 час",
    noMoves: "Ходов пока нет"
  },
  chat: {
    gameChat: "Чат игры",
    typePlaceholder: "Введите сообщение...",
    you: "Вы",
    system: "Система",
    gameStarted: "Игра началась! Удачи!",
    moved: "сходил"
  },
  leaderboard: {
    title: "Рейтинг",
    wins: "Победы",
    viewFull: "Посмотреть полный рейтинг",
    showLess: "Показать меньше",
    loading: "Загрузка рейтинга..."
  },
  startGame: {
    title: "Начать новую игру",
    gameMode: "Режим игры",
    oneHour: "1 час",
    unlimited: "Без ограничений",
    gameStake: "Ставка игры",
    stakeAmount: "Размер ставки",
    stakeDescription: "Победитель получает 1 IGY от проигравшего. У вас должен быть как минимум 1 токен IGY.",
    yourBalance: "Ваш баланс",
    findOpponent: "Найти противника",
    randomMatch: "Случайный матч",
    inviteFriend: "Пригласить друга",
    startGame: "Начать игру"
  },
  wallet: {
    connected: "Кошелек подключен",
    walletConnected: "Ваш кошелек успешно подключен",
    disconnected: "Кошелек отключен",
    walletDisconnected: "Ваш кошелек был отключен"
  },
  footer: {
    tagline: "Играйте в шахматы на блокчейне. Выигрывайте токены.",
    igyToken: "Токен IGY",
    allRightsReserved: "Все права защищены.",
    terms: "Условия использования",
    privacy: "Политика конфиденциальности"
  },
  errors: {
    walletConnection: "Ошибка подключения кошелька",
    walletNotConnected: "Кошелек не подключен",
    connectWalletFirst: "Пожалуйста, сначала подключите кошелек",
    insufficientBalance: "Недостаточный баланс",
    needOneIGY: "Вам нужен как минимум 1 токен IGY для игры",
    gameCreationFailed: "Ошибка создания игры",
    cannotResign: "Невозможно сдаться",
    cannotOfferDraw: "Невозможно предложить ничью",
    noActiveGame: "Нет активной игры",
    connectionFailed: "Ошибка подключения",
    notConnected: "Не подключен к кошельку или игровому серверу",
    tryAgain: "Пожалуйста, попробуйте снова",
    error: "Ошибка"
  },
  time: {
    secondsAgo: "секунд назад",
    minutesAgo: "минут назад",
    hoursAgo: "часов назад"
  },
  token: {
    igyToken: "Токен IGY",
    poweredByPolygon: "На базе Polygon",
    currentPrice: "Текущая цена",
    priceTooltip: "Цена токена IGY равна цене POL с соотношением 1:1",
    contractInfo: "Информация о контракте",
    totalSupply: "Общее предложение",
    circulatingSupply: "В обращении",
    walletVisibility: "Виден в кошельках",
    polygonscanVisibility: "Проверен в Polygonscan",
    buy: "Купить токены",
    sell: "Продать токены"
  },
  common: {
    cancel: "Отмена",
    accept: "Принять",
    decline: "Отклонить",
    loading: "Загрузка..."
  },
  messenger: {
    title: "Мессенджер",
    registerProfile: "Регистрация профиля",
    registrationDesc: "Создайте профиль мессенджера для общения с другими игроками. Стоимость - 1 токен IGY.",
    dataPolicy: "CHESS_GO не собирает и не использует ваши персональные данные.",
    registrationFee: "Стоимость регистрации: 1 токен IGY",
    displayName: "Отображаемое имя",
    displayNamePlaceholder: "Введите ваше имя",
    createProfile: "Создать профиль",
    profileCreated: "Профиль создан",
    profileCreatedDesc: "Ваш профиль мессенджера успешно создан",
    conversations: "Беседы",
    contacts: "Контакты",
    yourConversations: "Ваши беседы",
    newConversation: "Новая беседа",
    selectContact: "Выберите контакт для начала беседы",
    noMessages: "Сообщений пока нет",
    noConversations: "Бесед пока нет",
    startConversation: "Начните беседу, отправив сообщение",
    selectConversation: "Выберите беседу",
    typePlaceholder: "Введите сообщение...",
    messageSent: "Сообщение отправлено",
    friends: "Друзья",
    addFriend: "Добавить друга",
    enterWalletAddress: "Введите адрес кошелька",
    sendRequest: "Отправить запрос",
    noFriends: "У вас пока нет друзей",
    friendRequests: "Запросы в друзья",
    accept: "Принять",
    decline: "Отклонить",
    noMoreRequests: "Больше запросов нет",
    pleaseConnectWallet: "Подключите кошелек, чтобы использовать мессенджер",
    errors: {
      nameRequired: "Требуется имя",
      pleaseEnterName: "Пожалуйста, введите отображаемое имя",
      profileCreationFailed: "Ошибка создания профиля",
      messageFailed: "Не удалось отправить сообщение"
    }
  }
};

// Add other language translations similarly
const esTranslations = {
  // Spanish translations
  header: {
    home: "Inicio",
    play: "Jugar",
    leaderboard: "Clasificación",
    about: "Acerca de"
  },
  // ... other translations ...
};

const zhTranslations = {
  // Chinese translations (Mandarin/中文)
  header: {
    home: "首页",
    play: "开始游戏",
    leaderboard: "排行榜",
    about: "关于"
  },
  walletConnect: {
    welcome: "欢迎来到 IGY Chess",
    subtitle: "连接您的钱包，在区块链上下棋并赚取 IGY 代币",
    connectWallet: "连接钱包",
    connecting: "连接中...",
    info: "通过 WalletConnect 进行身份验证并管理您的代币"
  },
  features: {
    playChess: "下棋",
    playChessDesc: "在限时或无限时模式中挑战对手",
    earnTokens: "赚取代币",
    earnTokensDesc: "赢得比赛以从对手那里获得 IGY 代币",
    inviteFriends: "邀请朋友",
    inviteFriendsDesc: "生成推荐链接邀请朋友",
    climbLeaderboard: "攀登排行榜",
    climbLeaderboardDesc: "在玩家中争夺顶级排名"
  },
  profile: {
    tabs: {
      dailyTasks: "每日任务",
      tokens: "代币",
      roadmap: "路线图",
      themes: "主题"
    }
  },
  // ... other translations ...
};

// Hindi translations (हिन्दी)
const hiTranslations = {
  header: {
    home: "होम",
    play: "खेलें",
    leaderboard: "लीडरबोर्ड",
    about: "परिचय"
  },
  walletConnect: {
    welcome: "IGY Chess में आपका स्वागत है",
    subtitle: "ब्लॉकचेन पर शतरंज खेलने और IGY टोकन कमाने के लिए अपना वॉलेट कनेक्ट करें",
    connectWallet: "वॉलेट कनेक्ट करें",
    connecting: "कनेक्ट हो रहा है...",
    info: "अपने टोकन को प्रमाणित और प्रबंधित करने के लिए WalletConnect से कनेक्ट करें"
  },
  profile: {
    tabs: {
      dailyTasks: "दैनिक कार्य",
      tokens: "टोकन",
      roadmap: "रोडमैप",
      themes: "थीम्स"
    }
  },
  // ... other translations ...
};

// Japanese translations (日本語)
const jaTranslations = {
  header: {
    home: "ホーム",
    play: "プレイ",
    leaderboard: "リーダーボード",
    about: "概要"
  },
  walletConnect: {
    welcome: "IGY Chess へようこそ",
    subtitle: "ウォレットを接続してブロックチェーン上でチェスをプレイし、IGYトークンを獲得しましょう",
    connectWallet: "ウォレットを接続",
    connecting: "接続中...",
    info: "WalletConnect で認証してトークンを管理"
  },
  profile: {
    tabs: {
      dailyTasks: "デイリータスク",
      tokens: "トークン",
      roadmap: "ロードマップ",
      themes: "テーマ"
    }
  },
  // ... other translations ...
};

// French translations (Français)
const frTranslations = {
  header: {
    home: "Accueil",
    play: "Jouer",
    leaderboard: "Classement",
    about: "À propos"
  },
  walletConnect: {
    welcome: "Bienvenue sur IGY Chess",
    subtitle: "Connectez votre portefeuille pour jouer aux échecs sur blockchain et gagner des jetons IGY",
    connectWallet: "Connecter le portefeuille",
    connecting: "Connexion en cours...",
    info: "Connectez-vous avec WalletConnect pour vous authentifier et gérer vos jetons"
  },
  profile: {
    tabs: {
      dailyTasks: "Tâches quotidiennes",
      tokens: "Jetons",
      roadmap: "Feuille de route",
      themes: "Thèmes"
    }
  },
  // ... other translations ...
};

i18n
  .use(initReactI18next)
  .init({
    resources: {
      en: { translation: enTranslations },
      ru: { translation: ruTranslations },
      es: { translation: esTranslations },
      zh: { translation: zhTranslations },
      hi: { translation: hiTranslations },
      ja: { translation: jaTranslations },
      fr: { translation: frTranslations }
    },
    lng: "en", // default language
    fallbackLng: "en",
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
