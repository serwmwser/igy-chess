import i18n from './i18n';

/**
 * Translation helper function with fallback support.
 * This function handles both formats:
 * - t(key, fallback)
 * - t(key, params)
 */
export function translateWithFallback(
  key: string, 
  fallbackOrParams?: string | Record<string, string | number>,
  params?: Record<string, string | number>
): string {
  if (typeof fallbackOrParams === 'object') {
    // If the second parameter is an object, it's the params
    return i18n.t(key, fallbackOrParams) as string;
  }
  
  // Otherwise, it's the fallback with optional params
  return i18n.t(key, { 
    defaultValue: fallbackOrParams,
    ...params 
  }) as string;
}