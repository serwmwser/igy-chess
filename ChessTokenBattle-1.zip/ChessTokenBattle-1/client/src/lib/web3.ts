import { ethers } from "ethers";
import { BrowserProvider, Contract, formatUnits, parseUnits } from "ethers";
import Web3Modal from "web3modal";
import WalletConnectProvider from "@walletconnect/web3-provider";

// Добавляем тип для window.ethereum
declare global {
  interface Window {
    ethereum?: any;
  }
}

// Токены
const IGY_TOKEN_ADDRESS = "0x6d278Ec8Bb6FC8d06c081e4688759546CC73eaB8";
const POL_TOKEN_ADDRESS = "0x0000000000000000000000000000000000001010";
const ADMIN_WALLET = "0xc2e5650f84eeb9e4011afbb398108ea302cb17a6";

// ABI для токена ERC20
const ERC20_ABI = [
  "function balanceOf(address owner) view returns (uint256)",
  "function transfer(address to, uint256 amount) returns (bool)",
  "function approve(address spender, uint256 amount) returns (bool)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function transferFrom(address sender, address recipient, uint256 amount) returns (bool)",
  "function decimals() view returns (uint8)"
];

// Для разработки используем mock кошелек, если кошелек недоступен
const mockWalletAddresses = {
  primary: "0x71CB05EE1b1F506fF321Da3dac38f25c0c9ce6E1",
  secondary: "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266"
};

// Параметры для Web3Modal
const providerOptions = {
  walletconnect: {
    package: WalletConnectProvider,
    options: {
      infuraId: "27e484dcd9e3efcfd25a83a78777cdf1" // Публичный ключ Infura для Polygon
    }
  }
};

// Инициализация Web3Modal
let web3Modal: Web3Modal | null = null;

const getWeb3Modal = () => {
  if (!web3Modal) {
    web3Modal = new Web3Modal({
      network: "matic", // Polygon network
      cacheProvider: true, // Запоминает последний подключенный кошелек
      providerOptions, // Настроенные провайдеры
      theme: {
        background: "#ffffff",
        main: "#7c3aed", // purple-600
        secondary: "#4f46e5", // indigo-600
        border: "#e5e7eb", // gray-200
        hover: "#f3f4f6" // gray-100
      }
    });
  }
  return web3Modal;
};

// Подключение к кошельку через Web3Modal (поддерживает Desktop и Mobile)
export const connectToWallet = async (): Promise<string> => {
  try {
    const modal = getWeb3Modal();
    const provider = await modal.connect();
    
    // Подписываемся на события
    provider.on("accountsChanged", (accounts: string[]) => {
      window.location.reload();
    });
    
    provider.on("chainChanged", (chainId: number) => {
      window.location.reload();
    });
    
    provider.on("disconnect", (error: { code: number; message: string }) => {
      disconnectWallet();
    });
    
    // Получаем адрес кошелька
    const ethersProvider = new BrowserProvider(provider);
    const signer = await ethersProvider.getSigner();
    const address = await signer.getAddress();
    
    return address;
  } catch (error) {
    console.error("Failed to connect to wallet:", error);
    
    // Если в режиме разработки, используем тестовый кошелек
    if (process.env.NODE_ENV === "development") {
      console.warn("Using mock wallet for development");
      return mockWalletAddresses.primary;
    }
    
    throw error;
  }
};

// Отключение от кошелька
export const disconnectWallet = async () => {
  try {
    // Очищаем кеш провайдера Web3Modal
    if (web3Modal) {
      web3Modal.clearCachedProvider();
    }
    console.log("Disconnected from wallet");
    
    // Перезагрузка страницы чтобы сбросить состояние приложения
    // window.location.reload();
  } catch (error) {
    console.error("Error disconnecting wallet:", error);
  }
};

// Получение экземпляра провайдера и подписчика (signer)
export const getProviderAndSigner = async () => {
  try {
    // Если есть уже подключенный провайдер через Web3Modal
    if (web3Modal && web3Modal.cachedProvider) {
      const provider = await web3Modal.connect();
      const ethersProvider = new BrowserProvider(provider);
      const signer = await ethersProvider.getSigner();
      return { provider, ethersProvider, signer };
    } 
    // Если доступен window.ethereum (MetaMask или другой инжектированный провайдер)
    else if (window.ethereum) {
      const provider = window.ethereum;
      const ethersProvider = new BrowserProvider(provider);
      const signer = await ethersProvider.getSigner();
      return { provider, ethersProvider, signer };
    } 
    // Для разработки - заглушка
    else if (process.env.NODE_ENV === "development") {
      console.warn("No wallet detected, using mock provider for development");
      return { 
        provider: null, 
        ethersProvider: null, 
        signer: {
          getAddress: async () => mockWalletAddresses.primary
        } as any
      };
    }
    
    throw new Error("No Ethereum wallet detected");
  } catch (error) {
    console.error("Error getting provider and signer:", error);
    throw error;
  }
};

// Получение баланса IGY токенов
export const getIGYBalance = async (address: string): Promise<number> => {
  try {
    // Для реального проекта, сделаем запрос через API к балансу на блокчейне
    const response = await fetch(`/api/users/${address}/balance`);
    
    if (!response.ok) {
      throw new Error("Failed to fetch balance");
    }
    
    const data = await response.json();
    return parseFloat(data.balance);
  } catch (error) {
    console.error("Error getting IGY balance:", error);
    // Для разработки возвращаем заглушку в случае ошибки
    return 10.0;
  }
};

// Перевод IGY токенов
export const transferIGY = async (toAddress: string, amount: number): Promise<string> => {
  try {
    const { ethersProvider, signer } = await getProviderAndSigner();
    
    if (ethersProvider && signer) {
      // Создаем экземпляр контракта IGY
      const igyContract = new Contract(
        IGY_TOKEN_ADDRESS,
        ERC20_ABI,
        signer
      );
      
      // Преобразуем сумму в wei (используя decimals токена)
      const decimals = await igyContract.decimals();
      const amountInWei = parseUnits(amount.toString(), decimals);
      
      // Выполняем транзакцию перевода
      const tx = await igyContract.transfer(toAddress, amountInWei);
      await tx.wait();
      
      return tx.hash;
    } else {
      console.warn("No Ethereum provider, using mock transaction");
      return `0x${Math.random().toString(16).substr(2, 64)}`;
    }
  } catch (error) {
    console.error("Error transferring IGY tokens:", error);
    throw error;
  }
};

// Покупка IGY токенов за POL
export const purchaseIGYWithPOL = async (amount: number): Promise<string> => {
  try {
    const { ethersProvider, signer } = await getProviderAndSigner();
    
    if (ethersProvider && signer) {
      const walletAddress = await signer.getAddress();
      
      // Создаем экземпляр контракта POL
      const polContract = new Contract(
        POL_TOKEN_ADDRESS,
        ERC20_ABI,
        signer
      );
      
      // Преобразуем сумму в wei
      const decimals = await polContract.decimals();
      const amountInWei = parseUnits(amount.toString(), decimals);
      
      // Отправляем POL токены адмиину
      const tx = await polContract.transfer(ADMIN_WALLET, amountInWei);
      await tx.wait();
      
      // Отправляем запрос на сервер для получения IGY
      const response = await fetch("/api/tokens/purchase", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          walletAddress,
          amount,
        }),
      });
      
      if (!response.ok) {
        throw new Error("Failed to process purchase on server");
      }
      
      const data = await response.json();
      
      if (!data.success) {
        throw new Error(data.message || "Unknown error");
      }
      
      return tx.hash;
    } else {
      console.warn("No Ethereum provider, using mock transaction");
      return `0x${Math.random().toString(16).substr(2, 64)}`;
    }
  } catch (error) {
    console.error("Error purchasing IGY tokens:", error);
    throw error;
  }
};
