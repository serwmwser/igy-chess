// Глобальные типы для приложения

// Расширение типа window для Ethereum
interface Window {
  ethereum?: any;
}

// Типы для Web3 и Metamask
declare namespace Ethereum {
  interface RequestArguments {
    method: string;
    params?: unknown[] | object;
  }
}