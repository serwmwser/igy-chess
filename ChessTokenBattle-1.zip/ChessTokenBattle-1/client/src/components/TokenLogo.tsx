import { useState, useEffect } from 'react';

interface TokenLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showLabel?: boolean;
  className?: string;
}

export default function TokenLogo({ size = 'md', showLabel = false, className = '' }: TokenLogoProps) {
  const [svgContent, setSvgContent] = useState<string>('');
  
  useEffect(() => {
    // Fetch the SVG content
    fetch('/token-logo.svg')
      .then(response => response.text())
      .then(data => {
        setSvgContent(data);
      })
      .catch(error => {
        console.error('Error loading token logo:', error);
      });
  }, []);
  
  // Determine size class
  const sizeClass = {
    'sm': 'w-6 h-6',
    'md': 'w-10 h-10',
    'lg': 'w-16 h-16',
    'xl': 'w-24 h-24'
  }[size];
  
  if (!svgContent) {
    // Display a placeholder while loading
    return (
      <div className={`${sizeClass} rounded-full bg-primary/10 ${className}`}></div>
    );
  }
  
  return (
    <div className={`flex flex-col items-center ${className}`}>
      <div
        className={`${sizeClass} ${showLabel ? 'mb-2' : ''}`}
        dangerouslySetInnerHTML={{ __html: svgContent }}
      />
      {showLabel && (
        <span className="text-xs font-medium">IGY Token</span>
      )}
    </div>
  );
}