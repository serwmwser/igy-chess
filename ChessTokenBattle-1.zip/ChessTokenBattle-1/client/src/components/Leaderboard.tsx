import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/context/LanguageContext";
import { useWallet } from "@/context/WalletContext";
import { Button } from "@/components/ui/button";

type LeaderboardPlayer = {
  address: string;
  wins: number;
  igyBalance: number;
  rank: number;
};

export default function Leaderboard() {
  const { t } = useLanguage();
  const { walletAddress } = useWallet();
  const [isExpanded, setIsExpanded] = useState(false);

  // Fetch leaderboard data
  const { data: leaderboardData } = useQuery<LeaderboardPlayer[]>({
    queryKey: ['/api/leaderboard'],
  });

  // Display top 3 players by default, or all if expanded
  const displayPlayers = leaderboardData 
    ? (isExpanded ? leaderboardData : leaderboardData.slice(0, 3))
    : [];

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h3 className="font-montserrat font-semibold mb-3">{t("leaderboard.title")}</h3>
      
      <div className="space-y-2">
        {displayPlayers.length > 0 ? (
          displayPlayers.map((player) => (
            <div className="flex items-center p-2 bg-gray-50 rounded" key={player.address}>
              <div className={`w-8 h-8 flex items-center justify-center rounded-full mr-3 font-semibold ${
                player.rank === 1 
                  ? "bg-secondary text-white" 
                  : player.rank === 2 
                    ? "bg-gray-300 text-gray-700" 
                    : player.rank === 3 
                      ? "bg-amber-600 text-white"
                      : "bg-gray-200 text-gray-700"
              }`}>
                {player.rank}
              </div>
              <div className="flex-1">
                <div className={`font-semibold truncate ${player.address === walletAddress ? "text-secondary" : ""}`}>
                  {player.address.substring(0, 6)}...{player.address.substring(player.address.length - 4)}
                </div>
                <div className="flex text-xs text-gray-500">
                  <span className="mr-2">{t("leaderboard.wins")}: {player.wins}</span>
                  <span>IGY: {player.igyBalance.toFixed(1)}</span>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-4 text-gray-500">
            {t("leaderboard.loading")}
          </div>
        )}
      </div>
      
      <div className="mt-3 text-center">
        <Button 
          variant="link" 
          className="text-primary text-sm"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          {isExpanded ? t("leaderboard.showLess") : t("leaderboard.viewFull")}
        </Button>
      </div>
    </div>
  );
}
