import { useState, useEffect } from 'react';
import { useWallet } from '@/context/WalletContext';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { formatDistanceToNow } from 'date-fns';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { CheckIcon, CoinsIcon, TrophyIcon, SwordIcon, CalendarIcon } from 'lucide-react';

type DailyTask = {
  id: number;
  title: string;
  description: string;
  rewardAmount: number;
  taskType: string;
  requiredCount: number;
  active: boolean;
  progress: {
    currentCount: number;
    completed: boolean;
    completedAt: string | null;
  };
};

export default function DailyTasks() {
  const { walletAddress } = useWallet();
  const { toast } = useToast();
  
  const [tasks, setTasks] = useState<DailyTask[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [userId, setUserId] = useState<number | null>(null);

  // Fetch user and tasks
  useEffect(() => {
    const fetchUserAndTasks = async () => {
      if (!walletAddress) return;
      
      setIsLoading(true);
      try {
        // Get user info first to get user ID
        const userData = await apiRequest<any>(`/api/users/${walletAddress}`);
        if (userData && userData.id) {
          setUserId(userData.id);
          
          // Then fetch task progress using user ID
          const tasksData = await apiRequest<DailyTask[]>(`/api/users/${userData.id}/daily-tasks/progress`);
          setTasks(tasksData || []);
        }
      } catch (error) {
        console.error('Error fetching tasks:', error);
        toast({
          title: 'Error',
          description: 'Failed to load daily tasks. Please try again.',
          variant: 'destructive'
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchUserAndTasks();
  }, [walletAddress, toast]);

  // Complete a task (for "click to complete" type tasks)
  const completeTask = async (taskId: number) => {
    if (!userId) return;
    
    try {
      const response = await apiRequest(`/api/users/${userId}/daily-tasks/${taskId}/complete`, {
        method: 'POST'
      });
      
      if (response && response.success) {
        // Update local task state
        setTasks(prev => prev.map(task => {
          if (task.id === taskId) {
            return {
              ...task,
              progress: {
                ...task.progress,
                currentCount: task.requiredCount,
                completed: true,
                completedAt: new Date().toISOString()
              }
            };
          }
          return task;
        }));
        
        toast({
          title: 'Task Completed',
          description: `You've received ${response.task.rewardAmount} IGY tokens!`,
          variant: 'default'
        });
      }
    } catch (error) {
      console.error('Error completing task:', error);
      toast({
        title: 'Error',
        description: 'Failed to complete task. Please try again.',
        variant: 'destructive'
      });
    }
  };

  // Get task icon based on task type
  const getTaskIcon = (taskType: string) => {
    switch (taskType) {
      case 'win_game':
        return <TrophyIcon className="h-5 w-5 text-yellow-500" />;
      case 'play_game':
        return <SwordIcon className="h-5 w-5 text-blue-500" />;
      case 'login':
        return <CalendarIcon className="h-5 w-5 text-green-500" />;
      default:
        return <CoinsIcon className="h-5 w-5 text-amber-500" />;
    }
  };

  if (!walletAddress) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Daily Tasks</CardTitle>
          <CardDescription>Connect your wallet to see daily tasks</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CoinsIcon className="h-5 w-5 text-amber-500" />
          Daily Tasks
        </CardTitle>
        <CardDescription>Complete tasks to earn IGY tokens</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="py-8 text-center">Loading tasks...</div>
        ) : tasks.length === 0 ? (
          <div className="py-8 text-center">No tasks available today</div>
        ) : (
          <div className="space-y-4">
            {tasks.map((task) => (
              <Card key={task.id} className="overflow-hidden">
                <div className={`p-4 ${task.progress.completed ? 'bg-green-50 dark:bg-green-950' : ''}`}>
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-2">
                      {getTaskIcon(task.taskType)}
                      <h3 className="font-medium">{task.title}</h3>
                    </div>
                    <Badge variant="outline">
                      <CoinsIcon className="h-3 w-3 mr-1 text-amber-500" />
                      {task.rewardAmount} IGY
                    </Badge>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-3">{task.description}</p>
                  
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs text-muted-foreground">
                      Progress: {task.progress.currentCount} / {task.requiredCount}
                    </span>
                    {task.progress.completed && (
                      <span className="text-xs text-green-600 dark:text-green-400 flex items-center">
                        <CheckIcon className="h-3 w-3 mr-1" />
                        {task.progress.completedAt ? (
                          `Completed ${formatDistanceToNow(new Date(task.progress.completedAt), { addSuffix: true })}`
                        ) : (
                          'Completed'
                        )}
                      </span>
                    )}
                  </div>
                  
                  <Progress 
                    value={(task.progress.currentCount / task.requiredCount) * 100}
                    className={task.progress.completed ? 'bg-green-100 dark:bg-green-900' : ''}
                  />
                  
                  {/* For manual completion tasks, show complete button */}
                  {task.taskType === 'manual' && !task.progress.completed && (
                    <Button 
                      className="w-full mt-3"
                      onClick={() => completeTask(task.id)}
                    >
                      Complete Task
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}