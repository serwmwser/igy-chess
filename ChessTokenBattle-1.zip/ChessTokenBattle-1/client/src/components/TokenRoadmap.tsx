import { useLanguage } from "@/context/LanguageContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CoinsIcon, TrendingUp, Calendar, Users, Globe, Rocket } from "lucide-react";

export default function TokenRoadmap() {
  const { t } = useLanguage();

  const roadmapItems = [
    {
      id: 1,
      title: "Запуск IGY токена",
      date: "Q1 2024",
      description: "Запуск токена IGY внутри приложения шахмат. Доступен только для пользователей игры.",
      icon: <CoinsIcon className="h-8 w-8 text-indigo-500" />,
      status: "completed"
    },
    {
      id: 2,
      title: "Расширение пользовательской базы",
      date: "Q2-Q4 2024",
      description: "Увеличение базы пользователей до 10,000. Создание экосистемы вокруг IGY токена в приложении.",
      icon: <Users className="h-8 w-8 text-indigo-500" />,
      status: "active"
    },
    {
      id: 3,
      title: "Рост пользовательской базы",
      date: "Q1-Q4 2025",
      description: "Расширение до 100,000 активных пользователей. Подготовка к листингу на биржах.",
      icon: <TrendingUp className="h-8 w-8 text-indigo-500" />,
      status: "upcoming"
    },
    {
      id: 4,
      title: "Выход на биржи",
      date: "Q4 2025 / Q1 2026",
      description: "Официальный листинг токена IGY на криптовалютных биржах. Потенциальный рост стоимости в десятки раз.",
      icon: <Globe className="h-8 w-8 text-indigo-500" />,
      status: "upcoming"
    },
    {
      id: 5,
      title: "IGY Ecosystem Expansion",
      date: "2026+",
      description: "Расширение использования IGY за пределы шахматной платформы. Новые партнерства и интеграции.",
      icon: <Rocket className="h-8 w-8 text-indigo-500" />,
      status: "upcoming"
    }
  ];

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-indigo-100">
      <CardHeader className="relative pb-2">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/10 to-violet-500/10 rounded-t-lg"></div>
        <div className="relative">
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
            {t("tokens.roadmap.title") || "Дорожная карта токена IGY"}
          </CardTitle>
          <CardDescription className="text-base opacity-90">
            {t("tokens.roadmap.subtitle") || "Стратегия развития и потенциал роста стоимости"}
          </CardDescription>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-8 py-4">
          <div className="relative">
            {/* Timeline connector */}
            <div className="absolute left-4 top-0 bottom-0 w-[2px] bg-gradient-to-b from-indigo-300 to-violet-400"></div>
            
            {roadmapItems.map((item) => (
              <div key={item.id} className="relative mb-12 last:mb-0 pl-14">
                {/* Timeline dot */}
                <div className={`absolute left-0 top-0 h-10 w-10 rounded-full flex items-center justify-center ${
                  item.status === "completed" 
                    ? "bg-gradient-to-br from-green-100 to-green-200 border-2 border-green-400" 
                    : item.status === "active"
                      ? "bg-gradient-to-br from-blue-100 to-blue-200 border-2 border-blue-400"
                      : "bg-gradient-to-br from-gray-100 to-gray-200 border-2 border-gray-300"
                }`}>
                  {item.icon}
                </div>
                
                <div className="bg-white rounded-lg p-4 shadow-sm border border-indigo-50">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{item.title}</h3>
                    <div className="bg-indigo-100 text-indigo-800 text-sm px-2 py-1 rounded-full">
                      {item.date}
                    </div>
                  </div>
                  <p className="text-gray-600 mb-3">{item.description}</p>
                  
                  {item.status === "completed" && (
                    <div className="flex items-center text-sm text-green-600">
                      <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mr-2">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                      Завершено
                    </div>
                  )}
                  
                  {item.status === "active" && (
                    <div className="flex items-center text-sm text-blue-600">
                      <div className="h-5 w-5 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                        </svg>
                      </div>
                      В процессе
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="mt-6 bg-gradient-to-r from-indigo-100 to-purple-100 p-4 rounded-lg border border-indigo-200">
          <h3 className="font-semibold text-indigo-800 mb-2">Потенциал роста</h3>
          <p className="text-gray-700 mb-3">
            Текущая возможность приобрести IGY токен только через наше приложение создает уникальный потенциал для инвесторов. 
            При выходе на биржи в конце 2025 или начале 2026 года и достижении 100,000 пользователей, стоимость токена может 
            <span className="font-bold text-indigo-800"> вырасти в десятки раз</span> от текущей.
          </p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
            <div className="flex items-center justify-center bg-white rounded-lg p-3 border border-indigo-200">
              <div className="flex flex-col items-center">
                <span className="text-xs text-gray-500 uppercase tracking-wide">Общее количество токенов</span>
                <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
                  10 000 000 IGY
                </span>
                <div className="text-xs text-gray-500 mt-1">Ограниченная эмиссия</div>
              </div>
            </div>
            
            <div className="flex items-center justify-center bg-white rounded-lg p-3 border border-indigo-200">
              <div className="flex flex-col items-center">
                <span className="text-xs text-gray-500 uppercase tracking-wide">Выход на биржи</span>
                <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
                  Q4 2025 / Q1 2026
                </span>
                <div className="text-xs text-gray-500 mt-1">При достижении 100 000 пользователей</div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg p-4 mb-4 border border-indigo-200">
            <h3 className="font-semibold text-indigo-800 mb-2 flex items-center">
              <Users className="h-5 w-5 mr-2 text-indigo-500" />
              Реферальная программа
            </h3>
            <div className="space-y-3">
              <div className="flex items-start">
                <div className="bg-indigo-100 rounded-full h-6 w-6 flex items-center justify-center text-indigo-800 font-semibold text-sm mr-3 mt-0.5">1</div>
                <p className="text-sm text-gray-700">
                  За каждых 10 приглашенных людей по индивидуальной ссылке вы получаете <span className="font-bold text-indigo-700">+1 IGY токен</span>
                </p>
              </div>
              <div className="flex items-start">
                <div className="bg-indigo-100 rounded-full h-6 w-6 flex items-center justify-center text-indigo-800 font-semibold text-sm mr-3 mt-0.5">2</div>
                <p className="text-sm text-gray-700">
                  Условие: не менее 10 приглашенных пользователей должны приобрести минимум по 1 токену
                </p>
              </div>
              <div className="flex items-start">
                <div className="bg-indigo-100 rounded-full h-6 w-6 flex items-center justify-center text-indigo-800 font-semibold text-sm mr-3 mt-0.5">3</div>
                <p className="text-sm text-gray-700">
                  При покупке вами токенов, вы получаете <span className="font-bold text-indigo-700">+1 бонусный IGY токен</span>
                </p>
              </div>
            </div>
          </div>
          
          <Button className="w-full bg-gradient-to-r from-indigo-600 to-violet-600">
            <CoinsIcon className="mr-2 h-4 w-4" /> Купить IGY токен сейчас
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}