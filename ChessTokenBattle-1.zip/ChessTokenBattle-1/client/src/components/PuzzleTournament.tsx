import { useState, useEffect } from "react";
import { useWallet } from "@/context/WalletContext";
import { useLanguage } from "@/context/LanguageContext";
import { Chessboard } from "react-chessboard";
import { Chess } from "chess.js";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { formatTime } from "@/lib/utils";
import { FaClock, FaTrophy, FaUsers, FaCoins } from "react-icons/fa";
import { useGameSocket } from "@/hooks/useGameSocket";

// Тип для информации о шахматной задаче
type Puzzle = {
  id: string;
  fen: string;
  moves: string[];
  rating: number;
  themes: string[];
  solution: string[];
};

// Тип для информации о турнире
type TournamentInfo = {
  id: string;
  name: string;
  status: "waiting" | "active" | "completed";
  puzzleCount: number;
  currentPuzzleIndex: number;
  startTime?: number;
  endTime?: number;
  timeLimit: number; // в секундах
  entryFee: number;
  participants: TournamentParticipant[];
};

// Тип для информации об участнике турнира
type TournamentParticipant = {
  address: string;
  score: number;
  currentPuzzleIndex: number;
  solveTime: number;
  isActive: boolean;
};

export default function PuzzleTournament() {
  const { t } = useLanguage();
  const { walletAddress, igyBalance } = useWallet();
  const socket = useGameSocket();
  const { toast } = useToast();
  
  const [currentPuzzle, setCurrentPuzzle] = useState<Puzzle | null>(null);
  const [tournamentInfo, setTournamentInfo] = useState<TournamentInfo | null>(null);
  const [game, setGame] = useState(new Chess());
  const [loading, setLoading] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [userAnswer, setUserAnswer] = useState("");
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [isWaiting, setIsWaiting] = useState(true);
  
  // Подключение к турниру
  useEffect(() => {
    if (!socket || !walletAddress) return;
    
    const handleSocketMessage = (event: MessageEvent) => {
      try {
        const data = JSON.parse(event.data);
        
        switch (data.type) {
          case 'tournamentUpdate':
            setTournamentInfo(data.tournament);
            break;
            
          case 'puzzleUpdate':
            setCurrentPuzzle(data.puzzle);
            if (data.puzzle) {
              try {
                const newGame = new Chess(data.puzzle.fen);
                setGame(newGame);
                // Сбросить состояние проверки при получении новой задачи
                setIsCorrect(null);
                setUserAnswer("");
              } catch (error) {
                console.error("Invalid FEN:", error);
              }
            }
            break;
            
          case 'tournamentStart':
            setIsWaiting(false);
            setTimeRemaining(data.timeLimit || 600);
            toast({
              title: t("tournament.started"),
              description: t("tournament.goodLuck"),
            });
            break;
            
          case 'tournamentEnd':
            setIsWaiting(true);
            toast({
              title: t("tournament.ended"),
              description: data.winner === walletAddress 
                ? t("tournament.youWon") 
                : t("tournament.betterLuckNextTime"),
            });
            
            // Если пользователь победил
            if (data.winner === walletAddress) {
              toast({
                title: t("tournament.congratulations"),
                description: t("tournament.prizeClaimed", { amount: data.prize }),
                variant: "success"
              });
            }
            break;
            
          case 'puzzleResult':
            setIsCorrect(data.correct);
            if (data.correct) {
              toast({
                title: t("puzzle.correct"),
                description: t("puzzle.pointsEarned", { points: data.points }),
                variant: "success"
              });
            } else {
              toast({
                title: t("puzzle.incorrect"),
                description: t("puzzle.correctSolution", { solution: data.solution }),
                variant: "destructive"
              });
            }
            
            // Перейти к следующей задаче через 2 секунды
            setTimeout(() => {
              if (data.nextPuzzle) {
                try {
                  const newGame = new Chess(data.nextPuzzle.fen);
                  setGame(newGame);
                  setCurrentPuzzle(data.nextPuzzle);
                  setIsCorrect(null);
                  setUserAnswer("");
                } catch (error) {
                  console.error("Invalid FEN:", error);
                }
              }
            }, 2000);
            break;
            
          case 'error':
            toast({
              title: t("errors.error"),
              description: data.message,
              variant: "destructive"
            });
            break;
        }
      } catch (error) {
        console.error('Error handling websocket message:', error);
      }
    };
    
    socket.addEventListener('message', handleSocketMessage);
    
    return () => {
      socket.removeEventListener('message', handleSocketMessage);
    };
  }, [socket, walletAddress, toast, t]);
  
  // Таймер обратного отсчета
  useEffect(() => {
    if (isWaiting || timeRemaining <= 0) return;
    
    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [isWaiting, timeRemaining]);
  
  // Присоединиться к турниру
  const joinTournament = () => {
    if (!socket || !walletAddress) return;
    
    if (igyBalance < 1) {
      toast({
        title: t("errors.insufficientBalance"),
        description: t("errors.needMinTokens", { amount: 1 }),
        variant: "destructive"
      });
      return;
    }
    
    setLoading(true);
    
    socket.send(JSON.stringify({
      type: 'joinTournament',
      address: walletAddress
    }));
    
    setLoading(false);
  };
  
  // Отправить решение задачи
  const submitSolution = (move: string) => {
    if (!socket || !walletAddress || !currentPuzzle || isWaiting) return;
    
    setUserAnswer(move);
    
    socket.send(JSON.stringify({
      type: 'submitPuzzleSolution',
      address: walletAddress,
      puzzleId: currentPuzzle.id,
      move
    }));
  };
  
  // Попробовать сделать ход
  const onDrop = (sourceSquare: string, targetSquare: string) => {
    if (isWaiting || isCorrect !== null) return false;
    
    try {
      const move = game.move({
        from: sourceSquare,
        to: targetSquare,
        promotion: 'q' // Всегда повышать до ферзя для простоты
      });
      
      if (move === null) return false;
      
      setGame(new Chess(game.fen()));
      
      // Отправить решение
      submitSolution(`${sourceSquare}${targetSquare}`);
      
      return true;
    } catch (error) {
      return false;
    }
  };
  
  // Форматирование списка участников по рейтингу
  const sortedParticipants = tournamentInfo?.participants.slice()
    .sort((a, b) => b.score - a.score);
  
  // Если идет ожидание начала турнира
  if (isWaiting) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">{t("tournament.puzzleTournament")}</h2>
          {tournamentInfo && (
            <div className="flex items-center gap-2 bg-primary/10 text-primary px-3 py-1 rounded-full">
              <FaUsers />
              <span>{tournamentInfo.participants.length} {t("tournament.participants")}</span>
            </div>
          )}
        </div>
        
        <div className="text-center py-8">
          {tournamentInfo ? (
            <>
              <FaTrophy className="w-16 h-16 mx-auto text-amber-500 mb-4" />
              <h3 className="text-xl font-semibold mb-2">{tournamentInfo.name}</h3>
              <p className="mb-4 text-gray-600">{t("tournament.waitingToStart")}</p>
              <div className="flex items-center justify-center gap-3 mb-6">
                <div className="flex items-center bg-amber-100 text-amber-700 px-3 py-1 rounded-full">
                  <FaCoins className="mr-2" />
                  <span>{tournamentInfo.entryFee} IGY</span>
                </div>
                <div className="flex items-center bg-blue-100 text-blue-700 px-3 py-1 rounded-full">
                  <FaClock className="mr-2" />
                  <span>{tournamentInfo.puzzleCount} {t("tournament.puzzles")}</span>
                </div>
              </div>
              
              {/* Список участников */}
              <div className="bg-gray-50 rounded-lg p-4 mb-6">
                <h4 className="font-semibold mb-3">{t("tournament.participants")}</h4>
                <div className="grid grid-cols-1 gap-2 max-h-40 overflow-y-auto">
                  {sortedParticipants?.map((participant, index) => (
                    <div 
                      key={participant.address} 
                      className={`flex items-center justify-between py-2 px-3 rounded ${participant.address === walletAddress ? 'bg-blue-50' : ''}`}
                    >
                      <div className="flex items-center">
                        <span className="font-mono mr-2">{index + 1}.</span>
                        <span className="truncate max-w-[120px]">
                          {participant.address.substring(0, 6)}...{participant.address.substring(participant.address.length - 4)}
                          {participant.address === walletAddress && ` (${t("tournament.you")})`}
                        </span>
                      </div>
                      <span className="font-semibold">{participant.score}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              {tournamentInfo.participants.find(p => p.address === walletAddress) ? (
                <p className="text-green-600 font-medium">{t("tournament.youAreRegistered")}</p>
              ) : (
                <Button 
                  onClick={joinTournament} 
                  disabled={loading || igyBalance < 1}
                  className="w-full"
                >
                  {loading ? t("common.loading") : t("tournament.joinTournament")}
                </Button>
              )}
            </>
          ) : (
            <>
              <Skeleton className="h-16 w-16 rounded-full mx-auto mb-4" />
              <Skeleton className="h-6 w-48 mx-auto mb-2" />
              <Skeleton className="h-4 w-64 mx-auto mb-6" />
              <Skeleton className="h-10 w-32 mx-auto" />
            </>
          )}
        </div>
      </div>
    );
  }
  
  // Если турнир активен
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Панель информации */}
        <div className="lg:order-1 lg:col-span-1">
          <div className="mb-4">
            <h2 className="text-xl font-bold mb-2">{tournamentInfo?.name || t("tournament.puzzleTournament")}</h2>
            <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3 mb-4">
              <div className="flex items-center">
                <FaClock className="mr-2 text-gray-600" />
                <span>{formatTime(timeRemaining)}</span>
              </div>
              <div className="font-semibold">
                {tournamentInfo?.currentPuzzleIndex}/{tournamentInfo?.puzzleCount} {t("tournament.puzzles")}
              </div>
            </div>
            
            {/* Прогресс решения задач */}
            <Progress 
              value={(tournamentInfo?.currentPuzzleIndex || 0) / (tournamentInfo?.puzzleCount || 1) * 100} 
              className="h-2 mb-4"
            />
            
            {/* Информация о текущей задаче */}
            {currentPuzzle && (
              <div className="bg-gray-50 rounded-lg p-3 mb-4">
                <h3 className="font-semibold mb-2">{t("puzzle.puzzle")} #{tournamentInfo?.currentPuzzleIndex}</h3>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">{t("puzzle.rating")}:</span>
                  <span className="font-mono">{currentPuzzle.rating}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">{t("puzzle.themes")}:</span>
                  <span className="font-mono">{currentPuzzle.themes.join(', ')}</span>
                </div>
              </div>
            )}
            
            {/* Таблица лидеров */}
            <div className="bg-gray-50 rounded-lg p-3">
              <h3 className="font-semibold mb-2">{t("tournament.leaderboard")}</h3>
              <div className="max-h-48 overflow-y-auto">
                {sortedParticipants?.map((participant, index) => (
                  <div 
                    key={participant.address} 
                    className={`flex items-center justify-between py-2 border-b border-gray-200 last:border-b-0 ${participant.address === walletAddress ? 'font-semibold' : ''}`}
                  >
                    <div className="flex items-center">
                      <span className="mr-2">{index + 1}.</span>
                      <span className="truncate max-w-[100px]">
                        {participant.address.substring(0, 6)}...{participant.address.substring(participant.address.length - 4)}
                        {participant.address === walletAddress && ` (${t("tournament.you")})`}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <span className="bg-green-100 text-green-800 px-2 py-0.5 rounded-full text-xs mr-2">
                        {participant.currentPuzzleIndex}/{tournamentInfo?.puzzleCount}
                      </span>
                      <span className="font-mono">{participant.score}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Шахматная доска */}
        <div className="lg:order-0 lg:col-span-2">
          <div className="aspect-square max-w-md mx-auto">
            <Chessboard 
              position={game.fen()}
              onPieceDrop={onDrop}
              boardOrientation={game.turn() === 'w' ? 'white' : 'black'}
              customBoardStyle={{
                borderRadius: '4px',
                boxShadow: '0 2px 10px rgba(0, 0, 0, 0.2)',
              }}
            />
          </div>
          
          {/* Результат ответа */}
          {isCorrect !== null && (
            <div className={`mt-4 p-3 rounded-lg text-center ${isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
              {isCorrect 
                ? t("puzzle.correctSolution") 
                : t("puzzle.incorrectSolution")}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}