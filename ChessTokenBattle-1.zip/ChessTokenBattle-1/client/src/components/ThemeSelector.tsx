import { useState, useEffect } from 'react';
import { useWallet } from '@/context/WalletContext';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useQueryClient } from '@tanstack/react-query';

type Theme = {
  id: number;
  name: string;
  displayName: string;
  description: string | null;
  previewImage: string | null;
  isPremium: boolean;
  price: number;
  // Board-specific
  primaryColor?: string;
  secondaryColor?: string;
  // Piece-specific
  folderPath?: string;
};

export default function ThemeSelector() {
  const { walletAddress, igyBalance } = useWallet();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [boardThemes, setBoardThemes] = useState<Theme[]>([]);
  const [pieceThemes, setPieceThemes] = useState<Theme[]>([]);
  const [selectedBoardTheme, setSelectedBoardTheme] = useState<string | null>(null);
  const [selectedPieceTheme, setSelectedPieceTheme] = useState<string | null>(null);
  const [isPurchasing, setIsPurchasing] = useState(false);

  // Fetch themes
  useEffect(() => {
    const fetchThemes = async () => {
      try {
        const [boardData, pieceData, userData] = await Promise.all([
          apiRequest<Theme[]>('/api/themes/board'),
          apiRequest<Theme[]>('/api/themes/piece'),
          apiRequest<any>(`/api/users/${walletAddress}`)
        ]);
        
        setBoardThemes(boardData);
        setPieceThemes(pieceData);
        
        if (userData?.preferences) {
          setSelectedBoardTheme(userData.preferences.boardTheme || 'standard');
          setSelectedPieceTheme(userData.preferences.pieceTheme || 'standard');
        } else {
          setSelectedBoardTheme('standard');
          setSelectedPieceTheme('standard');
        }
      } catch (error) {
        console.error('Error fetching themes:', error);
        toast({
          title: 'Error',
          description: 'Failed to load themes. Please try again.',
          variant: 'destructive'
        });
      }
    };
    
    if (walletAddress) {
      fetchThemes();
    }
  }, [walletAddress, toast]);

  // Handle theme selection
  const selectTheme = async (type: 'board' | 'piece', theme: Theme) => {
    if (!walletAddress) return;
    
    // If theme is premium and not already selected, handle purchase flow
    if (theme.isPremium && 
        ((type === 'board' && selectedBoardTheme !== theme.name) || 
         (type === 'piece' && selectedPieceTheme !== theme.name))) {
      
      // Check if user has enough IGY
      if (igyBalance < theme.price) {
        return toast({
          title: 'Insufficient IGY Balance',
          description: `You need ${theme.price} IGY to purchase this theme.`,
          variant: 'destructive'
        });
      }
      
      // Confirm purchase
      if (!window.confirm(`Purchase ${theme.displayName} for ${theme.price} IGY?`)) {
        return;
      }
      
      setIsPurchasing(true);
      
      try {
        const response = await apiRequest('/api/users/' + walletAddress + '/themes/purchase', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            themeType: type,
            themeId: theme.id
          })
        });
        
        if (response.success) {
          if (type === 'board') {
            setSelectedBoardTheme(theme.name);
          } else {
            setSelectedPieceTheme(theme.name);
          }
          
          toast({
            title: 'Purchase Successful',
            description: `You've purchased the ${theme.displayName} theme.`,
            variant: 'default'
          });
          
          // Invalidate queries to refresh user data
          queryClient.invalidateQueries({ queryKey: [`/api/users/${walletAddress}`] });
        }
      } catch (error) {
        console.error('Error purchasing theme:', error);
        toast({
          title: 'Purchase Failed',
          description: 'Failed to purchase theme. Please try again.',
          variant: 'destructive'
        });
      } finally {
        setIsPurchasing(false);
      }
      return;
    }
    
    // For non-premium or already purchased themes, just update preference
    try {
      await apiRequest('/api/users/' + walletAddress + '/preferences', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          [type === 'board' ? 'boardTheme' : 'pieceTheme']: theme.name
        })
      });
      
      if (type === 'board') {
        setSelectedBoardTheme(theme.name);
      } else {
        setSelectedPieceTheme(theme.name);
      }
      
      toast({
        title: 'Theme Updated',
        description: `Your ${type} theme has been updated to ${theme.displayName}.`,
        variant: 'default'
      });
      
    } catch (error) {
      console.error('Error updating theme preference:', error);
      toast({
        title: 'Update Failed',
        description: 'Failed to update theme preference. Please try again.',
        variant: 'destructive'
      });
    }
  };

  if (!walletAddress) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Theme Selection</CardTitle>
          <CardDescription>Connect your wallet to customize your chess experience</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Customize Your Game</CardTitle>
        <CardDescription>Select your preferred board and piece themes</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="board">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="board">Board Themes</TabsTrigger>
            <TabsTrigger value="piece">Piece Themes</TabsTrigger>
          </TabsList>
          
          <TabsContent value="board" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {boardThemes.map((theme) => (
                <Card 
                  key={theme.id} 
                  className={`overflow-hidden cursor-pointer transition-all hover:shadow-md ${
                    selectedBoardTheme === theme.name ? 'ring-2 ring-primary' : ''
                  }`}
                  onClick={() => selectTheme('board', theme)}
                >
                  <div 
                    className="w-full aspect-square grid grid-cols-8 grid-rows-8"
                    style={{
                      background: `conic-gradient(
                        ${theme.primaryColor} 90deg, 
                        ${theme.secondaryColor} 90deg 180deg,
                        ${theme.primaryColor} 180deg 270deg,
                        ${theme.secondaryColor} 270deg
                      )`,
                      backgroundSize: '25% 25%'
                    }}
                  ></div>
                  <CardFooter className="flex justify-between items-center p-2">
                    <div>
                      <h4 className="text-sm font-medium">{theme.displayName}</h4>
                      {theme.isPremium && (
                        <Badge variant="secondary" className="mt-1">
                          {theme.price} IGY
                        </Badge>
                      )}
                    </div>
                    {selectedBoardTheme === theme.name ? (
                      <Badge variant="default">Selected</Badge>
                    ) : theme.isPremium ? (
                      <Button 
                        variant="outline" 
                        size="sm"
                        disabled={isPurchasing || igyBalance < theme.price}
                      >
                        Purchase
                      </Button>
                    ) : (
                      <Button variant="outline" size="sm">Select</Button>
                    )}
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="piece" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {pieceThemes.map((theme) => (
                <Card 
                  key={theme.id} 
                  className={`overflow-hidden cursor-pointer transition-all hover:shadow-md ${
                    selectedPieceTheme === theme.name ? 'ring-2 ring-primary' : ''
                  }`}
                  onClick={() => selectTheme('piece', theme)}
                >
                  <div className="w-full aspect-square bg-slate-200 flex items-center justify-center">
                    {theme.previewImage ? (
                      <img 
                        src={theme.previewImage} 
                        alt={theme.displayName}
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <div className="grid grid-cols-3 grid-rows-2 gap-2 p-4">
                        <div className="bg-slate-600 w-12 h-12 rounded-full"></div>
                        <div className="bg-slate-600 w-12 h-12 rounded-full"></div>
                        <div className="bg-slate-600 w-12 h-12 rounded-full"></div>
                        <div className="bg-white w-12 h-12 rounded-full border border-slate-300"></div>
                        <div className="bg-white w-12 h-12 rounded-full border border-slate-300"></div>
                        <div className="bg-white w-12 h-12 rounded-full border border-slate-300"></div>
                      </div>
                    )}
                  </div>
                  <CardFooter className="flex justify-between items-center p-2">
                    <div>
                      <h4 className="text-sm font-medium">{theme.displayName}</h4>
                      {theme.isPremium && (
                        <Badge variant="secondary" className="mt-1">
                          {theme.price} IGY
                        </Badge>
                      )}
                    </div>
                    {selectedPieceTheme === theme.name ? (
                      <Badge variant="default">Selected</Badge>
                    ) : theme.isPremium ? (
                      <Button 
                        variant="outline" 
                        size="sm"
                        disabled={isPurchasing || igyBalance < theme.price}
                      >
                        Purchase
                      </Button>
                    ) : (
                      <Button variant="outline" size="sm">Select</Button>
                    )}
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <div>
          <p className="text-sm text-muted-foreground">
            Premium themes require IGY tokens. Your balance: {igyBalance || 0} IGY
          </p>
        </div>
      </CardFooter>
    </Card>
  );
}