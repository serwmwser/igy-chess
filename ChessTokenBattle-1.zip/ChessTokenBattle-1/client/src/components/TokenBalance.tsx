import { useState } from "react";
import { useWallet } from "@/context/WalletContext";
import { useLanguage } from "@/context/LanguageContext";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { purchaseIGYWithPOL } from "@/lib/web3";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger 
} from "@/components/ui/tooltip";
import { InfoIcon, RefreshCw, TrendingUp } from "lucide-react";

// Константы для токенов
const IGY_CONTRACT_ADDRESS = "0x6d278Ec8Bb6FC8d06c081e4688759546CC73eaB8";

export default function TokenBalance() {
  const { walletAddress, igyBalance, updateBalance } = useWallet();
  const { t } = useLanguage();
  const { toast } = useToast();
  
  const [amount, setAmount] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  
  // ABI для ERC20 токена (упрощенная версия)
  const erc20Abi = [
    "function balanceOf(address owner) view returns (uint256)",
    "function transfer(address to, uint256 amount) returns (bool)",
    "function approve(address spender, uint256 amount) returns (bool)",
    "function transferFrom(address sender, address recipient, uint256 amount) returns (bool)"
  ];
  
  const handlePurchase = async () => {
    if (!walletAddress) {
      toast({
        title: t("errors.walletNotConnected"),
        description: t("errors.connectWalletFirst"),
        variant: "destructive"
      });
      return;
    }
    
    if (amount <= 0) {
      toast({
        title: t("errors.invalidAmount"),
        description: t("errors.enterPositiveAmount"),
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Используем функцию из lib/web3 для покупки токенов
      await purchaseIGYWithPOL(amount);
      
      // Обновление баланса
      await updateBalance();
      
      toast({
        title: t("tokens.purchaseSuccess"),
        description: t("tokens.purchaseSuccessDescription", { amount }),
      });
    } catch (error) {
      console.error("Purchase error:", error);
      toast({
        title: t("errors.purchaseFailed"),
        description: typeof error === 'string' ? error : t("errors.transactionFailed"),
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <Card className="bg-gradient-to-br from-violet-50 to-indigo-50 shadow-lg border-indigo-100 overflow-hidden">
      <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-br from-purple-500/20 to-violet-500/10 rounded-full translate-x-20 -translate-y-20 blur-xl"></div>
      
      <CardHeader className="relative">
        <CardTitle className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
          {t("tokens.yourBalance")}
        </CardTitle>
        <CardDescription>
          {t("tokens.balanceDescription")}
        </CardDescription>
        <div className="absolute right-4 top-4">
          <Button 
            size="icon" 
            variant="ghost"
            onClick={updateBalance}
            className="h-8 w-8"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between bg-white p-3 rounded-lg">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-full bg-gradient-to-r from-indigo-600 to-violet-600 flex items-center justify-center text-white font-bold text-sm">
              IGY
            </div>
            <div>
              <h3 className="font-semibold">Ivan Grozny</h3>
              <div className="text-xs text-gray-500">IGY Token</div>
            </div>
          </div>
          <div className="flex flex-col items-end">
            <span className="font-bold text-xl">{igyBalance?.toFixed(2) || "0.00"}</span>
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              <TrendingUp className="mr-1 h-3 w-3" /> 1 IGY = 1 POL
            </Badge>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">{t("tokens.purchaseTokens")}</h3>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <InfoIcon className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p>{t("tokens.purchaseExplanation")}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          
          <div className="flex flex-col md:flex-row gap-3">
            <div className="flex-grow">
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                min="0.1"
                step="0.1"
                className="h-10"
              />
            </div>
            <Button 
              onClick={handlePurchase} 
              disabled={isLoading || !walletAddress}
              className="bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 transition-all duration-300 shadow-md hover:shadow-lg h-10"
            >
              {isLoading ? t("common.loading") : t("tokens.purchaseNow")}
            </Button>
          </div>
          <p className="text-xs text-gray-500">{t("tokens.rateInfo")}</p>
        </div>
      </CardContent>
      
      <CardFooter className="bg-white/50 border-t border-indigo-100/60 text-xs text-gray-600">
        {t("tokens.contractAddress")}: <span className="font-mono ml-1 text-violet-600">{IGY_CONTRACT_ADDRESS.slice(0, 10)}...{IGY_CONTRACT_ADDRESS.slice(-6)}</span>
      </CardFooter>
    </Card>
  );
}