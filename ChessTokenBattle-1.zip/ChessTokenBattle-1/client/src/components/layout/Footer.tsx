import { useLanguage } from "@/context/LanguageContext";
import { FaChessKnight, FaTwitter, FaTelegram, FaDiscord, FaGithub } from "react-icons/fa";

export default function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="mt-auto bg-primary text-white py-6">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <div className="flex items-center justify-center md:justify-start">
              <div className="text-secondary mr-2 text-2xl">
                <FaChessKnight />
              </div>
              <h2 className="font-montserrat font-bold text-xl">IGY Chess</h2>
            </div>
            <p className="text-sm text-gray-300 mt-2 text-center md:text-left">
              {t("footer.tagline")}
            </p>
          </div>
          
          <div className="flex flex-col items-center md:items-end">
            <div className="mb-2">
              <span className="text-sm text-gray-300">{t("footer.igyToken")}: </span>
              <span className="font-mono text-xs">0x6d278Ec8Bb6FC8d06c081e4688759546CC73eaB8</span>
            </div>
            
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-secondary transition-colors">
                <FaTwitter />
              </a>
              <a href="#" className="text-gray-300 hover:text-secondary transition-colors">
                <FaTelegram />
              </a>
              <a href="#" className="text-gray-300 hover:text-secondary transition-colors">
                <FaDiscord />
              </a>
              <a href="#" className="text-gray-300 hover:text-secondary transition-colors">
                <FaGithub />
              </a>
            </div>
          </div>
        </div>
        
        <div className="mt-6 pt-6 border-t border-gray-700 text-center text-xs text-gray-400">
          <p>&copy; {new Date().getFullYear()} IGY Chess. {t("footer.allRightsReserved")}</p>
          <p className="mt-1">
            <a href="#" className="hover:text-secondary transition-colors">{t("footer.terms")}</a>
            <span className="mx-2">•</span>
            <a href="#" className="hover:text-secondary transition-colors">{t("footer.privacy")}</a>
          </p>
        </div>
      </div>
    </footer>
  );
}
