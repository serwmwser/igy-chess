import { useState } from "react";
import { Link } from "wouter";
import { useLanguage } from "@/context/LanguageContext";
import { useWallet } from "@/context/WalletContext";
import { FaChessKnight, FaGlobe, FaBars, FaChevronDown } from "react-icons/fa";

const languages = [
  { code: "en", name: "English" },
  { code: "ru", name: "Русский" },
  { code: "es", name: "Español" },
  { code: "zh", name: "中文" },
  { code: "hi", name: "हिन्दी" },
  { code: "ja", name: "日本語" },
  { code: "fr", name: "Français" },
];

export default function Header() {
  const { t, changeLanguage, currentLanguage } = useLanguage();
  const { isConnected } = useWallet();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex flex-col sm:flex-row justify-between items-center">
        <div className="flex items-center mb-4 sm:mb-0">
          <div className="text-secondary mr-2 text-3xl">
            <FaChessKnight />
          </div>
          <h1 className="font-montserrat font-bold text-2xl">IGY Chess</h1>
        </div>
        
        {/* Desktop menu */}
        <nav className="hidden md:flex items-center space-x-6">
          <Link href="/" className="hover:text-secondary transition-colors">
            {t("header.home")}
          </Link>
          {isConnected && (
            <Link href="/dashboard" className="hover:text-secondary transition-colors">
              {t("header.play")}
            </Link>
          )}
          <Link href="#" className="hover:text-secondary transition-colors">
            {t("header.leaderboard")}
          </Link>
          <Link href="#" className="hover:text-secondary transition-colors">
            {t("header.about")}
          </Link>
          
          {/* Language selector */}
          <div className="relative group">
            <button className="flex items-center hover:text-secondary transition-colors">
              <FaGlobe className="mr-2" />
              <span>{languages.find(lang => lang.code === currentLanguage)?.name || "English"}</span>
              <FaChevronDown className="ml-2 text-xs" />
            </button>
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 text-neutral-dark hidden group-hover:block z-10">
              {languages.map((language) => (
                <a 
                  key={language.code}
                  href="#" 
                  className="block px-4 py-2 hover:bg-gray-100"
                  onClick={(e) => {
                    e.preventDefault();
                    changeLanguage(language.code);
                  }}
                >
                  {language.name}
                </a>
              ))}
            </div>
          </div>
        </nav>
        
        {/* Mobile menu toggle */}
        <div className="md:hidden flex items-center">
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-white focus:outline-none"
          >
            <FaBars className="text-xl" />
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-primary-dark">
          <div className="container mx-auto px-4 py-2 flex flex-col">
            <Link 
              href="/" 
              className="py-2 hover:text-secondary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t("header.home")}
            </Link>
            {isConnected && (
              <Link 
                href="/dashboard" 
                className="py-2 hover:text-secondary transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                {t("header.play")}
              </Link>
            )}
            <Link 
              href="#" 
              className="py-2 hover:text-secondary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t("header.leaderboard")}
            </Link>
            <Link 
              href="#" 
              className="py-2 hover:text-secondary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t("header.about")}
            </Link>
            
            {/* Language selector mobile */}
            <div className="py-2">
              {languages.map((language) => (
                <button 
                  key={language.code}
                  className="flex items-center hover:text-secondary transition-colors mb-2"
                  onClick={() => {
                    changeLanguage(language.code);
                    setMobileMenuOpen(false);
                  }}
                >
                  <FaGlobe className="mr-2" />
                  <span>{language.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
