import { useState } from "react";
import { useLanguage } from "@/context/LanguageContext";
import { useWallet } from "@/context/WalletContext";
import { useGame } from "@/context/GameContext";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { FaClock, FaInfinity, FaRandom, FaUserPlus, FaRobot } from "react-icons/fa";
import { useToast } from "@/hooks/use-toast";
import { VideoIcon } from "lucide-react";

type StartGameModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

type GameTimeMode = "5min" | "15min" | "30min" | "hour" | "unlimited";
type OpponentMode = "random" | "invite" | "ai";

export default function StartGameModal({ isOpen, onClose }: StartGameModalProps) {
  const { t } = useLanguage();
  const { walletAddress, igyBalance } = useWallet();
  const { createGame } = useGame();
  const { toast } = useToast();
  
  const [timeMode, setTimeMode] = useState<GameTimeMode>("hour");
  const [opponentMode, setOpponentMode] = useState<OpponentMode>("random");
  const [videoEnabled, setVideoEnabled] = useState(false);
  const [stakeAmount, setStakeAmount] = useState(1); // Количество токенов для ставки
  const [isStarting, setIsStarting] = useState(false);

  const handleStartGame = async () => {
    if (!walletAddress) {
      toast({
        title: t("errors.walletNotConnected"),
        description: t("errors.connectWalletFirst"),
        variant: "destructive"
      });
      return;
    }

    if (igyBalance < 1 && opponentMode !== "ai") {
      toast({
        title: t("errors.insufficientBalance"),
        description: t("errors.needOneIGY"),
        variant: "destructive"
      });
      return;
    }

    setIsStarting(true);

    try {
      let timeInSeconds;
      switch(timeMode) {
        case "5min":
          timeInSeconds = 300; // 5 минут в секундах
          break;
        case "15min":
          timeInSeconds = 900; // 15 минут в секундах
          break;
        case "30min":
          timeInSeconds = 1800; // 30 минут в секундах
          break;
        case "hour":
          timeInSeconds = 3600; // 1 час в секундах
          break;
        case "unlimited":
          timeInSeconds = 0; // Неограниченное время
          break;
        default:
          timeInSeconds = 3600;
      }
      
      // Для режима AI не требуется соединение с другим игроком
      await createGame({
        timeLimit: timeInSeconds,
        isPublic: opponentMode === "random",
        videoEnabled: videoEnabled && opponentMode !== "ai", // Видеочат не нужен для игры с AI
        opponentMode: opponentMode,
        stakeAmount: stakeAmount
      });
      
      onClose();
      
      let description = "";
      if (opponentMode === "random") {
        description = t("game.lookingForOpponent") || "Ищем соперника онлайн";
      } else if (opponentMode === "invite") {
        description = t("game.inviteSent") || "Ссылка-приглашение готова";
      } else if (opponentMode === "ai") {
        description = t("game.playingWithAI") || "Игра с искусственным интеллектом";
      }
      
      toast({
        title: t("game.gameCreated") || "Игра создана",
        description: description
      });
    } catch (error) {
      toast({
        title: t("errors.gameCreationFailed"),
        description: typeof error === 'string' ? error : t("errors.tryAgain"),
        variant: "destructive"
      });
    } finally {
      setIsStarting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-montserrat font-bold">
            {t("startGame.title")}
          </DialogTitle>
        </DialogHeader>
        
        <div className="py-4">
          <div className="mb-6">
            <h4 className="font-semibold mb-3">{t("startGame.gameMode")}</h4>
            <div className="grid grid-cols-3 gap-2 mb-2">
              <Button
                variant={timeMode === "5min" ? "default" : "outline"}
                className={timeMode === "5min" ? "border-2 border-secondary" : ""}
                onClick={() => setTimeMode("5min")}
                size="sm"
              >
                <FaClock className="mr-1" size={12} />
                5 {t("startGame.minutes")}
              </Button>
              <Button
                variant={timeMode === "15min" ? "default" : "outline"}
                className={timeMode === "15min" ? "border-2 border-secondary" : ""}
                onClick={() => setTimeMode("15min")}
                size="sm"
              >
                <FaClock className="mr-1" size={12} />
                15 {t("startGame.minutes")}
              </Button>
              <Button
                variant={timeMode === "30min" ? "default" : "outline"}
                className={timeMode === "30min" ? "border-2 border-secondary" : ""}
                onClick={() => setTimeMode("30min")}
                size="sm"
              >
                <FaClock className="mr-1" size={12} />
                30 {t("startGame.minutes")}
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant={timeMode === "hour" ? "default" : "outline"}
                className={timeMode === "hour" ? "border-2 border-secondary" : ""}
                onClick={() => setTimeMode("hour")}
              >
                <FaClock className="mr-2" />
                {t("startGame.oneHour")}
              </Button>
              <Button
                variant={timeMode === "unlimited" ? "default" : "outline"}
                className={timeMode === "unlimited" ? "border-2 border-secondary" : ""}
                onClick={() => setTimeMode("unlimited")}
              >
                <FaInfinity className="mr-2" />
                {t("startGame.unlimited")}
              </Button>
            </div>
          </div>
          
          <div className="mb-6">
            <h4 className="font-semibold mb-3">{t("startGame.gameStake")}</h4>
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <span>{t("startGame.stakeAmount")}:</span>
                <div className="font-semibold">{stakeAmount} IGY Token</div>
              </div>
              
              <div className="grid grid-cols-6 gap-2 mb-3">
                {[1, 2, 3, 4, 5, 10].map((amount) => (
                  <Button
                    key={amount}
                    variant={stakeAmount === amount ? "default" : "outline"}
                    className={`${stakeAmount === amount ? "bg-accent hover:bg-accent/90" : ""} h-8 px-2`}
                    onClick={() => setStakeAmount(amount)}
                    disabled={amount > igyBalance}
                    size="sm"
                  >
                    {amount}
                  </Button>
                ))}
              </div>
              
              <div className="text-xs text-gray-500">
                {t("startGame.stakeDescription")}
              </div>
              
              <div className="mt-3 flex items-center text-sm">
                <div className="mr-2 text-accent">
                  <i className="fas fa-info-circle"></i>
                </div>
                <div className="text-gray-600">
                  {t("startGame.yourBalance")}: <span className="font-semibold">{igyBalance?.toFixed(2) || "0.00"} IGY</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mb-6">
            <h4 className="font-semibold mb-3">{t("startGame.findOpponent")}</h4>
            <div className="grid grid-cols-3 gap-2">
              <Button
                variant={opponentMode === "random" ? "default" : "outline"}
                className={opponentMode === "random" ? "" : ""}
                onClick={() => setOpponentMode("random")}
              >
                <FaRandom className="mr-1" />
                {t("startGame.randomMatch") || "Онлайн"}
              </Button>
              <Button
                variant={opponentMode === "invite" ? "default" : "outline"}
                className={`${opponentMode === "invite" ? "bg-secondary hover:bg-secondary/90" : ""}`}
                onClick={() => setOpponentMode("invite")}
              >
                <FaUserPlus className="mr-1" />
                {t("startGame.inviteFriend") || "По ссылке"}
              </Button>
              <Button
                variant={opponentMode === "ai" ? "default" : "outline"}
                className={opponentMode === "ai" ? "bg-indigo-600 hover:bg-indigo-700" : ""}
                onClick={() => setOpponentMode("ai")}
              >
                <FaRobot className="mr-1" />
                {t("startGame.aiOpponent") || "AI"}
              </Button>
            </div>
          </div>
          
          <div className="mb-6">
            <h4 className="font-semibold mb-3">{t("startGame.videoChatOption")}</h4>
            <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <VideoIcon className="text-gray-600" />
              <div className="flex-grow">
                <p className="text-sm font-medium">{t("startGame.enableVideoChat")}</p>
                <p className="text-xs text-gray-500">{t("startGame.videoChatDescription")}</p>
              </div>
              <Switch
                checked={videoEnabled}
                onCheckedChange={setVideoEnabled}
                aria-label={t("startGame.toggleVideoChat")}
              />
            </div>
          </div>
          
          <div className="flex justify-end">
            <Button
              variant="outline"
              onClick={onClose}
              className="mr-2"
            >
              {t("common.cancel")}
            </Button>
            <Button
              onClick={handleStartGame}
              disabled={isStarting || (igyBalance < 1 && opponentMode !== "ai")}
              className="bg-accent hover:bg-accent/90"
            >
              {isStarting ? t("common.loading") : t("startGame.startGame")}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
