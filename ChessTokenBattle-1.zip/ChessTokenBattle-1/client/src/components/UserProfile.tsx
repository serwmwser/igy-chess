import { useWallet } from "@/context/WalletContext";
import { useLanguage } from "@/context/LanguageContext";
import { useQuery } from "@tanstack/react-query";
import { FaUser, FaCopy } from "react-icons/fa";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function UserProfile() {
  const { walletAddress, igyBalance, disconnect } = useWallet();
  const { t } = useLanguage();
  const { toast } = useToast();
  const [inviteLink, setInviteLink] = useState(`${window.location.origin}?invite=${generateRandomInviteCode()}`);

  // Format wallet address for display
  const shortAddress = walletAddress
    ? `${walletAddress.substring(0, 6)}...${walletAddress.substring(walletAddress.length - 4)}`
    : "0x0000...0000";

  // Fetch user stats from API
  const { data: userStats } = useQuery({
    queryKey: [`/api/users/${walletAddress}/stats`],
    enabled: !!walletAddress,
  });

  const stats = userStats || { wins: 0, losses: 0, draws: 0 };

  // Copy invite link to clipboard
  const copyToClipboard = () => {
    navigator.clipboard.writeText(inviteLink);
    toast({
      title: t("invite.copied"),
      description: t("invite.copiedDesc"),
    });
  };

  // Generate new invite link
  const generateNewLink = () => {
    const newInviteCode = generateRandomInviteCode();
    setInviteLink(`${window.location.origin}?invite=${newInviteCode}`);
    toast({
      title: t("invite.generated"),
      description: t("invite.generatedDesc"),
    });
  };

  // Helper function to generate random invite code
  function generateRandomInviteCode() {
    return Math.random().toString(36).substring(2, 10);
  }

  return (
    <div className="lg:col-span-3">
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        {/* User Profile */}
        <div className="flex flex-col items-center pb-4 border-b border-gray-200">
          <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center text-white text-2xl mb-3">
            <FaUser />
          </div>
          
          <div className="text-center">
            <p className="text-sm text-gray-500 mb-1">{t("profile.walletAddress")}</p>
            <p className="font-mono text-xs mb-3 truncate">{shortAddress}</p>
            
            <div className="flex items-center justify-center bg-gray-100 rounded-full px-3 py-1">
              <span className="h-2 w-2 bg-green-500 rounded-full mr-2"></span>
              <span className="text-sm">{t("profile.connected")}</span>
            </div>

            <Button 
              variant="outline" 
              size="sm" 
              className="mt-3" 
              onClick={disconnect}
            >
              {t("profile.disconnect")}
            </Button>
          </div>
        </div>
        
        {/* Token Balance */}
        <div className="py-4 border-b border-gray-200">
          <h3 className="font-montserrat font-semibold mb-3">{t("profile.yourBalance")}</h3>
          
          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center mr-2 text-white">
                <FaUser className="text-sm" />
              </div>
              <span>IGY</span>
            </div>
            <div className="font-semibold">{igyBalance?.toFixed(2) || "0.00"}</div>
          </div>
          
          <div className="text-xs text-gray-500 mt-2">
            {t("profile.igyTokenAddress")}: <span className="font-mono">0x6d27...eaB8</span>
          </div>
        </div>
        
        {/* Stats */}
        <div className="py-4">
          <h3 className="font-montserrat font-semibold mb-3">{t("profile.gameStats")}</h3>
          
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="bg-gray-50 p-2 rounded">
              <div className="text-xl font-semibold text-primary">{stats.wins}</div>
              <div className="text-xs text-gray-500">{t("profile.wins")}</div>
            </div>
            
            <div className="bg-gray-50 p-2 rounded">
              <div className="text-xl font-semibold text-error">{stats.losses}</div>
              <div className="text-xs text-gray-500">{t("profile.losses")}</div>
            </div>
            
            <div className="bg-gray-50 p-2 rounded">
              <div className="text-xl font-semibold text-gray-700">{stats.draws}</div>
              <div className="text-xs text-gray-500">{t("profile.draws")}</div>
            </div>
          </div>
          
          <div className="mt-4 text-center">
            <Button variant="link" className="text-primary text-sm">
              {t("profile.viewHistory")}
            </Button>
          </div>
        </div>
      </div>
      
      {/* Invite Section */}
      <div className="bg-white rounded-lg shadow-md p-4">
        <h3 className="font-montserrat font-semibold mb-3">{t("invite.inviteFriends")}</h3>
        
        <p className="text-sm text-gray-600 mb-3">{t("invite.generateLink")}</p>
        
        <div className="relative">
          <input 
            type="text" 
            className="w-full border border-gray-300 rounded-lg py-2 px-3 pr-10 font-mono text-xs" 
            value={inviteLink} 
            readOnly 
          />
          <button 
            className="absolute right-2 top-1.5 text-primary hover:text-secondary transition-colors" 
            title={t("invite.copyToClipboard")}
            onClick={copyToClipboard}
          >
            <FaCopy />
          </button>
        </div>
        
        <Button 
          className="w-full mt-3 bg-primary hover:bg-opacity-90"
          onClick={generateNewLink}
        >
          {t("invite.generateNewLink")}
        </Button>
      </div>
    </div>
  );
}
