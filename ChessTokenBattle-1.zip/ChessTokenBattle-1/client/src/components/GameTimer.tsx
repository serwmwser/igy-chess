import { useState, useEffect } from "react";
import { useWallet } from "@/context/WalletContext";
import { useGame } from "@/context/GameContext";
import { useLanguage } from "@/context/LanguageContext";
import { FaClock } from "react-icons/fa";
import { Progress } from "@/components/ui/progress";
import { formatTime } from "@/lib/utils";
import { Chess } from "chess.js";
import { useGameSocket } from "@/hooks/useGameSocket";

export default function GameTimer() {
  const { t } = useLanguage();
  const { walletAddress } = useWallet();
  const { gameState } = useGame();
  const socket = useGameSocket();
  
  const [whiteTimeRemaining, setWhiteTimeRemaining] = useState<number>(0);
  const [blackTimeRemaining, setBlackTimeRemaining] = useState<number>(0);
  const [activeTimer, setActiveTimer] = useState<'white' | 'black' | null>(null);

  // Initialize timer when game state changes
  useEffect(() => {
    if (!gameState || gameState.timeLimit === 0) {
      return; // No timer for unlimited games
    }

    // Initialize both timers with the full time limit
    const timeLimit = gameState.timeLimit;
    setWhiteTimeRemaining(timeLimit);
    setBlackTimeRemaining(timeLimit);

    // Determine the current player's turn from FEN
    if (gameState.status === "active") {
      try {
        const chess = new Chess(gameState.fen);
        setActiveTimer(chess.turn() === 'w' ? 'white' : 'black');
      } catch (error) {
        console.error("Invalid FEN:", error);
      }
    } else {
      setActiveTimer(null); // Game not active
    }
  }, [gameState?.id, gameState?.timeLimit, gameState?.fen, gameState?.status]);

  // Timer countdown effect
  useEffect(() => {
    if (
      !gameState || 
      gameState.timeLimit === 0 || 
      gameState.status !== "active" || 
      !activeTimer || 
      !socket
    ) {
      return;
    }

    let interval: number;
    
    if (activeTimer === 'white') {
      interval = window.setInterval(() => {
        setWhiteTimeRemaining(prev => {
          if (prev <= 1) {
            // Time's up - handle timeout
            if (gameState.playerWhite === walletAddress) {
              socket.send(JSON.stringify({
                type: 'timeOut',
                gameId: gameState.id,
                player: walletAddress
              }));
            }
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (activeTimer === 'black') {
      interval = window.setInterval(() => {
        setBlackTimeRemaining(prev => {
          if (prev <= 1) {
            // Time's up - handle timeout
            if (gameState.playerBlack === walletAddress) {
              socket.send(JSON.stringify({
                type: 'timeOut',
                gameId: gameState.id,
                player: walletAddress
              }));
            }
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [activeTimer, gameState, walletAddress, socket]);

  // Update active timer when the game state changes (after a move)
  useEffect(() => {
    if (!gameState || gameState.timeLimit === 0 || gameState.status !== "active") {
      return;
    }

    try {
      const chess = new Chess(gameState.fen);
      setActiveTimer(chess.turn() === 'w' ? 'white' : 'black');
    } catch (error) {
      console.error("Invalid FEN:", error);
    }
  }, [gameState?.fen]);

  // Update timers if we receive updated time data from the server
  useEffect(() => {
    if (!gameState || !gameState.lastMove || gameState.timeLimit === 0) {
      return;
    }

    // Update the opponent's timer after they made a move
    if (gameState.lastMove.player === gameState.playerWhite) {
      // White player just moved, we can update their time if provided
      if (gameState.lastMove.whiteTimeLeft !== undefined) {
        setWhiteTimeRemaining(gameState.lastMove.whiteTimeLeft);
      }
    } 
    else if (gameState.lastMove.player === gameState.playerBlack) {
      // Black player just moved, we can update their time if provided
      if (gameState.lastMove.blackTimeLeft !== undefined) {
        setBlackTimeRemaining(gameState.lastMove.blackTimeLeft);
      }
    }
  }, [gameState?.lastMove]);

  // Calculate progress percentage for the progress bar
  const getProgressPercentage = (timeRemaining: number) => {
    if (!gameState || gameState.timeLimit === 0) return 100;
    return Math.max(0, Math.min(100, (timeRemaining / gameState.timeLimit) * 100));
  };

  // If there's no time limit, return a simple message
  if (!gameState || gameState.timeLimit === 0) {
    return (
      <div className="mb-4 p-3 bg-gray-50 rounded-lg text-center">
        <div className="flex items-center justify-center text-gray-600">
          <FaClock className="mr-2" />
          <span>{t("game.unlimitedTime")}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-4 grid grid-cols-1 gap-3">
      {/* White player timer */}
      <div className={`p-3 rounded-lg relative overflow-hidden ${activeTimer === 'white' ? 'bg-blue-50 border border-blue-200' : 'bg-gray-50'}`}>
        <div className="flex justify-between items-center mb-1">
          <div className="font-medium">
            {t("game.whitePlayer")} 
            {gameState.playerWhite === walletAddress && ` (${t("game.you")})`}
          </div>
          <div className={`font-mono font-bold ${whiteTimeRemaining < 30 ? 'text-red-500' : ''}`}>
            {formatTime(whiteTimeRemaining)}
          </div>
        </div>
        <Progress 
          value={getProgressPercentage(whiteTimeRemaining)} 
          className={`h-2 ${activeTimer === 'white' ? 'bg-blue-100' : 'bg-gray-200'}`}
          indicatorClassName={whiteTimeRemaining < 30 ? 'bg-red-500' : 'bg-blue-500'}
        />
        {activeTimer === 'white' && (
          <div className="absolute top-0 right-0 w-3 h-3 rounded-full bg-blue-500 animate-pulse mt-1 mr-1" />
        )}
      </div>
      
      {/* Black player timer */}
      <div className={`p-3 rounded-lg relative overflow-hidden ${activeTimer === 'black' ? 'bg-purple-50 border border-purple-200' : 'bg-gray-50'}`}>
        <div className="flex justify-between items-center mb-1">
          <div className="font-medium">
            {t("game.blackPlayer")} 
            {gameState.playerBlack === walletAddress && ` (${t("game.you")})`}
          </div>
          <div className={`font-mono font-bold ${blackTimeRemaining < 30 ? 'text-red-500' : ''}`}>
            {formatTime(blackTimeRemaining)}
          </div>
        </div>
        <Progress 
          value={getProgressPercentage(blackTimeRemaining)} 
          className={`h-2 ${activeTimer === 'black' ? 'bg-purple-100' : 'bg-gray-200'}`}
          indicatorClassName={blackTimeRemaining < 30 ? 'bg-red-500' : 'bg-purple-500'}
        />
        {activeTimer === 'black' && (
          <div className="absolute top-0 right-0 w-3 h-3 rounded-full bg-purple-500 animate-pulse mt-1 mr-1" />
        )}
      </div>
    </div>
  );
}