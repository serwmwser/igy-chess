import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import TokenLogo from "./TokenLogo";
import { useLanguage } from "@/context/LanguageContext";
import { FaCoins, FaInfoCircle, FaExchangeAlt, FaChartLine } from "react-icons/fa";
import { useWallet } from "@/context/WalletContext";
import { Button } from "./ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip";

export default function TokenInfo() {
  const { t } = useLanguage();
  const { igyBalance } = useWallet();
  
  // Токен IGY сейчас не торгуется публично, поэтому цена равна цене POL (1:1)
  const tokenPrice = 1.0; // В будущем это значение может приходить с API
  const totalSupply = 10_000_000;
  const circulatingSupply = 2_500_000; // Примерное значение для демонстрации
  const percentCirculating = (circulatingSupply / totalSupply) * 100;
  
  return (
    <Card className="mb-6">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg font-bold">{t("token.igyToken")}</CardTitle>
            <CardDescription>{t("token.poweredByPolygon")}</CardDescription>
          </div>
          <TokenLogo size="lg" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          {/* Цена токена */}
          <div className="bg-secondary/20 rounded-lg p-4">
            <div className="flex justify-between items-center mb-2">
              <div className="flex items-center">
                <FaChartLine className="mr-2 text-primary" />
                <span className="font-medium">{t("token.currentPrice")}</span>
              </div>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-6 w-6">
                      <FaInfoCircle className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{t("token.priceTooltip")}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <div className="text-2xl font-bold text-gradient">
              ${tokenPrice.toFixed(2)} <span className="text-sm font-normal text-gray-500">USD</span>
            </div>
            <div className="text-xs text-green-600 mt-1">1 IGY = 1 POL</div>
          </div>
          
          {/* Информация о контракте */}
          <div className="bg-secondary/10 rounded-lg p-4">
            <div className="text-sm font-medium mb-2">{t("token.contractInfo")}</div>
            <div className="font-mono text-xs overflow-hidden text-ellipsis">
              0x6d278Ec8Bb6FC8d06c081e4688759546CC73eaB8
            </div>
            <div className="mt-2 flex items-center text-xs">
              <FaCoins className="mr-1 text-amber-500" />
              <span>{t("token.totalSupply")}: {totalSupply.toLocaleString()}</span>
            </div>
            <div className="mt-2 grid grid-cols-2 gap-1 text-xs">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-green-500 rounded-full mr-1"></div>
                <span>{t("token.walletVisibility", "Visible in wallets")}</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-blue-500 rounded-full mr-1"></div>
                <span>{t("token.polygonscanVisibility", "Polygonscan verified")}</span>
              </div>
            </div>
          </div>
          
          {/* Оборот токенов */}
          <div>
            <div className="flex justify-between items-center mb-1 text-sm">
              <span>{t("token.circulatingSupply")}</span>
              <span>{Math.round(percentCirculating)}%</span>
            </div>
            <Progress value={percentCirculating} className="h-2" />
            <div className="flex justify-between text-xs mt-1 text-gray-500">
              <span>{circulatingSupply.toLocaleString()} IGY</span>
              <span>{totalSupply.toLocaleString()} IGY</span>
            </div>
          </div>
          
          {/* Кнопки обмена */}
          <div className="grid grid-cols-2 gap-2 mt-2">
            <Button variant="outline" className="w-full">
              <FaExchangeAlt className="mr-2 h-4 w-4" />
              {t("token.buy")}
            </Button>
            <Button variant="outline" className="w-full">
              {t("token.sell")}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}