import { useState, useEffect, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { FaRedo, FaTrophy } from 'react-icons/fa';
import { useWallet } from '@/context/WalletContext';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/context/LanguageContext';

// Типы для игры
type Cell = 0 | 2 | 4 | 8 | 16 | 32 | 64 | 128 | 256 | 512 | 1024 | 2048 | 4096 | 8192;
type Board = Cell[][];
type Direction = 'up' | 'down' | 'left' | 'right';

const GRID_SIZE = 4;
const CELL_COUNT = GRID_SIZE * GRID_SIZE;
const WIN_SCORE = 2048;

const Game2048 = () => {
  const { walletAddress, addTokens } = useWallet();
  const { toast } = useToast();
  const { t } = useLanguage();
  const [board, setBoard] = useState<Board>([]);
  const [score, setScore] = useState(0);
  const [bestScore, setBestScore] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);
  const [hasWon, setHasWon] = useState(false);
  const [animClasses, setAnimClasses] = useState<{[key: string]: string}>({});

  // Инициализация игры
  const initializeGame = useCallback(() => {
    // Создаем пустую доску
    const newBoard: Board = Array(GRID_SIZE).fill(0).map(() => 
      Array(GRID_SIZE).fill(0)
    ) as Board;
    
    // Добавляем две начальные плитки
    const boardWithTiles = addRandomTile(addRandomTile(newBoard));
    
    setBoard(boardWithTiles);
    setScore(0);
    setIsGameOver(false);
    setHasWon(false);
    setAnimClasses({});
  }, []);

  // Загрузка лучшего результата из localStorage при первом рендере
  useEffect(() => {
    const savedBestScore = localStorage.getItem('2048-best-score');
    if (savedBestScore) {
      setBestScore(parseInt(savedBestScore));
    }
    
    initializeGame();
  }, [initializeGame]);

  // Сохранение лучшего результата в localStorage при его изменении
  useEffect(() => {
    if (score > bestScore) {
      setBestScore(score);
      localStorage.setItem('2048-best-score', score.toString());
    }
  }, [score, bestScore]);

  // Обработка клавиатурных событий
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isGameOver || !walletAddress) return;
      
      let direction: Direction | null = null;
      
      switch (e.key) {
        case 'ArrowUp':
          direction = 'up';
          e.preventDefault();
          break;
        case 'ArrowDown':
          direction = 'down';
          e.preventDefault();
          break;
        case 'ArrowLeft':
          direction = 'left';
          e.preventDefault();
          break;
        case 'ArrowRight':
          direction = 'right';
          e.preventDefault();
          break;
        default:
          return;
      }
      
      if (direction) {
        const { newBoard, newScore, moved } = moveBoard(board, direction, score);
        if (moved) {
          const boardWithNewTile = addRandomTile(newBoard);
          setBoard(boardWithNewTile);
          setScore(newScore);
          
          // Проверка на выигрыш
          if (hasWinningTile(boardWithNewTile) && !hasWon) {
            setHasWon(true);
            
            // Награждаем пользователя токенами при выигрыше
            if (walletAddress) {
              addTokens(5, "Выигрыш в игре 2048");
              toast({
                title: "Поздравляем!",
                description: "Вы получили 5 IGY токенов за достижение 2048!",
              });
            }
          }
          
          // Проверка на проигрыш
          if (isGameOverCheck(boardWithNewTile)) {
            setIsGameOver(true);
          }
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [board, isGameOver, walletAddress, score, hasWon, addTokens, toast]);

  // Добавление новой плитки на случайную пустую клетку
  const addRandomTile = (currentBoard: Board): Board => {
    // Клонируем доску
    const newBoard = currentBoard.map(row => [...row]);
    
    // Находим все пустые ячейки
    const emptyCells: [number, number][] = [];
    for (let i = 0; i < GRID_SIZE; i++) {
      for (let j = 0; j < GRID_SIZE; j++) {
        if (newBoard[i][j] === 0) {
          emptyCells.push([i, j]);
        }
      }
    }
    
    // Если есть пустые ячейки, добавляем новую плитку
    if (emptyCells.length > 0) {
      const [row, col] = emptyCells[Math.floor(Math.random() * emptyCells.length)];
      // 90% шанс получить плитку со значением 2, 10% - со значением 4
      newBoard[row][col] = Math.random() < 0.9 ? 2 : 4;
      
      // Добавляем класс для анимации новой плитки
      setTimeout(() => {
        setAnimClasses(prev => {
          const newAnimClasses = {...prev};
          newAnimClasses[`${row}-${col}`] = 'animate-pop-in';
          return newAnimClasses;
        });
      }, 50);
    }
    
    return newBoard;
  };

  // Перемещение плиток в указанном направлении
  const moveBoard = (currentBoard: Board, direction: Direction, currentScore: number): { newBoard: Board, newScore: number, moved: boolean } => {
    // Клонируем доску
    const newBoard = currentBoard.map(row => [...row]);
    let newScore = currentScore;
    let moved = false;
    
    // Различная логика в зависимости от направления
    if (direction === 'left') {
      for (let i = 0; i < GRID_SIZE; i++) {
        const { newRow, rowScore, rowMoved } = moveLine(newBoard[i]);
        newBoard[i] = newRow;
        newScore += rowScore;
        moved = moved || rowMoved;
      }
    } else if (direction === 'right') {
      for (let i = 0; i < GRID_SIZE; i++) {
        const reversedRow = [...newBoard[i]].reverse();
        const { newRow, rowScore, rowMoved } = moveLine(reversedRow);
        newBoard[i] = newRow.reverse();
        newScore += rowScore;
        moved = moved || rowMoved;
      }
    } else if (direction === 'up') {
      for (let j = 0; j < GRID_SIZE; j++) {
        const column = newBoard.map(row => row[j]);
        const { newRow, rowScore, rowMoved } = moveLine(column);
        for (let i = 0; i < GRID_SIZE; i++) {
          newBoard[i][j] = newRow[i];
        }
        newScore += rowScore;
        moved = moved || rowMoved;
      }
    } else if (direction === 'down') {
      for (let j = 0; j < GRID_SIZE; j++) {
        const column = newBoard.map(row => row[j]).reverse();
        const { newRow, rowScore, rowMoved } = moveLine(column);
        for (let i = 0; i < GRID_SIZE; i++) {
          newBoard[GRID_SIZE - 1 - i][j] = newRow[i];
        }
        newScore += rowScore;
        moved = moved || rowMoved;
      }
    }
    
    return { newBoard, newScore, moved };
  };

  // Перемещение одной линии (строки или столбца)
  const moveLine = (line: Cell[]): { newRow: Cell[], rowScore: number, rowMoved: boolean } => {
    // Удаляем нули
    const nonZeros = line.filter(cell => cell !== 0);
    const newRow: Cell[] = Array(GRID_SIZE).fill(0) as Cell[];
    let rowScore = 0;
    let rowMoved = line.some((cell, i) => cell !== 0 && i !== nonZeros.findIndex(c => c === cell));
    
    // Объединяем плитки
    let position = 0;
    for (let i = 0; i < nonZeros.length; i++) {
      if (i < nonZeros.length - 1 && nonZeros[i] === nonZeros[i + 1]) {
        // Объединяем одинаковые плитки
        const mergedValue = nonZeros[i] * 2 as Cell;
        newRow[position] = mergedValue;
        rowScore += mergedValue;
        i++; // Пропускаем следующий элемент, так как он был объединен
        rowMoved = true;
      } else {
        // Просто перемещаем плитку
        newRow[position] = nonZeros[i];
      }
      position++;
    }
    
    return { newRow, rowScore, rowMoved };
  };

  // Проверка на наличие выигрышной плитки
  const hasWinningTile = (currentBoard: Board): boolean => {
    for (let i = 0; i < GRID_SIZE; i++) {
      for (let j = 0; j < GRID_SIZE; j++) {
        if (currentBoard[i][j] >= WIN_SCORE) {
          return true;
        }
      }
    }
    return false;
  };

  // Проверка на конец игры (нет возможных ходов)
  const isGameOverCheck = (currentBoard: Board): boolean => {
    // Есть ли пустые ячейки
    for (let i = 0; i < GRID_SIZE; i++) {
      for (let j = 0; j < GRID_SIZE; j++) {
        if (currentBoard[i][j] === 0) {
          return false;
        }
      }
    }
    
    // Есть ли возможные объединения по горизонтали
    for (let i = 0; i < GRID_SIZE; i++) {
      for (let j = 0; j < GRID_SIZE - 1; j++) {
        if (currentBoard[i][j] === currentBoard[i][j + 1]) {
          return false;
        }
      }
    }
    
    // Есть ли возможные объединения по вертикали
    for (let i = 0; i < GRID_SIZE - 1; i++) {
      for (let j = 0; j < GRID_SIZE; j++) {
        if (currentBoard[i][j] === currentBoard[i + 1][j]) {
          return false;
        }
      }
    }
    
    return true;
  };

  // Функция для определения цвета плитки
  const getTileColor = (value: Cell): string => {
    const colors: {[key: number]: string} = {
      0: 'bg-gray-200',
      2: 'bg-amber-100 text-gray-800',
      4: 'bg-amber-200 text-gray-800',
      8: 'bg-orange-300 text-white',
      16: 'bg-orange-400 text-white',
      32: 'bg-orange-500 text-white',
      64: 'bg-orange-600 text-white',
      128: 'bg-yellow-300 text-white',
      256: 'bg-yellow-400 text-white',
      512: 'bg-yellow-500 text-white',
      1024: 'bg-yellow-600 text-white',
      2048: 'bg-yellow-700 text-white',
      4096: 'bg-purple-500 text-white',
      8192: 'bg-purple-600 text-white'
    };
    
    return colors[value] || 'bg-purple-700 text-white';
  };

  // Функция для определения размера шрифта плитки
  const getTileFontSize = (value: Cell): string => {
    if (value < 100) return 'text-2xl';
    if (value < 1000) return 'text-xl';
    return 'text-lg';
  };

  // Обработчики свайпов для мобильных устройств
  const [touchStart, setTouchStart] = useState<{x: number, y: number} | null>(null);
  const [touchEnd, setTouchEnd] = useState<{x: number, y: number} | null>(null);
  
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart({
      x: e.touches[0].clientX,
      y: e.touches[0].clientY
    });
  };
  
  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd({
      x: e.touches[0].clientX,
      y: e.touches[0].clientY
    });
  };
  
  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd || isGameOver || !walletAddress) {
      setTouchStart(null);
      setTouchEnd(null);
      return;
    }
    
    const xDiff = touchStart.x - touchEnd.x;
    const yDiff = touchStart.y - touchEnd.y;
    
    let direction: Direction | null = null;
    
    // Определяем направление свайпа
    if (Math.abs(xDiff) > Math.abs(yDiff)) {
      // Горизонтальный свайп
      if (xDiff > 20) direction = 'left';
      else if (xDiff < -20) direction = 'right';
    } else {
      // Вертикальный свайп
      if (yDiff > 20) direction = 'up';
      else if (yDiff < -20) direction = 'down';
    }
    
    if (direction) {
      const { newBoard, newScore, moved } = moveBoard(board, direction, score);
      if (moved) {
        const boardWithNewTile = addRandomTile(newBoard);
        setBoard(boardWithNewTile);
        setScore(newScore);
        
        // Проверка на выигрыш
        if (hasWinningTile(boardWithNewTile) && !hasWon) {
          setHasWon(true);
          
          // Награждаем пользователя токенами при выигрыше
          if (walletAddress) {
            addTokens(5, "Выигрыш в игре 2048");
            toast({
              title: "Поздравляем!",
              description: "Вы получили 5 IGY токенов за достижение 2048!",
            });
          }
        }
        
        // Проверка на проигрыш
        if (isGameOverCheck(boardWithNewTile)) {
          setIsGameOver(true);
        }
      }
    }
    
    setTouchStart(null);
    setTouchEnd(null);
  };

  return (
    <Card className="w-full max-w-md mx-auto bg-white shadow-xl overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-amber-500 to-yellow-500 text-white">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-2xl">2048</CardTitle>
            <CardDescription className="text-yellow-100">
              Объедините числа и получите 2048!
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <div className="bg-white bg-opacity-20 rounded p-2 text-center">
              <div className="text-xs text-yellow-100">Счёт</div>
              <div className="text-lg font-bold">{score}</div>
            </div>
            <div className="bg-white bg-opacity-20 rounded p-2 text-center">
              <div className="text-xs text-yellow-100">Рекорд</div>
              <div className="text-lg font-bold">{bestScore}</div>
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-4">
        <div className="mb-4 flex justify-between items-center">
          <Button 
            onClick={initializeGame}
            variant="outline" 
            className="flex items-center gap-1"
          >
            <FaRedo className="h-4 w-4" />
            Новая игра
          </Button>
          
          {hasWon && (
            <div className="flex items-center gap-1 text-yellow-600 font-bold">
              <FaTrophy className="h-4 w-4" />
              Победа!
            </div>
          )}
        </div>
        
        <div 
          className="bg-gray-300 p-3 rounded-lg"
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          <div className="grid grid-cols-4 gap-3">
            {board.map((row, rowIndex) => 
              row.map((cell, colIndex) => (
                <div 
                  key={`${rowIndex}-${colIndex}`} 
                  className={`w-full aspect-square rounded-md flex items-center justify-center ${getTileColor(cell)} font-bold ${getTileFontSize(cell)} transition-all transform ${animClasses[`${rowIndex}-${colIndex}`] || ''}`}
                >
                  {cell !== 0 ? cell : ''}
                </div>
              ))
            )}
          </div>
        </div>
        
        {isGameOver && !hasWon && (
          <div className="mt-4 bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded">
            <div className="font-bold text-center">Игра окончена!</div>
            <div className="text-center text-sm">Нажмите "Новая игра", чтобы начать заново</div>
          </div>
        )}
        
        <div className="mt-4 text-sm text-gray-500">
          <p>Используйте клавиши стрелок для перемещения плиток. На мобильном устройстве просто свайпайте в нужном направлении.</p>
          <p className="mt-1 text-amber-600 font-medium">Достигните 2048 и получите 5 IGY токенов!</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default Game2048;