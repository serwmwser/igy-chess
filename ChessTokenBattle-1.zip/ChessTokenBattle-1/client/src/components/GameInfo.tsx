import { useGame } from "@/context/GameContext";
import { useLanguage } from "@/context/LanguageContext";
import { formatTime } from "@/lib/utils";
import GameTimer from "@/components/GameTimer";

export default function GameInfo() {
  const { t } = useLanguage();
  const { gameState } = useGame();

  // Format time for display
  const formatTimeAgo = (timestamp?: number) => {
    if (!timestamp) return "";
    
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    if (seconds < 60) return `${seconds} ${t("time.secondsAgo")}`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)} ${t("time.minutesAgo")}`;
    return `${Math.floor(seconds / 3600)} ${t("time.hoursAgo")}`;
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-6">
      <h3 className="font-montserrat font-semibold mb-3">{t("gameInfo.title")}</h3>
      
      {/* Game Timer */}
      {gameState && gameState.status === "active" && (
        <GameTimer />
      )}
      
      <div className="space-y-2 mt-3">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">{t("gameInfo.stake")}:</span>
          <span className="font-semibold">
            {gameState?.stakeAmount 
              ? `${gameState.stakeAmount} IGY Token${gameState.stakeAmount > 1 ? 's' : ''}` 
              : '1 IGY Token'}
          </span>
        </div>
        
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">{t("gameInfo.gameMode")}:</span>
          <span className="font-semibold">
            {gameState?.timeLimit === 0 
              ? t("gameInfo.unlimitedTime")
              : gameState?.timeLimit === 3600
                ? t("gameInfo.oneHourTimer")
                : gameState?.timeLimit === 1800
                  ? t("gameInfo.thirtyMinTimer")
                  : gameState?.timeLimit === 900
                    ? t("gameInfo.fifteenMinTimer")
                    : gameState?.timeLimit === 300
                      ? t("gameInfo.fiveMinTimer")
                      : t("gameInfo.customTimer", { time: formatTime(gameState?.timeLimit || 0) })}
          </span>
        </div>
        
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">{t("gameInfo.gameId")}:</span>
          <span className="font-mono text-xs">{gameState?.id || "-"}</span>
        </div>
        
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">{t("gameInfo.started")}:</span>
          <span>{gameState?.startTime ? formatTimeAgo(gameState.startTime) : "-"}</span>
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-200">
        <h4 className="font-semibold mb-2">{t("gameInfo.moveHistory")}</h4>
        <div className="h-32 overflow-y-auto bg-gray-50 p-2 rounded font-mono text-xs">
          {gameState?.moveHistory && gameState.moveHistory.length > 0 ? (
            gameState.moveHistory.map((moveGroup, index) => (
              <div className="grid grid-cols-3 gap-1 mb-1" key={index}>
                <div className="text-gray-500">{index + 1}.</div>
                <div>{moveGroup[0] || ""}</div>
                <div>{moveGroup[1] || ""}</div>
              </div>
            ))
          ) : (
            <div className="text-gray-500 text-center py-2">
              {t("gameInfo.noMoves")}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
