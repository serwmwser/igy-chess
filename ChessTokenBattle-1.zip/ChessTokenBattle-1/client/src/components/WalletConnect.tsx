import { FaChessKing, FaWallet, FaChessPawn, FaCoins, FaUserFriends, FaTrophy, FaChessQueen, FaMobileAlt, FaDesktop, FaTimes } from "react-icons/fa";
import { useWallet } from "@/context/WalletContext";
import { useLanguage } from "@/context/LanguageContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { QRCodeSVG } from "qrcode.react";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle,
  DialogClose
} from "@/components/ui/dialog";

export default function WalletConnect() {
  const { connectWallet, isConnecting, isDesktopWallet } = useWallet();
  const { t } = useLanguage();
  const { toast } = useToast();
  const [deviceType, setDeviceType] = useState<"desktop" | "mobile">("desktop");
  const [showQRCode, setShowQRCode] = useState<boolean>(false);
  const [qrValue, setQrValue] = useState<string>("");

  const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

  // Автоматически устанавливаем начальное значение вкладки на основе устройства пользователя
  useEffect(() => {
    setDeviceType(isMobile ? "mobile" : "desktop");
  }, [isMobile]);

  const handleConnect = async () => {
    try {
      // Для мобильных устройств показываем QR-код через WalletConnect
      if (deviceType === "mobile" && !isMobile) {
        setShowQRCode(true);
        // В реальном приложении здесь будет URI для QR-кода из WalletConnect
        // Для демонстрации, заполняем временным значением
        setQrValue("ethereum:0x0/transfer?address=0x0&uint256=1");
      } else {
        await connectWallet();
      }
    } catch (error) {
      console.error("Wallet connection error:", error);
      toast({
        title: t("errors.walletConnection"),
        description: typeof error === 'string' ? error : t("errors.tryAgain"),
        variant: "destructive"
      });
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <Card className="card-gradient overflow-hidden border-0 shadow-lg">
        <div className="relative overflow-hidden pt-8 px-6 pb-0 bg-gradient-to-br from-purple-50 to-gray-50">
          <div className="absolute top-0 right-0 -mt-8 -mr-8 w-32 h-32 bg-purple-100 rounded-full opacity-50"></div>
          <div className="absolute bottom-0 left-0 -mb-8 -ml-8 w-32 h-32 bg-blue-100 rounded-full opacity-40"></div>
          
          <div className="relative z-10 flex justify-center">
            <div className="w-24 h-24 rounded-full bg-white shadow-md flex items-center justify-center">
              <div className="flex items-center justify-center space-x-1">
                <FaChessQueen className="text-4xl text-primary" />
                <FaChessKing className="text-5xl text-primary" />
              </div>
            </div>
          </div>
          
          <div className="relative z-10 text-center mt-4 mb-6">
            <h2 className="font-bold text-3xl mb-2">{t("walletConnect.welcome")}</h2>
            <p className="text-gray-600">{t("walletConnect.subtitle")}</p>
          </div>
        </div>
        
        <CardContent className="p-6">
          {/* Устройства - переключатель */}
          <div className="mb-4">
            <Tabs
              defaultValue={isMobile ? "mobile" : "desktop"}
              onValueChange={(v) => setDeviceType(v as "desktop" | "mobile")}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-2 mb-3">
                <TabsTrigger value="desktop" className="flex items-center justify-center">
                  <FaDesktop className="mr-2" />
                  Компьютер
                </TabsTrigger>
                <TabsTrigger value="mobile" className="flex items-center justify-center">
                  <FaMobileAlt className="mr-2" />
                  Телефон
                </TabsTrigger>
              </TabsList>

              <TabsContent value="desktop" className="mt-0">
                <div className="bg-gray-50 rounded-lg p-3 mb-4 text-sm">
                  <p className="mb-2 font-medium">Инструкция для компьютера:</p>
                  <ol className="list-decimal pl-5 space-y-1 text-xs">
                    <li>Установите расширение MetaMask или используйте другой совместимый кошелек</li>
                    <li>Нажмите кнопку "Подключить кошелек" ниже</li>
                    <li>Выберите ваш кошелек из списка и подтвердите подключение</li>
                    <li>После подключения вы сможете играть в шахматы и использовать мессенджер</li>
                  </ol>
                </div>
              </TabsContent>

              <TabsContent value="mobile" className="mt-0">
                <div className="bg-gray-50 rounded-lg p-3 mb-4 text-sm">
                  <p className="mb-2 font-medium">Инструкция для телефона:</p>
                  <ol className="list-decimal pl-5 space-y-1 text-xs">
                    <li>Установите мобильное приложение MetaMask, Trust Wallet или другой WalletConnect кошелек</li>
                    <li>Нажмите кнопку "Подключить кошелек" ниже</li>
                    <li>Сканируйте QR-код с помощью вашего мобильного кошелька</li>
                    <li>Подтвердите подключение в приложении кошелька</li>
                    <li>После подключения вы сможете играть в шахматы и использовать мессенджер</li>
                  </ol>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          <Button 
            className="w-full btn-gradient py-6 mb-4 text-lg font-semibold"
            onClick={handleConnect}
            disabled={isConnecting}
          >
            <FaWallet className="mr-2" />
            {isConnecting ? t("walletConnect.connecting") : t("walletConnect.connectWallet")}
          </Button>
          
          <p className="text-sm text-center text-gray-500 mb-6">
            {deviceType === "mobile" 
              ? "Используйте один кошелек для доступа к игре и мессенджеру на всех устройствах" 
              : t("walletConnect.info")}
          </p>
          
          {/* Features */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-purple-100 mb-3 mx-auto">
                <FaChessPawn className="text-primary" />
              </div>
              <h3 className="text-center font-medium mb-1">{t("features.playChess")}</h3>
              <p className="text-xs text-center text-gray-600">{t("features.playChessDesc")}</p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-amber-100 mb-3 mx-auto">
                <FaCoins className="text-amber-500" />
              </div>
              <h3 className="text-center font-medium mb-1">{t("features.earnTokens")}</h3>
              <p className="text-xs text-center text-gray-600">{t("features.earnTokensDesc")}</p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-blue-100 mb-3 mx-auto">
                <FaUserFriends className="text-blue-500" />
              </div>
              <h3 className="text-center font-medium mb-1">{t("features.inviteFriends")}</h3>
              <p className="text-xs text-center text-gray-600">{t("features.inviteFriendsDesc")}</p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-100 mb-3 mx-auto">
                <FaTrophy className="text-green-500" />
              </div>
              <h3 className="text-center font-medium mb-1">{t("features.climbLeaderboard")}</h3>
              <p className="text-xs text-center text-gray-600">{t("features.climbLeaderboardDesc")}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
