import { useEffect, useRef, useState } from 'react';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { useWallet } from '@/context/WalletContext';
import { useGame } from '@/context/GameContext';
import { cn } from '@/lib/utils';
import { useIsMobile } from '@/hooks/use-mobile';
import { MicIcon, MicOffIcon, VideoIcon, VideoOffIcon, MonitorIcon, PhoneOffIcon } from 'lucide-react';

// Configuration for WebRTC
const ICE_SERVERS = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
  ],
};

export default function VideoChat() {
  const { walletAddress } = useWallet();
  const { gameState } = useGame();
  const isMobile = useIsMobile();
  
  const [isConnected, setIsConnected] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isMinimized, setIsMinimized] = useState(isMobile);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  
  const isWhitePlayer = walletAddress === gameState?.playerWhite;
  const opponentAddress = isWhitePlayer ? gameState?.playerBlack : gameState?.playerWhite;

  // Handle WebRTC signaling
  useEffect(() => {
    const handleRTCSignal = (event: Event) => {
      if (!gameState || !peerConnectionRef.current) return;
      
      const detail = (event as CustomEvent).detail;
      const { type, gameId } = detail;
      
      // Ignore signals not meant for this game
      if (gameId !== gameState.id) return;
      
      switch (type) {
        case 'offer':
          handleOffer(detail.offer);
          break;
        case 'answer':
          handleAnswer(detail.answer);
          break;
        case 'iceCandidate':
          handleIceCandidate(detail.candidate);
          break;
      }
    };
    
    const handleOffer = async (offer: RTCSessionDescriptionInit) => {
      if (!peerConnectionRef.current) return;
      
      try {
        await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(offer));
        const answer = await peerConnectionRef.current.createAnswer();
        await peerConnectionRef.current.setLocalDescription(answer);
        
        // Send answer to the other player through WebSocket
        if (gameState) {
          const socket = new WebSocket(getWebSocketUrl());
          
          socket.onopen = () => {
            socket.send(JSON.stringify({
              type: 'rtcAnswer',
              address: walletAddress,
              gameId: gameState.id,
              answer: peerConnectionRef.current?.localDescription
            }));
            socket.close();
          };
        }
      } catch (error) {
        console.error('Error handling offer:', error);
      }
    };
    
    const handleAnswer = async (answer: RTCSessionDescriptionInit) => {
      if (!peerConnectionRef.current) return;
      
      try {
        await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(answer));
      } catch (error) {
        console.error('Error handling answer:', error);
      }
    };
    
    const handleIceCandidate = async (candidate: RTCIceCandidateInit) => {
      if (!peerConnectionRef.current) return;
      
      try {
        await peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(candidate));
      } catch (error) {
        console.error('Error handling ICE candidate:', error);
      }
    };
    
    window.addEventListener('rtcSignal', handleRTCSignal);
    
    return () => {
      window.removeEventListener('rtcSignal', handleRTCSignal);
    };
  }, [gameState, walletAddress]);
  
  // Get WebSocket URL
  const getWebSocketUrl = () => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${protocol}//${window.location.host}/ws`;
  };

  // Initialize video chat
  useEffect(() => {
    if (!gameState || !gameState.videoEnabled || !gameState.playerWhite || !gameState.playerBlack) {
      return;
    }
    
    const initVideoChat = async () => {
      try {
        // Get user media
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true
        });
        
        localStreamRef.current = stream;
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
        
        // Create peer connection
        const peerConnection = new RTCPeerConnection(ICE_SERVERS);
        peerConnectionRef.current = peerConnection;
        
        // Add local tracks to peer connection
        stream.getTracks().forEach(track => {
          if (localStreamRef.current) {
            peerConnection.addTrack(track, localStreamRef.current);
          }
        });
        
        // Listen for remote tracks
        peerConnection.ontrack = (event) => {
          if (remoteVideoRef.current && event.streams[0]) {
            remoteVideoRef.current.srcObject = event.streams[0];
          }
        };
        
        // Listen for ICE candidates
        peerConnection.onicecandidate = (event) => {
          if (event.candidate && gameState) {
            // Send ICE candidate to the other player through WebSocket
            const socket = new WebSocket(getWebSocketUrl());
            
            socket.onopen = () => {
              socket.send(JSON.stringify({
                type: 'rtcIceCandidate',
                address: walletAddress,
                gameId: gameState.id,
                candidate: event.candidate
              }));
              socket.close();
            };
          }
        };
        
        // If white player, create and send offer
        if (isWhitePlayer) {
          try {
            const offer = await peerConnection.createOffer();
            await peerConnection.setLocalDescription(offer);
            
            // Send offer to black player through WebSocket
            if (gameState) {
              const socket = new WebSocket(getWebSocketUrl());
              
              socket.onopen = () => {
                socket.send(JSON.stringify({
                  type: 'rtcOffer',
                  address: walletAddress,
                  gameId: gameState.id,
                  offer: peerConnection.localDescription
                }));
                socket.close();
              };
            }
          } catch (error) {
            console.error('Error creating offer:', error);
          }
        }
        
        setIsConnected(true);
      } catch (error) {
        console.error('Error initializing video chat:', error);
      }
    };
    
    initVideoChat();
    
    return () => {
      // Clean up
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach(track => track.stop());
      }
      
      if (peerConnectionRef.current) {
        peerConnectionRef.current.close();
      }
    };
  }, [gameState, isWhitePlayer, walletAddress]);
  
  // Handle mute/unmute
  const toggleMute = () => {
    if (localStreamRef.current) {
      const audioTracks = localStreamRef.current.getAudioTracks();
      audioTracks.forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsMuted(!isMuted);
    }
  };
  
  // Handle video on/off
  const toggleVideo = () => {
    if (localStreamRef.current) {
      const videoTracks = localStreamRef.current.getVideoTracks();
      videoTracks.forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsVideoEnabled(!isVideoEnabled);
    }
  };
  
  // Handle disconnect
  const disconnect = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => track.stop());
    }
    
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
    }
    
    setIsConnected(false);
  };
  
  // Don't render if video is not enabled for the game
  if (!gameState?.videoEnabled) {
    return null;
  }
  
  return (
    <Card className={cn(
      "fixed right-4 transition-all duration-300 z-50",
      isMinimized 
        ? "bottom-4 w-40 h-24" 
        : isMobile 
          ? "bottom-4 w-[calc(100%-32px)] h-[300px]" 
          : "bottom-4 w-80 h-[400px]"
    )}>
      <CardHeader className="p-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm">Video Chat</CardTitle>
        <div className="flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6" 
            onClick={() => setIsMinimized(!isMinimized)}
          >
            <MonitorIcon className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      
      {!isMinimized && (
        <CardContent className="p-2 grid gap-2">
          <div className="relative w-full aspect-video bg-secondary rounded-md overflow-hidden">
            {remoteVideoRef && (
              <video
                ref={remoteVideoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
            )}
            <div className="absolute bottom-2 right-2 w-1/4 aspect-video bg-secondary rounded-md overflow-hidden border border-primary">
              {localVideoRef && (
                <video
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
              )}
            </div>
          </div>
          
          <div className="flex items-center justify-center gap-2 mt-2">
            <Button
              variant={isMuted ? "destructive" : "secondary"}
              size="icon"
              onClick={toggleMute}
              className="rounded-full h-9 w-9"
            >
              {isMuted ? (
                <MicOffIcon className="h-4 w-4" />
              ) : (
                <MicIcon className="h-4 w-4" />
              )}
            </Button>
            
            <Button
              variant={!isVideoEnabled ? "destructive" : "secondary"}
              size="icon"
              onClick={toggleVideo}
              className="rounded-full h-9 w-9"
            >
              {!isVideoEnabled ? (
                <VideoOffIcon className="h-4 w-4" />
              ) : (
                <VideoIcon className="h-4 w-4" />
              )}
            </Button>
            
            <Button
              variant="destructive"
              size="icon"
              onClick={disconnect}
              className="rounded-full h-9 w-9"
            >
              <PhoneOffIcon className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      )}
    </Card>
  );
}