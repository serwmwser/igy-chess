import { useGame } from "@/context/GameContext";
import { useLanguage } from "@/context/LanguageContext";
import { FaFlag, FaHandshake, FaClock, FaInfinity } from "react-icons/fa";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function GameControls() {
  const { t } = useLanguage();
  const { gameState, resignGame, offerDraw } = useGame();
  const { toast } = useToast();

  const handleResign = () => {
    if (!gameState || gameState.status !== "active") {
      toast({
        title: t("errors.cannotResign"),
        description: t("errors.noActiveGame"),
        variant: "destructive"
      });
      return;
    }

    resignGame(gameState.id);
  };

  const handleOfferDraw = () => {
    if (!gameState || gameState.status !== "active") {
      toast({
        title: t("errors.cannotOfferDraw"),
        description: t("errors.noActiveGame"),
        variant: "destructive"
      });
      return;
    }

    offerDraw(gameState.id);
    toast({
      title: t("game.drawOffered"),
      description: t("game.waitingForOpponent"),
    });
  };

  return (
    <div className="flex flex-col sm:flex-row justify-between bg-gray-50 p-4 border-t border-gray-200">
      <div className="mb-2 sm:mb-0">
        <Button 
          variant="destructive" 
          size="sm" 
          className="mr-2"
          onClick={handleResign}
          disabled={!gameState || gameState.status !== "active"}
        >
          <FaFlag className="mr-1" />
          {t("game.resign")}
        </Button>
        <Button 
          variant="outline" 
          size="sm"
          onClick={handleOfferDraw}
          disabled={!gameState || gameState.status !== "active"}
        >
          <FaHandshake className="mr-1" />
          {t("game.offerDraw")}
        </Button>
      </div>
      
      <div className="flex items-center">
        <span className="mr-3">{t("game.gameMode")}:</span>
        <span className="bg-primary text-white px-3 py-1 rounded-full text-sm">
          {gameState?.timeLimit === 0 ? (
            <>
              <FaInfinity className="mr-1 inline" />
              {t("game.unlimited")}
            </>
          ) : (
            <>
              <FaClock className="mr-1 inline" />
              {t("game.oneHour")}
            </>
          )}
        </span>
      </div>
    </div>
  );
}
