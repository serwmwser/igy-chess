import { useEffect, useState, useRef } from "react";
import { useGame } from "@/context/GameContext";
import { useWallet } from "@/context/WalletContext";
import { useLanguage } from "@/context/LanguageContext";
import { FaPaperPlane } from "react-icons/fa";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { formatTime } from "@/lib/utils";

type ChatMessage = {
  id: string;
  sender: string;
  content: string;
  timestamp: number;
  systemMessage?: boolean;
};

export default function GameChat() {
  const { t } = useLanguage();
  const { gameState, sendChatMessage } = useGame();
  const { walletAddress } = useWallet();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [messageInput, setMessageInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Add system message when game starts
  useEffect(() => {
    if (gameState && gameState.status === "active" && messages.length === 0) {
      setMessages([
        {
          id: "system-welcome",
          sender: "system",
          content: t("chat.gameStarted"),
          timestamp: Date.now(),
          systemMessage: true
        }
      ]);
    }
  }, [gameState, t, messages.length]);

  // Update messages when new chat messages come in
  useEffect(() => {
    if (gameState?.chatMessages) {
      setMessages(prevMessages => {
        // Combine system messages with game chat messages
        const systemMessages = prevMessages.filter(m => m.systemMessage);
        return [...systemMessages, ...gameState.chatMessages];
      });
    }
  }, [gameState?.chatMessages]);

  // Add move notifications to chat
  useEffect(() => {
    if (gameState?.lastMove && gameState.lastMove.notation) {
      const moveMessage = {
        id: `move-${Date.now()}`,
        sender: "system",
        content: `${gameState.lastMove.player === gameState.playerWhite ? 'White' : 'Black'} ${t("chat.moved")} ${gameState.lastMove.notation}`,
        timestamp: Date.now(),
        systemMessage: true
      };
      
      setMessages(prevMessages => [...prevMessages, moveMessage]);
    }
  }, [gameState?.lastMove, gameState?.playerWhite, t]);

  // Scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (!messageInput.trim() || !gameState?.id) return;
    
    sendChatMessage({
      gameId: gameState.id,
      content: messageInput
    });
    
    setMessageInput("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  // Format sender display name
  const formatSenderName = (sender: string) => {
    if (sender === "system") return t("chat.system");
    if (sender === walletAddress) return t("chat.you");
    return `${sender.substring(0, 6)}...${sender.substring(sender.length - 4)}`;
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="bg-primary text-white p-3">
        <h3 className="font-montserrat font-semibold">{t("chat.gameChat")}</h3>
      </div>
      
      <div className="h-48 overflow-y-auto p-4 bg-gray-50" id="chat-messages">
        {messages.map((message) => (
          <div className="mb-3" key={message.id}>
            <div className="flex items-start">
              <div className={`font-semibold mr-2 ${
                message.systemMessage 
                  ? "text-gray-500" 
                  : message.sender === walletAddress 
                    ? "text-secondary" 
                    : "text-primary"
              }`}>
                {formatSenderName(message.sender)}:
              </div>
              <div>{message.content}</div>
            </div>
            <div className="text-xs text-gray-500">
              {formatTime(Math.floor((Date.now() - message.timestamp) / 1000), true)}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      
      <div className="p-3 border-t border-gray-200">
        <div className="flex">
          <Input
            type="text"
            placeholder={t("chat.typePlaceholder")}
            className="rounded-r-none"
            value={messageInput}
            onChange={(e) => setMessageInput(e.target.value)}
            onKeyPress={handleKeyPress}
            disabled={!gameState || gameState.status !== "active"}
          />
          <Button 
            className="rounded-l-none"
            onClick={handleSendMessage}
            disabled={!gameState || gameState.status !== "active"}
          >
            <FaPaperPlane />
          </Button>
        </div>
      </div>
    </div>
  );
}
