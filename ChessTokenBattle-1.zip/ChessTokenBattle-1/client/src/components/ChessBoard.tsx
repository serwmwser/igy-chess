import { useEffect, useState } from "react";
import { useGame } from "@/context/GameContext";
import { useWallet } from "@/context/WalletContext";
import { useLanguage } from "@/context/LanguageContext";
import { FaUser } from "react-icons/fa";
import { Chessboard } from "react-chessboard";
import { Chess } from "chess.js";

export default function ChessBoard() {
  const { t } = useLanguage();
  const { gameState, makeMove } = useGame();
  const { walletAddress } = useWallet();
  const [game, setGame] = useState(new Chess());
  const [boardOrientation, setBoardOrientation] = useState<"white" | "black">("white");

  // Set board orientation based on player color
  useEffect(() => {
    if (gameState?.playerWhite === walletAddress) {
      setBoardOrientation("white");
    } else if (gameState?.playerBlack === walletAddress) {
      setBoardOrientation("black");
    }
  }, [gameState?.playerWhite, gameState?.playerBlack, walletAddress]);

  // Update chess instance when game state changes
  useEffect(() => {
    if (gameState?.fen) {
      const newGame = new Chess(gameState.fen);
      setGame(newGame);
    }
  }, [gameState?.fen]);

  // Handle making a move
  function onDrop(sourceSquare: string, targetSquare: string) {
    try {
      // Проверка, ваш ли ход сейчас
      const isPlayerTurn = 
        (game.turn() === 'w' && gameState?.playerWhite === walletAddress) || 
        (game.turn() === 'b' && gameState?.playerBlack === walletAddress);
        
      if (!isPlayerTurn || !gameState || gameState.status !== "active") {
        return false;
      }
      
      const move = game.move({
        from: sourceSquare,
        to: targetSquare,
        promotion: 'q' // Always promote to queen for simplicity
      });
      
      if (move === null) return false;
      
      setGame(new Chess(game.fen()));
      
      // Send move to server
      makeMove({
        from: sourceSquare,
        to: targetSquare,
        promotion: 'q',
        gameId: gameState.id
      });
      
      return true;
    } catch (error) {
      return false;
    }
  }

  // Format opponent address for display
  const opponentAddress = gameState?.playerWhite === walletAddress 
    ? gameState?.playerBlack 
    : gameState?.playerWhite;
  
  const shortOpponentAddress = opponentAddress
    ? `${opponentAddress.substring(0, 6)}...${opponentAddress.substring(opponentAddress.length - 4)}`
    : "Waiting...";

  // Determine game status text
  const getStatusText = () => {
    if (!gameState) return t("game.waiting");
    
    if (gameState.status === "completed") {
      if (gameState.winner === walletAddress) return t("game.youWon");
      else if (gameState.winner === "draw") return t("game.draw");
      else return t("game.youLost");
    }
    
    const isPlayerTurn = 
      (game.turn() === 'w' && gameState.playerWhite === walletAddress) || 
      (game.turn() === 'b' && gameState.playerBlack === walletAddress);
    
    return isPlayerTurn ? t("game.yourTurn") : t("game.opponentTurn");
  };

  // Применяем тему доски из контекста игры
  const boardTheme = gameState?.boardTheme || "standard";
  
  // Настройка темы доски на основе выбранной темы
  const getBoardStyles = () => {
    // Базовые стили
    let darkSquareStyle = { backgroundColor: '#1a2b4c' };
    let lightSquareStyle = { backgroundColor: '#f8f5ed' };
    
    // Изменение стилей в зависимости от темы
    if (boardTheme === "blue") {
      darkSquareStyle = { backgroundColor: '#2c5aa0' };
      lightSquareStyle = { backgroundColor: '#e8ebf2' };
    } else if (boardTheme === "green") {
      darkSquareStyle = { backgroundColor: '#107b57' };
      lightSquareStyle = { backgroundColor: '#efefd5' };
    } else if (boardTheme === "purple") {
      darkSquareStyle = { backgroundColor: '#6a4c93' };
      lightSquareStyle = { backgroundColor: '#f7f3fb' };
    }
    
    return { darkSquareStyle, lightSquareStyle };
  };
  
  const { darkSquareStyle, lightSquareStyle } = getBoardStyles();

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
      {/* Game Header */}
      <div className="bg-primary text-white p-4 flex justify-between items-center">
        <div className="flex items-center">
          <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center text-primary mr-3">
            <FaUser />
          </div>
          <div>
            <div className="text-xs opacity-75">{t("game.opponent")}</div>
            <div className="font-semibold truncate max-w-[120px]">{shortOpponentAddress}</div>
          </div>
        </div>
        
        <div>
          <div className="text-sm font-montserrat">{t("game.gameStatus")}</div>
          <div className="text-secondary font-semibold">{getStatusText()}</div>
        </div>
      </div>
      
      {/* Chess Board */}
      <div className="flex justify-center p-4">
        <div className="w-full max-w-md aspect-square">
          <Chessboard 
            position={game.fen()}
            onPieceDrop={onDrop}
            boardOrientation={boardOrientation}
            customBoardStyle={{
              borderRadius: '4px',
              boxShadow: '0 2px 10px rgba(0, 0, 0, 0.2)',
            }}
            customDarkSquareStyle={darkSquareStyle}
            customLightSquareStyle={lightSquareStyle}
          />
        </div>
      </div>
    </div>
  );
}
