import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Dashboard from "@/pages/Dashboard";
import Profile from "@/pages/Profile";
import Messenger from "@/pages/Messenger";
import { WalletProvider } from "./context/WalletContext";
import { GameProvider } from "./context/GameContext";
import { LanguageProvider } from "./context/LanguageContext";
import { AuthProvider } from "./context/AuthContext";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";

function Router() {
  const [location] = useLocation();
  const [mounted, setMounted] = useState(false);
  
  useEffect(() => {
    setMounted(true);
  }, []);

  // Parse invite code from URL if any
  useEffect(() => {
    if (!mounted) return;
    
    const urlParams = new URLSearchParams(window.location.search);
    const inviteCode = urlParams.get("invite");
    
    if (inviteCode) {
      // Store invite code in local storage to retrieve after wallet connection
      localStorage.setItem("pendingInvite", inviteCode);
    }
  }, [mounted, location]);

  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/profile" component={Profile} />
      <Route path="/messenger" component={Messenger} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <WalletProvider>
          <AuthProvider>
            <GameProvider>
              <Router />
              <Toaster />
            </GameProvider>
          </AuthProvider>
        </WalletProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
