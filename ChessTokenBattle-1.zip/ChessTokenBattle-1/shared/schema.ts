import { pgTable, text, serial, integer, boolean, timestamp, jsonb, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table for storing wallet addresses and game information
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull().unique(),
  username: text("username"), // Optional username for display
  wins: integer("wins").default(0),
  losses: integer("losses").default(0),
  draws: integer("draws").default(0),
  igyBalance: integer("igy_balance").default(0), // This is a cached version, actual balance is on blockchain
  lastSeen: timestamp("last_seen").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  invitedBy: text("invited_by").references(() => users.walletAddress), // Who invited this user
  paidInvites: integer("paid_invites").default(0), // Count of users invited who paid 1 token
  hasMessengerAccess: boolean("has_messenger_access").default(false), // Whether user has messenger access
  preferences: jsonb("preferences").$type<{
    boardTheme: string;
    pieceTheme: string;
    soundEnabled: boolean;
  }>().default({
    boardTheme: "standard",
    pieceTheme: "standard",
    soundEnabled: true,
  }),
});

// Game table for storing chess game data
export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  gameId: text("game_id").notNull().unique(), // UUID for the game
  playerWhite: text("player_white").notNull().references(() => users.walletAddress),
  playerBlack: text("player_black").references(() => users.walletAddress),
  status: text("status").notNull().default("waiting"), // waiting, active, completed
  winner: text("winner"), // wallet address of winner, "draw", or null if in progress
  fen: text("fen").notNull().default("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"), // Current board position
  pgn: text("pgn"), // Game moves in Portable Game Notation
  timeLimit: integer("time_limit").default(3600), // Time limit in seconds, 0 for unlimited
  isPublic: boolean("is_public").default(true), // Whether game is public or invitation-only
  inviteCode: text("invite_code"), // Code for invitation-only games
  startTime: timestamp("start_time"),
  endTime: timestamp("end_time"),
  lastMoveTime: timestamp("last_move_time"),
  drawOfferedBy: text("draw_offered_by"), // Wallet address of player who offered draw
  moveHistory: jsonb("move_history").$type<string[][]>(), // Array of move pairs [["e4", "e5"], ["Nf3", "Nc6"]]
  boardTheme: text("board_theme").default("standard"),
  pieceTheme: text("piece_theme").default("standard"),
  videoEnabled: boolean("video_enabled").default(false),
  opponentType: text("opponent_type").default("random"), // AI, random, or invite
  stakeAmount: integer("stake_amount").default(1), // Количество токенов для ставки
});

// Chat messages for games
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  gameId: text("game_id").notNull().references(() => games.gameId),
  sender: text("sender").notNull(), // Wallet address of sender
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Daily tasks that users can complete
export const dailyTasks = pgTable("daily_tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  rewardAmount: integer("reward_amount").notNull().default(1),
  taskType: text("task_type").notNull(), // "win_game", "play_games", "login", etc.
  requiredCount: integer("required_count").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow(),
  active: boolean("active").default(true),
});

// Track user progress on daily tasks
export const userTaskProgress = pgTable("user_task_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  taskId: integer("task_id").notNull().references(() => dailyTasks.id),
  currentCount: integer("current_count").default(0),
  completed: boolean("completed").default(false),
  completedAt: timestamp("completed_at"),
  lastUpdated: timestamp("last_updated").defaultNow(),
  date: timestamp("date").defaultNow(), // To track which day this progress belongs to
});

// Available board themes
export const boardThemes = pgTable("board_themes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  displayName: text("display_name").notNull(),
  description: text("description"),
  previewImage: text("preview_image"),
  primaryColor: text("primary_color").notNull(),
  secondaryColor: text("secondary_color").notNull(),
  isPremium: boolean("is_premium").default(false),
  price: integer("price").default(0), // Price in IGY tokens if premium
});

// Available piece themes
export const pieceThemes = pgTable("piece_themes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  displayName: text("display_name").notNull(),
  description: text("description"),
  previewImage: text("preview_image"),
  folderPath: text("folder_path").notNull(), // Path to the folder containing piece images
  isPremium: boolean("is_premium").default(false),
  price: integer("price").default(0), // Price in IGY tokens if premium
});

// Messenger User Profiles
export const messengerProfiles = pgTable("messenger_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  displayName: text("display_name").notNull(),
  bio: text("bio"),
  avatarUrl: text("avatar_url"),
  isVerified: boolean("is_verified").default(false),
  interests: jsonb("interests").$type<string[]>().default([]),
  location: text("location"),
  contactInfo: jsonb("contact_info").$type<{
    email?: string;
    phone?: string;
    telegram?: string;
  }>().default({}),
  privacySettings: jsonb("privacy_settings").$type<{
    showOnline: boolean;
    allowMessages: boolean;
    allowFriendRequests: boolean;
  }>().default({
    showOnline: true,
    allowMessages: true,
    allowFriendRequests: true,
  }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  lastActive: timestamp("last_active").defaultNow(),
  status: text("status").default("active"), // active, suspended, deleted
});

// Messenger Conversations
export const messengerConversations = pgTable("messenger_conversations", {
  id: serial("id").primaryKey(),
  conversationId: uuid("conversation_id").notNull().unique().defaultRandom(),
  name: text("name"), // Group chat name, null for direct messages
  type: text("type").notNull().default("direct"), // direct, group
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  lastMessageAt: timestamp("last_message_at").defaultNow(),
  isEncrypted: boolean("is_encrypted").default(false),
  metadata: jsonb("metadata").default({}),
});

// Messenger Conversation Participants
export const messengerParticipants = pgTable("messenger_participants", {
  id: serial("id").primaryKey(),
  conversationId: uuid("conversation_id").notNull().references(() => messengerConversations.conversationId),
  userId: integer("user_id").notNull().references(() => users.id),
  role: text("role").default("member"), // admin, member
  joinedAt: timestamp("joined_at").defaultNow(),
  lastReadMessageId: integer("last_read_message_id"),
  isActive: boolean("is_active").default(true),
  isMuted: boolean("is_muted").default(false),
  isPinned: boolean("is_pinned").default(false),
});

// Messenger Messages
export const messengerMessages = pgTable("messenger_messages", {
  id: serial("id").primaryKey(),
  conversationId: uuid("conversation_id").notNull().references(() => messengerConversations.conversationId),
  senderId: integer("sender_id").notNull().references(() => users.id),
  messageType: text("message_type").default("text"), // text, image, file, audio, video, location
  content: text("content").notNull(),
  metadata: jsonb("metadata").$type<{
    fileName?: string;
    fileSize?: number;
    mimeType?: string;
    duration?: number;
    thumbnailUrl?: string;
    width?: number;
    height?: number;
    latitude?: number;
    longitude?: number;
  }>().default({}),
  sentAt: timestamp("sent_at").defaultNow(),
  editedAt: timestamp("edited_at"),
  isDeleted: boolean("is_deleted").default(false),
  replyToId: integer("reply_to_id"), // We'll add the reference constraint separately
  reactions: jsonb("reactions").$type<{
    [userId: string]: string; // userId: reaction emoji
  }>().default({}),
});

// Friend relationships
export const friendships = pgTable("friendships", {
  id: serial("id").primaryKey(),
  requesterId: integer("requester_id").notNull().references(() => users.id),
  addresseeId: integer("addressee_id").notNull().references(() => users.id),
  status: text("status").notNull().default("pending"), // pending, accepted, rejected, blocked
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// File attachments
export const fileAttachments = pgTable("file_attachments", {
  id: serial("id").primaryKey(),
  messageId: integer("message_id").references(() => messengerMessages.id),
  userId: integer("user_id").notNull().references(() => users.id),
  fileName: text("file_name").notNull(),
  fileSize: integer("file_size").notNull(),
  mimeType: text("mime_type").notNull(),
  filePath: text("file_path").notNull(),
  thumbnailPath: text("thumbnail_path"),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  expiresAt: timestamp("expires_at"),
  isPublic: boolean("is_public").default(false),
  downloadCount: integer("download_count").default(0),
  status: text("status").default("active"), // active, deleted
});

// Transaction history for token payments
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  transactionId: uuid("transaction_id").notNull().unique().defaultRandom(),
  fromWalletAddress: text("from_wallet_address"), // Can be null for system operations
  toWalletAddress: text("to_wallet_address"), // Can be null for system operations
  amount: integer("amount").notNull(),
  type: text("type").notNull(), // charge, add, transfer, withdraw, deposit
  reason: text("reason").notNull(), // e.g., "messenger_registration", "game_stake", "theme_purchase"
  status: text("status").notNull().default("completed"), // completed, failed, pending
  data: jsonb("data").$type<{
    gameId?: string;
    themeId?: number;
    themeType?: string;
    messageId?: number;
    profileId?: number;
    conversationId?: string;
    refundable?: boolean;
  }>().default({}),
  timestamp: timestamp("timestamp").defaultNow(),
  blockchainTxHash: text("blockchain_tx_hash"), // If this transaction was recorded on blockchain
});

// Create insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  walletAddress: true,
  username: true,
  invitedBy: true,
  paidInvites: true,
  hasMessengerAccess: true,
  preferences: true,
});

export const insertGameSchema = createInsertSchema(games).pick({
  gameId: true,
  playerWhite: true,
  playerBlack: true,
  timeLimit: true,
  isPublic: true,
  inviteCode: true,
  boardTheme: true,
  pieceTheme: true,
  videoEnabled: true,
  opponentType: true,
  stakeAmount: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  gameId: true,
  sender: true,
  content: true,
});

export const insertDailyTaskSchema = createInsertSchema(dailyTasks).pick({
  title: true,
  description: true,
  rewardAmount: true,
  taskType: true,
  requiredCount: true,
  active: true,
});

export const insertUserTaskProgressSchema = createInsertSchema(userTaskProgress).pick({
  userId: true,
  taskId: true,
  currentCount: true,
  completed: true,
});

export const insertBoardThemeSchema = createInsertSchema(boardThemes).pick({
  name: true,
  displayName: true,
  description: true,
  previewImage: true,
  primaryColor: true,
  secondaryColor: true,
  isPremium: true,
  price: true,
});

export const insertPieceThemeSchema = createInsertSchema(pieceThemes).pick({
  name: true,
  displayName: true,
  description: true,
  previewImage: true,
  folderPath: true,
  isPremium: true,
  price: true,
});

// Create insert schemas for messenger tables
export const insertMessengerProfileSchema = createInsertSchema(messengerProfiles).pick({
  userId: true,
  displayName: true,
  bio: true,
  avatarUrl: true,
  interests: true,
  location: true,
  contactInfo: true,
  privacySettings: true,
});

export const insertMessengerConversationSchema = createInsertSchema(messengerConversations).pick({
  name: true,
  type: true,
  createdBy: true,
  isEncrypted: true,
  metadata: true,
});

export const insertMessengerParticipantSchema = createInsertSchema(messengerParticipants).pick({
  conversationId: true,
  userId: true,
  role: true,
});

export const insertMessengerMessageSchema = createInsertSchema(messengerMessages).pick({
  conversationId: true,
  senderId: true,
  messageType: true,
  content: true,
  metadata: true,
  replyToId: true,
});

export const insertFriendshipSchema = createInsertSchema(friendships).pick({
  requesterId: true,
  addresseeId: true,
  status: true,
});

export const insertFileAttachmentSchema = createInsertSchema(fileAttachments).pick({
  messageId: true,
  userId: true,
  fileName: true,
  fileSize: true,
  mimeType: true,
  filePath: true,
  thumbnailPath: true,
  isPublic: true,
  expiresAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  fromWalletAddress: true,
  toWalletAddress: true,
  amount: true,
  type: true,
  reason: true,
  status: true,
  data: true,
  blockchainTxHash: true,
});

// Define types
export type User = typeof users.$inferSelect;
export type Game = typeof games.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type DailyTask = typeof dailyTasks.$inferSelect;
export type UserTaskProgress = typeof userTaskProgress.$inferSelect;
export type BoardTheme = typeof boardThemes.$inferSelect;
export type PieceTheme = typeof pieceThemes.$inferSelect;
export type MessengerProfile = typeof messengerProfiles.$inferSelect;
export type MessengerConversation = typeof messengerConversations.$inferSelect;
export type MessengerParticipant = typeof messengerParticipants.$inferSelect;
export type MessengerMessage = typeof messengerMessages.$inferSelect;
export type Friendship = typeof friendships.$inferSelect;
export type FileAttachment = typeof fileAttachments.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertGame = z.infer<typeof insertGameSchema>;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type InsertDailyTask = z.infer<typeof insertDailyTaskSchema>;
export type InsertUserTaskProgress = z.infer<typeof insertUserTaskProgressSchema>;
export type InsertBoardTheme = z.infer<typeof insertBoardThemeSchema>;
export type InsertPieceTheme = z.infer<typeof insertPieceThemeSchema>;
export type InsertMessengerProfile = z.infer<typeof insertMessengerProfileSchema>;
export type InsertMessengerConversation = z.infer<typeof insertMessengerConversationSchema>;
export type InsertMessengerParticipant = z.infer<typeof insertMessengerParticipantSchema>;
export type InsertMessengerMessage = z.infer<typeof insertMessengerMessageSchema>;
export type InsertFriendship = z.infer<typeof insertFriendshipSchema>;
export type InsertFileAttachment = z.infer<typeof insertFileAttachmentSchema>;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
