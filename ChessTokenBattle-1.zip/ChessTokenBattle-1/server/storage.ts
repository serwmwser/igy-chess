import { 
  type User, 
  type InsertUser, 
  type Game, 
  type InsertGame, 
  type ChatMessage, 
  type InsertChatMessage,
  type DailyTask,
  type UserTaskProgress,
  type BoardTheme,
  type PieceTheme,
  type InsertDailyTask,
  type InsertUserTaskProgress,
  type InsertBoardTheme,
  type InsertPieceTheme,
  type MessengerProfile,
  type InsertMessengerProfile,
  type MessengerConversation,
  type InsertMessengerConversation,
  type MessengerParticipant,
  type InsertMessengerParticipant,
  type MessengerMessage,
  type InsertMessengerMessage,
  type Friendship,
  type InsertFriendship,
  type FileAttachment,
  type InsertFileAttachment,
  type Transaction,
  type InsertTransaction
} from "@shared/schema";
import { v4 as uuidv4 } from "uuid";
import { Chess } from "chess.js";

// Define leaderboard entry type
type LeaderboardEntry = {
  address: string;
  wins: number;
  igyBalance: number;
  rank: number;
};

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByWallet(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStats(walletAddress: string, result: "win" | "loss" | "draw"): Promise<User | undefined>;
  updateUserBalance(walletAddress: string, balance: number): Promise<User | undefined>;
  updateUserPreferences(walletAddress: string, preferences: Partial<User['preferences']>): Promise<User | undefined>;
  updateUserPaidInvites(walletAddress: string, increment?: boolean): Promise<User | undefined>;
  checkAndGrantMessengerAccess(walletAddress: string): Promise<boolean>;
  
  // Payment methods
  chargeTokens(walletAddress: string, amount: number, reason: string): Promise<boolean>;
  addTokens(walletAddress: string, amount: number, reason: string): Promise<boolean>;
  transferTokens(fromWalletAddress: string, toWalletAddress: string, amount: number, reason: string): Promise<boolean>;
  getTransactionHistory(walletAddress: string): Promise<any[]>; // We'll define a proper type for this later
  
  // Game methods
  createGame(game: InsertGame): Promise<Game>;
  getGameById(gameId: string): Promise<Game | undefined>;
  updateGame(gameId: string, updates: Partial<Game>): Promise<Game | undefined>;
  getActiveGameForUser(walletAddress: string): Promise<Game | undefined>;
  getPublicGames(): Promise<Game[]>;
  makeMove(gameId: string, walletAddress: string, from: string, to: string, promotion?: string): Promise<Game | undefined>;
  resignGame(gameId: string, walletAddress: string): Promise<Game | undefined>;
  offerDraw(gameId: string, walletAddress: string): Promise<Game | undefined>;
  respondToDrawOffer(gameId: string, walletAddress: string, accept: boolean): Promise<Game | undefined>;
  
  // Chat methods
  addChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  getChatMessages(gameId: string): Promise<ChatMessage[]>;
  
  // Leaderboard
  getLeaderboard(): Promise<LeaderboardEntry[]>;
  
  // Daily Tasks
  getDailyTasks(): Promise<DailyTask[]>;
  getDailyTask(id: number): Promise<DailyTask | undefined>;
  createDailyTask(task: InsertDailyTask): Promise<DailyTask>;
  updateDailyTask(id: number, updates: Partial<DailyTask>): Promise<DailyTask | undefined>;
  deleteDailyTask(id: number): Promise<boolean>;
  
  // User Task Progress
  getUserTaskProgress(userId: number, date?: Date): Promise<UserTaskProgress[]>;
  updateTaskProgress(userId: number, taskId: number, increment?: number): Promise<UserTaskProgress | undefined>;
  completeUserTask(userId: number, taskId: number): Promise<UserTaskProgress | undefined>;
  
  // Theme methods
  getBoardThemes(): Promise<BoardTheme[]>;
  getPieceThemes(): Promise<PieceTheme[]>;
  createBoardTheme(theme: InsertBoardTheme): Promise<BoardTheme>;
  createPieceTheme(theme: InsertPieceTheme): Promise<PieceTheme>;
  purchaseTheme(walletAddress: string, themeType: 'board' | 'piece', themeId: number): Promise<boolean>;
  
  // Messenger methods
  createMessengerProfile(profile: InsertMessengerProfile): Promise<MessengerProfile>;
  getMessengerProfile(userId: number): Promise<MessengerProfile | undefined>;
  updateMessengerProfile(userId: number, updates: Partial<MessengerProfile>): Promise<MessengerProfile | undefined>;
  
  createConversation(conversation: InsertMessengerConversation): Promise<MessengerConversation>;
  getConversation(conversationId: string): Promise<MessengerConversation | undefined>;
  getUserConversations(userId: number): Promise<MessengerConversation[]>;
  
  addParticipant(participant: InsertMessengerParticipant): Promise<MessengerParticipant>;
  getConversationParticipants(conversationId: string): Promise<MessengerParticipant[]>;
  
  sendMessage(message: InsertMessengerMessage): Promise<MessengerMessage>;
  getConversationMessages(conversationId: string, limit?: number, offset?: number): Promise<MessengerMessage[]>;
  
  // Friendship methods
  sendFriendRequest(friendship: InsertFriendship): Promise<Friendship>;
  respondToFriendRequest(id: number, status: 'accepted' | 'rejected' | 'blocked'): Promise<Friendship | undefined>;
  getUserFriends(userId: number): Promise<User[]>;
  
  // File attachment methods
  uploadFile(fileAttachment: InsertFileAttachment): Promise<FileAttachment>;
  getFile(fileId: number): Promise<FileAttachment | undefined>;
  getMessageFiles(messageId: number): Promise<FileAttachment[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private games: Map<string, Game>;
  private chatMessages: Map<string, ChatMessage[]>;
  private dailyTasks: Map<number, DailyTask>;
  private userTaskProgress: Map<string, UserTaskProgress>; // Key: `${userId}-${taskId}-${dateString}`
  private boardThemes: Map<string, BoardTheme>;
  private pieceThemes: Map<string, PieceTheme>;
  private transactions: Map<string, Transaction>; // Key: transactionId
  private messengerProfiles: Map<number, MessengerProfile>; // Key: userId
  private messengerConversations: Map<string, MessengerConversation>; // Key: conversationId
  private messengerParticipants: Map<string, MessengerParticipant[]>; // Key: conversationId
  private messengerMessages: Map<string, MessengerMessage[]>; // Key: conversationId
  private friendships: Map<number, Friendship>; // Key: id
  private fileAttachments: Map<number, FileAttachment>; // Key: id
  private userId: number;
  private messageId: number;
  private taskId: number;
  private taskProgressId: number;
  private boardThemeId: number;
  private pieceThemeId: number;
  private transactionId: number;
  private profileId: number;
  private conversationId: number;
  private participantId: number;
  private friendshipId: number;
  private fileId: number;

  constructor() {
    this.users = new Map();
    this.games = new Map();
    this.chatMessages = new Map();
    this.dailyTasks = new Map();
    this.userTaskProgress = new Map();
    this.boardThemes = new Map();
    this.pieceThemes = new Map();
    this.transactions = new Map();
    this.messengerProfiles = new Map();
    this.messengerConversations = new Map();
    this.messengerParticipants = new Map();
    this.messengerMessages = new Map();
    this.friendships = new Map();
    this.fileAttachments = new Map();
    
    this.userId = 1;
    this.messageId = 1;
    this.taskId = 1;
    this.taskProgressId = 1;
    this.boardThemeId = 1;
    this.pieceThemeId = 1;
    this.transactionId = 1;
    this.profileId = 1;
    this.conversationId = 1;
    this.participantId = 1;
    this.friendshipId = 1;
    this.fileId = 1;
    
    // Initialize default themes
    this.initializeDefaultThemes();
  }
  
  private initializeDefaultThemes() {
    // Default board themes
    const defaultBoardThemes: InsertBoardTheme[] = [
      {
        name: "standard",
        displayName: "Standard",
        description: "Classic brown and beige chess board",
        previewImage: "/themes/boards/standard.png",
        primaryColor: "#B58863",
        secondaryColor: "#F0D9B5",
        isPremium: false,
        price: 0
      },
      {
        name: "blue",
        displayName: "Ocean Blue",
        description: "Calming blue chess board",
        previewImage: "/themes/boards/blue.png",
        primaryColor: "#4682B4",
        secondaryColor: "#B0E0E6",
        isPremium: false,
        price: 0
      },
      {
        name: "green",
        displayName: "Forest Green",
        description: "Traditional tournament board with green squares",
        previewImage: "/themes/boards/green.png",
        primaryColor: "#769656",
        secondaryColor: "#EEEED2",
        isPremium: false,
        price: 0
      },
      {
        name: "red",
        displayName: "Ruby Red",
        description: "Vibrant red and white board",
        previewImage: "/themes/boards/red.png",
        primaryColor: "#B22222",
        secondaryColor: "#F0D9B5",
        isPremium: true,
        price: 5
      },
      {
        name: "purple",
        displayName: "Royal Purple",
        description: "Luxurious purple and gold board",
        previewImage: "/themes/boards/purple.png",
        primaryColor: "#663399",
        secondaryColor: "#FFD700",
        isPremium: true,
        price: 10
      }
    ];
    
    // Default piece themes
    const defaultPieceThemes: InsertPieceTheme[] = [
      {
        name: "standard",
        displayName: "Standard",
        description: "Classic chess pieces",
        previewImage: "/themes/pieces/standard.png",
        folderPath: "/themes/pieces/standard",
        isPremium: false,
        price: 0
      },
      {
        name: "neo",
        displayName: "Neo",
        description: "Modern minimalist pieces",
        previewImage: "/themes/pieces/neo.png",
        folderPath: "/themes/pieces/neo",
        isPremium: false,
        price: 0
      },
      {
        name: "cartoon",
        displayName: "Cartoon",
        description: "Fun cartoon style pieces",
        previewImage: "/themes/pieces/cartoon.png",
        folderPath: "/themes/pieces/cartoon",
        isPremium: true,
        price: 5
      },
      {
        name: "metal",
        displayName: "Metal",
        description: "Metallic 3D rendered pieces",
        previewImage: "/themes/pieces/metal.png",
        folderPath: "/themes/pieces/metal",
        isPremium: true,
        price: 10
      }
    ];
    
    // Add default daily tasks
    const defaultDailyTasks: InsertDailyTask[] = [
      {
        title: "First Game of the Day",
        description: "Play your first game today",
        rewardAmount: 1,
        taskType: "play_game",
        requiredCount: 1,
        active: true
      },
      {
        title: "Win a Game",
        description: "Win a chess game today",
        rewardAmount: 2,
        taskType: "win_game",
        requiredCount: 1,
        active: true
      },
      {
        title: "Chess Master",
        description: "Play 3 games today",
        rewardAmount: 3,
        taskType: "play_game",
        requiredCount: 3,
        active: true
      }
    ];
    
    // Initialize themes
    defaultBoardThemes.forEach(theme => {
      this.createBoardTheme(theme);
    });
    
    defaultPieceThemes.forEach(theme => {
      this.createPieceTheme(theme);
    });
    
    // Initialize daily tasks
    defaultDailyTasks.forEach(task => {
      this.createDailyTask(task);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.id === id) {
        return user;
      }
    }
    return undefined;
  }

  async getUserByWallet(walletAddress: string): Promise<User | undefined> {
    return this.users.get(walletAddress.toLowerCase());
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const walletAddress = insertUser.walletAddress.toLowerCase();
    
    // Check if user already exists
    const existingUser = await this.getUserByWallet(walletAddress);
    if (existingUser) {
      return existingUser;
    }
    
    const id = this.userId++;
    const user: User = {
      id,
      walletAddress,
      username: insertUser.username || null,
      wins: 0,
      losses: 0,
      draws: 0,
      igyBalance: 0,
      lastSeen: new Date(),
      createdAt: new Date(),
      invitedBy: insertUser.invitedBy || null,
      paidInvites: 0,
      hasMessengerAccess: false,
      preferences: insertUser.preferences || {
        boardTheme: "standard",
        pieceTheme: "standard",
        soundEnabled: true
      }
    };
    
    this.users.set(walletAddress, user);
    return user;
  }

  async updateUserStats(walletAddress: string, result: "win" | "loss" | "draw"): Promise<User | undefined> {
    const user = await this.getUserByWallet(walletAddress.toLowerCase());
    if (!user) return undefined;
    
    const updatedUser = { ...user };
    
    if (result === "win") {
      updatedUser.wins += 1;
    } else if (result === "loss") {
      updatedUser.losses += 1;
    } else {
      updatedUser.draws += 1;
    }
    
    updatedUser.lastSeen = new Date();
    this.users.set(walletAddress.toLowerCase(), updatedUser);
    
    return updatedUser;
  }

  async updateUserBalance(walletAddress: string, balance: number): Promise<User | undefined> {
    const user = await this.getUserByWallet(walletAddress.toLowerCase());
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      igyBalance: balance,
      lastSeen: new Date()
    };
    
    this.users.set(walletAddress.toLowerCase(), updatedUser);
    return updatedUser;
  }

  // Payment methods
  async chargeTokens(walletAddress: string, amount: number, reason: string): Promise<boolean> {
    const user = await this.getUserByWallet(walletAddress.toLowerCase());
    if (!user) return false;
    
    // Check if user has enough balance
    if (!user.igyBalance || user.igyBalance < amount) {
      return false;
    }
    
    // Update user balance
    await this.updateUserBalance(walletAddress, user.igyBalance - amount);
    
    // Record transaction
    const transactionId = `tx_${uuidv4()}`;
    const transaction: Transaction = {
      id: this.transactionId++,
      transactionId,
      fromWalletAddress: walletAddress.toLowerCase(),
      toWalletAddress: null, // System operation
      amount,
      type: "charge",
      reason,
      status: "completed",
      data: {},
      timestamp: new Date(),
      blockchainTxHash: null
    };
    
    this.transactions.set(transactionId, transaction);
    return true;
  }
  
  async addTokens(walletAddress: string, amount: number, reason: string): Promise<boolean> {
    const user = await this.getUserByWallet(walletAddress.toLowerCase());
    if (!user) return false;
    
    // Update user balance
    await this.updateUserBalance(walletAddress, (user.igyBalance || 0) + amount);
    
    // Record transaction
    const transactionId = `tx_${uuidv4()}`;
    const transaction: Transaction = {
      id: this.transactionId++,
      transactionId,
      fromWalletAddress: null, // System operation
      toWalletAddress: walletAddress.toLowerCase(),
      amount,
      type: "add",
      reason,
      status: "completed",
      data: {},
      timestamp: new Date(),
      blockchainTxHash: null
    };
    
    this.transactions.set(transactionId, transaction);
    return true;
  }
  
  async transferTokens(fromWalletAddress: string, toWalletAddress: string, amount: number, reason: string): Promise<boolean> {
    const fromUser = await this.getUserByWallet(fromWalletAddress.toLowerCase());
    const toUser = await this.getUserByWallet(toWalletAddress.toLowerCase());
    
    if (!fromUser || !toUser) return false;
    
    // Check if sender has enough balance
    if (!fromUser.igyBalance || fromUser.igyBalance < amount) {
      return false;
    }
    
    // Update balances
    await this.updateUserBalance(fromWalletAddress, fromUser.igyBalance - amount);
    await this.updateUserBalance(toWalletAddress, (toUser.igyBalance || 0) + amount);
    
    // Record transaction
    const transactionId = `tx_${uuidv4()}`;
    const transaction: Transaction = {
      id: this.transactionId++,
      transactionId,
      fromWalletAddress: fromWalletAddress.toLowerCase(),
      toWalletAddress: toWalletAddress.toLowerCase(),
      amount,
      type: "transfer",
      reason,
      status: "completed",
      data: {},
      timestamp: new Date(),
      blockchainTxHash: null
    };
    
    this.transactions.set(transactionId, transaction);
    return true;
  }
  
  async getTransactionHistory(walletAddress: string): Promise<Transaction[]> {
    const lowerWalletAddress = walletAddress.toLowerCase();
    const userTransactions: Transaction[] = [];
    
    for (const transaction of this.transactions.values()) {
      if (
        transaction.fromWalletAddress === lowerWalletAddress || 
        transaction.toWalletAddress === lowerWalletAddress
      ) {
        userTransactions.push(transaction);
      }
    }
    
    // Sort by timestamp (newest first)
    userTransactions.sort((a, b) => 
      b.timestamp.getTime() - a.timestamp.getTime()
    );
    
    return userTransactions;
  }

  // Game methods
  async createGame(insertGame: InsertGame): Promise<Game> {
    const game: Game = {
      id: this.games.size + 1,
      gameId: insertGame.gameId || uuidv4(),
      playerWhite: insertGame.playerWhite.toLowerCase(),
      playerBlack: insertGame.playerBlack ? insertGame.playerBlack.toLowerCase() : null,
      status: "waiting",
      winner: null,
      fen: "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
      pgn: null,
      timeLimit: insertGame.timeLimit || 3600,
      isPublic: insertGame.isPublic !== undefined ? insertGame.isPublic : true,
      inviteCode: insertGame.inviteCode || null,
      startTime: null,
      endTime: null,
      lastMoveTime: null,
      drawOfferedBy: null,
      moveHistory: [],
      boardTheme: insertGame.boardTheme || "standard",
      pieceTheme: insertGame.pieceTheme || "standard",
      videoEnabled: insertGame.videoEnabled || false
    };
    
    this.games.set(game.gameId, game);
    return game;
  }

  async getGameById(gameId: string): Promise<Game | undefined> {
    return this.games.get(gameId);
  }

  async updateGame(gameId: string, updates: Partial<Game>): Promise<Game | undefined> {
    const game = await this.getGameById(gameId);
    if (!game) return undefined;
    
    const updatedGame = { ...game, ...updates };
    this.games.set(gameId, updatedGame);
    
    return updatedGame;
  }

  async getActiveGameForUser(walletAddress: string): Promise<Game | undefined> {
    const lowerWalletAddress = walletAddress.toLowerCase();
    
    for (const game of this.games.values()) {
      if ((game.playerWhite === lowerWalletAddress || game.playerBlack === lowerWalletAddress) && 
          (game.status === "waiting" || game.status === "active")) {
        return game;
      }
    }
    
    return undefined;
  }

  async getPublicGames(): Promise<Game[]> {
    const publicGames: Game[] = [];
    
    for (const game of this.games.values()) {
      if (game.isPublic && game.status === "waiting" && !game.playerBlack) {
        publicGames.push(game);
      }
    }
    
    return publicGames;
  }

  async makeMove(gameId: string, walletAddress: string, from: string, to: string, promotion: string = "q"): Promise<Game | undefined> {
    const game = await this.getGameById(gameId);
    if (!game || game.status !== "active") return undefined;
    
    const lowerWalletAddress = walletAddress.toLowerCase();
    
    // Check if it's the player's turn
    const chess = new Chess(game.fen);
    const turn = chess.turn();
    
    if ((turn === "w" && game.playerWhite !== lowerWalletAddress) || 
        (turn === "b" && game.playerBlack !== lowerWalletAddress)) {
      return undefined; // Not this player's turn
    }
    
    // Make the move
    try {
      const moveResult = chess.move({ from, to, promotion });
      if (!moveResult) return undefined;
      
      // Update game state
      const updatedGame: Partial<Game> = {
        fen: chess.fen(),
        pgn: chess.pgn(),
        lastMoveTime: new Date()
      };
      
      // Check if game is over
      if (chess.isGameOver()) {
        updatedGame.status = "completed";
        updatedGame.endTime = new Date();
        
        if (chess.isCheckmate()) {
          // Winner is the player who just moved
          updatedGame.winner = lowerWalletAddress;
          
          // Update player stats
          await this.updateUserStats(lowerWalletAddress, "win");
          await this.updateUserStats(
            lowerWalletAddress === game.playerWhite ? game.playerBlack! : game.playerWhite, 
            "loss"
          );
        } else {
          // Game ended in draw
          updatedGame.winner = "draw";
          
          // Update player stats
          await this.updateUserStats(game.playerWhite, "draw");
          if (game.playerBlack) {
            await this.updateUserStats(game.playerBlack, "draw");
          }
        }
      }
      
      // Update move history
      const moveHistory = [...(game.moveHistory || [])];
      const moveIndex = Math.floor(chess.moveNumber() - 1);
      
      if (!moveHistory[moveIndex]) {
        moveHistory[moveIndex] = ["", ""];
      }
      
      const moveNotation = moveResult.san;
      if (turn === "w") {
        moveHistory[moveIndex][0] = moveNotation;
      } else {
        moveHistory[moveIndex][1] = moveNotation;
      }
      
      updatedGame.moveHistory = moveHistory;
      
      // Apply all updates
      return await this.updateGame(gameId, updatedGame);
    } catch (error) {
      console.error("Error making move:", error);
      return undefined;
    }
  }

  async resignGame(gameId: string, walletAddress: string): Promise<Game | undefined> {
    const game = await this.getGameById(gameId);
    if (!game || game.status !== "active") return undefined;
    
    const lowerWalletAddress = walletAddress.toLowerCase();
    
    // Check if player is part of this game
    if (game.playerWhite !== lowerWalletAddress && game.playerBlack !== lowerWalletAddress) {
      return undefined;
    }
    
    // Determine winner (the other player)
    const winner = game.playerWhite === lowerWalletAddress ? game.playerBlack : game.playerWhite;
    
    // Update game status
    const updatedGame = await this.updateGame(gameId, {
      status: "completed",
      winner,
      endTime: new Date()
    });
    
    // Update player stats
    if (winner) {
      await this.updateUserStats(winner, "win");
    }
    await this.updateUserStats(lowerWalletAddress, "loss");
    
    return updatedGame;
  }

  async offerDraw(gameId: string, walletAddress: string): Promise<Game | undefined> {
    const game = await this.getGameById(gameId);
    if (!game || game.status !== "active") return undefined;
    
    const lowerWalletAddress = walletAddress.toLowerCase();
    
    // Check if player is part of this game
    if (game.playerWhite !== lowerWalletAddress && game.playerBlack !== lowerWalletAddress) {
      return undefined;
    }
    
    // Set draw offer
    return await this.updateGame(gameId, {
      drawOfferedBy: lowerWalletAddress
    });
  }

  async respondToDrawOffer(gameId: string, walletAddress: string, accept: boolean): Promise<Game | undefined> {
    const game = await this.getGameById(gameId);
    if (!game || game.status !== "active" || !game.drawOfferedBy) return undefined;
    
    const lowerWalletAddress = walletAddress.toLowerCase();
    
    // Check if player is part of this game
    if (game.playerWhite !== lowerWalletAddress && game.playerBlack !== lowerWalletAddress) {
      return undefined;
    }
    
    // Check if this player is the one who needs to respond
    if (game.drawOfferedBy === lowerWalletAddress) return undefined;
    
    if (accept) {
      // End game in draw
      const updatedGame = await this.updateGame(gameId, {
        status: "completed",
        winner: "draw",
        endTime: new Date(),
        drawOfferedBy: null
      });
      
      // Update player stats
      await this.updateUserStats(game.playerWhite, "draw");
      if (game.playerBlack) {
        await this.updateUserStats(game.playerBlack, "draw");
      }
      
      return updatedGame;
    } else {
      // Clear draw offer
      return await this.updateGame(gameId, {
        drawOfferedBy: null
      });
    }
  }

  // Chat methods
  async addChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const message: ChatMessage = {
      id: this.messageId++,
      gameId: insertMessage.gameId,
      sender: insertMessage.sender.toLowerCase(),
      content: insertMessage.content,
      timestamp: new Date()
    };
    
    // Get existing messages for this game or create new array
    const gameMessages = this.chatMessages.get(insertMessage.gameId) || [];
    
    // Add new message
    gameMessages.push(message);
    this.chatMessages.set(insertMessage.gameId, gameMessages);
    
    return message;
  }

  async getChatMessages(gameId: string): Promise<ChatMessage[]> {
    return this.chatMessages.get(gameId) || [];
  }

  // Leaderboard
  async getLeaderboard(): Promise<LeaderboardEntry[]> {
    const entries: LeaderboardEntry[] = [];
    
    for (const user of this.users.values()) {
      entries.push({
        address: user.walletAddress,
        wins: user.wins || 0,
        igyBalance: user.igyBalance || 0,
        rank: 0 // Will be set after sorting
      });
    }
    
    // Sort by wins (primary) and IGY balance (secondary)
    entries.sort((a, b) => {
      if (a.wins !== b.wins) {
        return b.wins - a.wins;
      }
      return b.igyBalance - a.igyBalance;
    });
    
    // Assign ranks
    for (let i = 0; i < entries.length; i++) {
      entries[i].rank = i + 1;
    }
    
    return entries;
  }
  
  // User Preferences
  async updateUserPreferences(walletAddress: string, preferences: Partial<User['preferences']> | any): Promise<User | undefined> {
    const user = await this.getUserByWallet(walletAddress.toLowerCase());
    if (!user) return undefined;
    
    const currentPreferences = user.preferences || {
      boardTheme: "standard",
      pieceTheme: "standard",
      soundEnabled: true
    };
    
    // If hasMessengerAccess is passed, update it directly on the user object
    const hasMessengerAccess = preferences.hasMessengerAccess !== undefined ? 
      preferences.hasMessengerAccess : 
      (user.hasMessengerAccess || false);
    
    // Remove hasMessengerAccess from preferences if it exists
    const prefsToUpdate = { ...preferences };
    if (prefsToUpdate.hasMessengerAccess !== undefined) {
      delete prefsToUpdate.hasMessengerAccess;
    }
    
    const updatedUser = { 
      ...user, 
      hasMessengerAccess,
      preferences: {
        ...currentPreferences,
        ...prefsToUpdate
      },
      lastSeen: new Date()
    };
    
    this.users.set(walletAddress.toLowerCase(), updatedUser);
    return updatedUser;
  }
  
  async updateUserPaidInvites(walletAddress: string, increment: boolean = true): Promise<User | undefined> {
    const user = await this.getUserByWallet(walletAddress.toLowerCase());
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      paidInvites: (user.paidInvites || 0) + (increment ? 1 : 0),
      lastSeen: new Date()
    };
    
    this.users.set(walletAddress.toLowerCase(), updatedUser);
    
    // Check if user now has 3 or more paid invites and grant messenger access
    if (updatedUser.paidInvites >= 3 && !updatedUser.hasMessengerAccess) {
      return this.updateUserPreferences(walletAddress, { hasMessengerAccess: true });
    }
    
    return updatedUser;
  }
  
  async checkAndGrantMessengerAccess(walletAddress: string): Promise<boolean> {
    const user = await this.getUserByWallet(walletAddress.toLowerCase());
    if (!user) return false;
    
    // User already has messenger access
    if (user.hasMessengerAccess) {
      return true;
    }
    
    // Check if user has 3 or more paid invites
    if (user.paidInvites && user.paidInvites >= 3) {
      const updatedUser = await this.updateUserPreferences(walletAddress, { hasMessengerAccess: true });
      return !!updatedUser?.hasMessengerAccess;
    }
    
    return false;
  }
  
  // Daily Tasks
  async getDailyTasks(): Promise<DailyTask[]> {
    return Array.from(this.dailyTasks.values());
  }
  
  async getDailyTask(id: number): Promise<DailyTask | undefined> {
    return this.dailyTasks.get(id);
  }
  
  async createDailyTask(task: InsertDailyTask): Promise<DailyTask> {
    const id = this.taskId++;
    const dailyTask: DailyTask = {
      id,
      title: task.title,
      description: task.description,
      rewardAmount: task.rewardAmount || 1,
      taskType: task.taskType,
      requiredCount: task.requiredCount || 1,
      active: task.active !== undefined ? task.active : true,
      createdAt: new Date()
    };
    
    this.dailyTasks.set(id, dailyTask);
    return dailyTask;
  }
  
  async updateDailyTask(id: number, updates: Partial<DailyTask>): Promise<DailyTask | undefined> {
    const task = await this.getDailyTask(id);
    if (!task) return undefined;
    
    const updatedTask = { ...task, ...updates };
    this.dailyTasks.set(id, updatedTask);
    
    return updatedTask;
  }
  
  async deleteDailyTask(id: number): Promise<boolean> {
    const exists = this.dailyTasks.has(id);
    if (exists) {
      this.dailyTasks.delete(id);
      return true;
    }
    return false;
  }
  
  // User Task Progress
  async getUserTaskProgress(userId: number, date?: Date): Promise<UserTaskProgress[]> {
    const result: UserTaskProgress[] = [];
    const targetDate = date ? date : new Date();
    const dateString = targetDate.toISOString().split('T')[0]; // YYYY-MM-DD
    
    for (const [key, progress] of this.userTaskProgress.entries()) {
      if (key.startsWith(`${userId}-`) && (!date || key.endsWith(`-${dateString}`))) {
        result.push(progress);
      }
    }
    
    return result;
  }
  
  async updateTaskProgress(userId: number, taskId: number, increment: number = 1): Promise<UserTaskProgress | undefined> {
    const dateString = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const key = `${userId}-${taskId}-${dateString}`;
    
    // Get existing progress or create new
    let progress = this.userTaskProgress.get(key);
    
    if (!progress) {
      // Create new progress entry
      progress = {
        id: this.taskProgressId++,
        userId,
        taskId,
        currentCount: 0,
        completed: false,
        completedAt: null,
        lastUpdated: new Date(),
        date: new Date()
      };
    }
    
    // Get the task to check required count
    const task = await this.getDailyTask(taskId);
    if (!task) return undefined;
    
    // Update progress
    const newCount = progress.currentCount + increment;
    const completed = newCount >= task.requiredCount;
    
    const updatedProgress: UserTaskProgress = {
      ...progress,
      currentCount: newCount,
      completed,
      completedAt: completed && !progress.completed ? new Date() : progress.completedAt,
      lastUpdated: new Date()
    };
    
    // If task was just completed, award IGY tokens
    if (completed && !progress.completed) {
      const user = await this.getUser(userId);
      if (user) {
        await this.updateUserBalance(
          user.walletAddress, 
          (user.igyBalance || 0) + task.rewardAmount
        );
      }
    }
    
    this.userTaskProgress.set(key, updatedProgress);
    return updatedProgress;
  }
  
  async completeUserTask(userId: number, taskId: number): Promise<UserTaskProgress | undefined> {
    const task = await this.getDailyTask(taskId);
    if (!task) return undefined;
    
    // Complete task by setting current count to required count
    return this.updateTaskProgress(userId, taskId, task.requiredCount);
  }
  
  // Board Themes
  async getBoardThemes(): Promise<BoardTheme[]> {
    return Array.from(this.boardThemes.values());
  }
  
  async createBoardTheme(theme: InsertBoardTheme): Promise<BoardTheme> {
    const id = this.boardThemeId++;
    const boardTheme: BoardTheme = {
      id,
      name: theme.name,
      displayName: theme.displayName,
      description: theme.description || null,
      previewImage: theme.previewImage || null,
      primaryColor: theme.primaryColor,
      secondaryColor: theme.secondaryColor,
      isPremium: theme.isPremium !== undefined ? theme.isPremium : false,
      price: theme.price || 0
    };
    
    this.boardThemes.set(theme.name, boardTheme);
    return boardTheme;
  }
  
  // Piece Themes
  async getPieceThemes(): Promise<PieceTheme[]> {
    return Array.from(this.pieceThemes.values());
  }
  
  async createPieceTheme(theme: InsertPieceTheme): Promise<PieceTheme> {
    const id = this.pieceThemeId++;
    const pieceTheme: PieceTheme = {
      id,
      name: theme.name,
      displayName: theme.displayName,
      description: theme.description || null,
      previewImage: theme.previewImage || null,
      folderPath: theme.folderPath,
      isPremium: theme.isPremium !== undefined ? theme.isPremium : false,
      price: theme.price || 0
    };
    
    this.pieceThemes.set(theme.name, pieceTheme);
    return pieceTheme;
  }
  
  // Purchase theme
  async purchaseTheme(walletAddress: string, themeType: 'board' | 'piece', themeId: number): Promise<boolean> {
    const user = await this.getUserByWallet(walletAddress.toLowerCase());
    if (!user) return false;
    
    let theme;
    if (themeType === 'board') {
      for (const t of this.boardThemes.values()) {
        if (t.id === themeId) {
          theme = t;
          break;
        }
      }
    } else {
      for (const t of this.pieceThemes.values()) {
        if (t.id === themeId) {
          theme = t;
          break;
        }
      }
    }
    
    if (!theme) return false;
    
    // Check if theme is premium and user has enough IGY
    if (theme.isPremium && user.igyBalance !== null) {
      if (user.igyBalance < theme.price) {
        return false;
      }
      
      // Deduct IGY balance
      await this.updateUserBalance(
        walletAddress,
        user.igyBalance - theme.price
      );
      
      // Set user preference to the new theme
      const preferences: Partial<User['preferences']> = {};
      if (themeType === 'board') {
        preferences.boardTheme = theme.name;
      } else {
        preferences.pieceTheme = theme.name;
      }
      
      await this.updateUserPreferences(walletAddress, preferences);
      
      return true;
    }
    
    // Free theme, just set preference
    const preferences: Partial<User['preferences']> = {};
    if (themeType === 'board') {
      preferences.boardTheme = theme.name;
    } else {
      preferences.pieceTheme = theme.name;
    }
    
    await this.updateUserPreferences(walletAddress, preferences);
    
    return true;
  }

  // Messenger profile methods
  async createMessengerProfile(profile: InsertMessengerProfile): Promise<MessengerProfile> {
    const id = this.profileId++;

    const messengerProfile: MessengerProfile = {
      id,
      userId: profile.userId,
      displayName: profile.displayName,
      bio: profile.bio || null,
      avatarUrl: profile.avatarUrl || null,
      isVerified: false,
      interests: profile.interests || [],
      location: profile.location || null,
      contactInfo: profile.contactInfo || {},
      privacySettings: profile.privacySettings || {
        showOnline: true,
        allowMessages: true,
        allowFriendRequests: true,
      },
      createdAt: new Date(),
      updatedAt: new Date(),
      lastActive: new Date(),
      status: "active",
    };

    this.messengerProfiles.set(id, messengerProfile);
    return messengerProfile;
  }

  async getMessengerProfile(userId: number): Promise<MessengerProfile | undefined> {
    const profile = this.messengerProfiles.get(userId);
    return profile || undefined;
  }

  async updateMessengerProfile(userId: number, updates: Partial<MessengerProfile>): Promise<MessengerProfile | undefined> {
    const profile = await this.getMessengerProfile(userId);
    if (!profile) return undefined;

    const updatedProfile = {
      ...profile,
      ...updates,
      updatedAt: new Date(),
    };

    this.messengerProfiles.set(userId, updatedProfile);
    return updatedProfile;
  }

  // Conversation methods
  async createConversation(conversation: InsertMessengerConversation): Promise<MessengerConversation> {
    const id = this.conversationId++;
    const conversationId = uuidv4();

    const messengerConversation: MessengerConversation = {
      id,
      conversationId,
      name: conversation.name || null,
      type: conversation.type || "direct",
      createdBy: conversation.createdBy,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastMessageAt: new Date(),
      isEncrypted: conversation.isEncrypted || false,
      metadata: conversation.metadata || {},
    };

    this.messengerConversations.set(conversationId, messengerConversation);
    return messengerConversation;
  }

  async getConversation(conversationId: string): Promise<MessengerConversation | undefined> {
    return this.messengerConversations.get(conversationId);
  }

  async getUserConversations(userId: number): Promise<MessengerConversation[]> {
    // Get all conversations where this user is a participant
    const userParticipations: MessengerParticipant[] = [];
    for (const [convId, participants] of this.messengerParticipants.entries()) {
      const userParticipation = participants.find(p => p.userId === userId && p.isActive);
      if (userParticipation) {
        userParticipations.push(userParticipation);
      }
    }

    // Get the actual conversations
    const conversations: MessengerConversation[] = [];
    for (const participation of userParticipations) {
      const conversation = await this.getConversation(participation.conversationId);
      if (conversation) {
        conversations.push(conversation);
      }
    }

    // Sort by most recent message
    return conversations.sort((a, b) => {
      if (!a.lastMessageAt || !b.lastMessageAt) return 0;
      return b.lastMessageAt.getTime() - a.lastMessageAt.getTime();
    });
  }

  // Participant methods
  async addParticipant(participant: InsertMessengerParticipant): Promise<MessengerParticipant> {
    const id = this.participantId++;

    const messengerParticipant: MessengerParticipant = {
      id,
      conversationId: participant.conversationId,
      userId: participant.userId,
      role: participant.role || "member",
      joinedAt: new Date(),
      lastReadMessageId: null,
      isActive: true,
      isMuted: false,
      isPinned: false,
    };

    // Get existing participants for this conversation or initialize a new array
    const participants = this.messengerParticipants.get(participant.conversationId) || [];
    participants.push(messengerParticipant);
    this.messengerParticipants.set(participant.conversationId, participants);

    return messengerParticipant;
  }

  async getConversationParticipants(conversationId: string): Promise<MessengerParticipant[]> {
    return this.messengerParticipants.get(conversationId) || [];
  }

  // Message methods
  async sendMessage(message: InsertMessengerMessage): Promise<MessengerMessage> {
    const id = this.messageId++;

    const messengerMessage: MessengerMessage = {
      id,
      conversationId: message.conversationId,
      senderId: message.senderId,
      messageType: message.messageType || "text",
      content: message.content,
      metadata: message.metadata || {},
      sentAt: new Date(),
      editedAt: null,
      isDeleted: false,
      replyToId: message.replyToId || null,
      reactions: {},
    };

    // Get existing messages for this conversation or initialize a new array
    const messages = this.messengerMessages.get(message.conversationId) || [];
    messages.push(messengerMessage);
    this.messengerMessages.set(message.conversationId, messages);

    // Update the conversation's lastMessageAt
    const conversation = await this.getConversation(message.conversationId);
    if (conversation) {
      conversation.lastMessageAt = new Date();
      conversation.updatedAt = new Date();
      this.messengerConversations.set(message.conversationId, conversation);
    }

    return messengerMessage;
  }

  async getConversationMessages(conversationId: string, limit: number = 50, offset: number = 0): Promise<MessengerMessage[]> {
    const messages = this.messengerMessages.get(conversationId) || [];
    
    // Sort by sentAt (oldest first)
    const sortedMessages = [...messages].sort((a, b) => {
      if (!a.sentAt || !b.sentAt) return 0;
      return a.sentAt.getTime() - b.sentAt.getTime();
    });
    
    // Apply pagination
    return sortedMessages.slice(offset, offset + limit);
  }

  // Friendship methods
  async sendFriendRequest(friendship: InsertFriendship): Promise<Friendship> {
    const id = this.friendshipId++;

    const newFriendship: Friendship = {
      id,
      requesterId: friendship.requesterId,
      addresseeId: friendship.addresseeId,
      status: friendship.status || "pending",
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.friendships.set(id, newFriendship);
    return newFriendship;
  }

  async respondToFriendRequest(id: number, status: 'accepted' | 'rejected' | 'blocked'): Promise<Friendship | undefined> {
    const friendship = this.friendships.get(id);
    if (!friendship) return undefined;

    const updatedFriendship = {
      ...friendship,
      status,
      updatedAt: new Date(),
    };

    this.friendships.set(id, updatedFriendship);
    return updatedFriendship;
  }

  async getUserFriends(userId: number): Promise<User[]> {
    const friends: User[] = [];
    
    for (const friendship of this.friendships.values()) {
      if (friendship.status === 'accepted') {
        if (friendship.requesterId === userId) {
          const friend = await this.getUser(friendship.addresseeId);
          if (friend) friends.push(friend);
        } else if (friendship.addresseeId === userId) {
          const friend = await this.getUser(friendship.requesterId);
          if (friend) friends.push(friend);
        }
      }
    }
    
    return friends;
  }

  // File attachment methods
  async uploadFile(fileAttachment: InsertFileAttachment): Promise<FileAttachment> {
    const id = this.fileId++;

    const newFileAttachment: FileAttachment = {
      id,
      messageId: fileAttachment.messageId || null,
      userId: fileAttachment.userId,
      fileName: fileAttachment.fileName,
      fileSize: fileAttachment.fileSize,
      mimeType: fileAttachment.mimeType,
      filePath: fileAttachment.filePath,
      thumbnailPath: fileAttachment.thumbnailPath || null,
      uploadedAt: new Date(),
      expiresAt: fileAttachment.expiresAt || null,
      isPublic: fileAttachment.isPublic || false,
      downloadCount: 0,
      status: "active",
    };

    this.fileAttachments.set(id, newFileAttachment);
    return newFileAttachment;
  }

  async getFile(fileId: number): Promise<FileAttachment | undefined> {
    return this.fileAttachments.get(fileId);
  }

  async getMessageFiles(messageId: number): Promise<FileAttachment[]> {
    const files: FileAttachment[] = [];
    
    for (const file of this.fileAttachments.values()) {
      if (file.messageId === messageId && file.status === "active") {
        files.push(file);
      }
    }
    
    return files;
  }
}

export const storage = new MemStorage();
