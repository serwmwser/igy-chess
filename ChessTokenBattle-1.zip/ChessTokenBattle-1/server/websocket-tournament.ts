import { WebSocket } from 'ws';
import { IStorage } from './storage';
import { handleTournamentMessage } from './tournament';

// Define client connection types
type Client = {
  id: string;
  ws: WebSocket;
  address: string | null;
};

// Define WebSocket message types
type WebSocketMessage = {
  type: string;
  [key: string]: any;
};

// WebSocket clients map for broadcasting
export const clients: Map<string, Client> = new Map();
// Map wallet addresses to client IDs
export const addressToClientId: Map<string, string> = new Map();

// Export function to process tournament messages
export async function processTournamentMessage(
  message: WebSocketMessage, 
  client: Client, 
  storage: IStorage
) {
  const tournamentMessageTypes = [
    'joinTournament', 
    'submitPuzzleSolution', 
    'getTournamentsList', 
    'getUserTournamentHistory',
    'startTournament'
  ];
  
  if (tournamentMessageTypes.includes(message.type)) {
    try {
      // Handle tournament related messages
      // Pass the clients map from this module to handleTournamentMessage
      await handleTournamentMessage(message, client, storage, clients);
      return true; // Message was handled
    } catch (error) {
      console.error("Error in tournament message handling:", error);
      sendErrorToClient(client, "Error processing tournament action");
      return true; // We still handled it, even though there was an error
    }
  }
  
  return false; // Message was not handled
}

// Helper for error handling
export function sendErrorToClient(client: Client, message: string) {
  if (client.ws.readyState === WebSocket.OPEN) {
    client.ws.send(JSON.stringify({
      type: 'error',
      message
    }));
  }
}