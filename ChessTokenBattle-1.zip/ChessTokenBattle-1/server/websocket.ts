import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { v4 as uuidv4 } from 'uuid';
import { Chess } from 'chess.js';
import { IStorage } from './storage';
import { InsertUser, InsertGame, InsertChatMessage } from '@shared/schema';

// Define client connection types
type Client = {
  id: string;
  ws: WebSocket;
  address: string | null;
};

// Define WebSocket message types
type WebSocketMessage = {
  type: string;
  [key: string]: any;
};

// Keep track of connected clients
const clients: Map<string, Client> = new Map();
// Map wallet addresses to client IDs
const addressToClientId: Map<string, string> = new Map();
// Track game invites and pending games
const gameInvites: Map<string, string> = new Map(); // inviteCode -> gameId
const pendingGames: Map<string, string[]> = new Map(); // gameId -> [players waiting for this game]

export function setupWebSocketServer(server: Server, storage: IStorage) {
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws) => {
    // Assign a unique ID to the client
    const clientId = uuidv4();
    const client: Client = { id: clientId, ws, address: null };
    clients.set(clientId, client);

    console.log(`WebSocket client connected: ${clientId}`);

    // Handle messages
    ws.on('message', async (message) => {
      try {
        const data: WebSocketMessage = JSON.parse(message.toString());
        await handleMessage(data, client, storage);
      } catch (error) {
        console.error('Error processing message:', error);
        sendErrorToClient(client, 'Failed to process message');
      }
    });

    // Handle disconnection
    ws.on('close', () => {
      console.log(`WebSocket client disconnected: ${clientId}`);
      
      // If client was authenticated, remove from the address map
      if (client.address) {
        addressToClientId.delete(client.address);
      }
      
      // Remove from clients
      clients.delete(clientId);
    });

    // Send welcome message
    ws.send(JSON.stringify({ type: 'connected', clientId }));
  });

  return wss;
}

async function handleMessage(message: WebSocketMessage, client: Client, storage: IStorage) {
  const { type } = message;

  // First, try to handle tournament-related messages
  // Import tournament module dynamically to avoid circular dependencies
  const { processTournamentMessage } = await import('./websocket-tournament');
  const wasHandled = await processTournamentMessage(message, client, storage);
  if (wasHandled) {
    return; // Message was handled by tournament module
  }

  // Otherwise, handle regular chess game messages
  switch (type) {
    case 'authenticate':
      await handleAuthenticate(message, client, storage);
      break;
    case 'reconnect':
      await handleReconnect(message, client, storage);
      break;
    case 'createGame':
      await handleCreateGame(message, client, storage);
      break;
    case 'joinGame':
      await handleJoinGame(message, client, storage);
      break;
    case 'makeMove':
      await handleMakeMove(message, client, storage);
      break;
    case 'resign':
      await handleResign(message, client, storage);
      break;
    case 'offerDraw':
      await handleOfferDraw(message, client, storage);
      break;
    case 'respondToDrawOffer':
      await handleRespondToDrawOffer(message, client, storage);
      break;
    case 'chatMessage':
      await handleChatMessage(message, client, storage);
      break;
    case 'timeOut':
      await handleTimeOut(message, client, storage);
      break;
    // WebRTC signaling for video chat
    case 'rtcOffer':
      await handleRTCOffer(message, client, storage);
      break;
    case 'rtcAnswer':
      await handleRTCAnswer(message, client, storage);
      break;
    case 'rtcIceCandidate':
      await handleRTCIceCandidate(message, client, storage);
      break;
    default:
      sendErrorToClient(client, `Unknown message type: ${type}`);
  }
}

async function handleAuthenticate(message: WebSocketMessage, client: Client, storage: IStorage) {
  const { address } = message;
  
  if (!address) {
    return sendErrorToClient(client, 'No wallet address provided');
  }

  // Link this client to the wallet address
  client.address = address.toLowerCase();
  addressToClientId.set(client.address, client.id);

  // Create or get user in storage
  let user = await storage.getUserByWallet(client.address);
  
  if (!user) {
    const insertUser: InsertUser = {
      walletAddress: client.address,
    };
    user = await storage.createUser(insertUser);
  }

  // Send success response
  client.ws.send(JSON.stringify({
    type: 'authenticated',
    address: client.address,
  }));
}

async function handleReconnect(message: WebSocketMessage, client: Client, storage: IStorage) {
  const { address } = message;
  
  if (!address) {
    return sendErrorToClient(client, 'No wallet address provided');
  }

  // Link this client to the wallet address
  client.address = address.toLowerCase();
  addressToClientId.set(client.address, client.id);

  // Check if user has an active game
  const activeGame = await storage.getActiveGameForUser(client.address);
  
  if (activeGame) {
    // Get chat messages for this game
    const chatMessages = await storage.getChatMessages(activeGame.gameId);
    
    // Send game state to client
    client.ws.send(JSON.stringify({
      type: 'gameState',
      game: {
        id: activeGame.gameId,
        playerWhite: activeGame.playerWhite,
        playerBlack: activeGame.playerBlack,
        status: activeGame.status,
        winner: activeGame.winner,
        fen: activeGame.fen,
        timeLimit: activeGame.timeLimit,
        startTime: activeGame.startTime,
        drawOfferedBy: activeGame.drawOfferedBy,
        moveHistory: activeGame.moveHistory || [],
        chatMessages
      }
    }));
  }
}

async function handleCreateGame(message: WebSocketMessage, client: Client, storage: IStorage) {
  if (!client.address) {
    return sendErrorToClient(client, 'You must authenticate first');
  }

  const { 
    timeLimit = 3600, 
    isPublic = true, 
    inviteAddress, 
    boardTheme,
    pieceTheme,
    videoEnabled = false,
    opponentMode = "random"
  } = message;
  
  // Create a new game
  const gameId = uuidv4();
  const inviteCode = uuidv4().slice(0, 8);
  
  // Get user preferences if no themes were specified
  const user = await storage.getUserByWallet(client.address);
  let userBoardTheme = "standard";
  let userPieceTheme = "standard";
  
  if (user && user.preferences) {
    userBoardTheme = user.preferences.boardTheme || "standard";
    userPieceTheme = user.preferences.pieceTheme || "standard";
  }
  
  const insertGame: InsertGame = {
    gameId,
    playerWhite: client.address,
    timeLimit,
    isPublic,
    inviteCode,
    boardTheme: boardTheme || userBoardTheme,
    pieceTheme: pieceTheme || userPieceTheme,
    videoEnabled,
    opponentType: opponentMode  // AI, random, или invite
  };
  
  const game = await storage.createGame(insertGame);
  
  // If this is an invite game, store the invite code
  if (!isPublic) {
    gameInvites.set(inviteCode, gameId);
  }
  
  // If an invite address is specified, notify that player
  if (inviteAddress) {
    const inviteeClientId = addressToClientId.get(inviteAddress.toLowerCase());
    if (inviteeClientId) {
      const inviteeClient = clients.get(inviteeClientId);
      if (inviteeClient && inviteeClient.ws.readyState === WebSocket.OPEN) {
        inviteeClient.ws.send(JSON.stringify({
          type: 'gameInvite',
          gameId,
          inviteCode,
          from: client.address
        }));
      }
    }
    
    // Track in pending games
    const pendingPlayers = pendingGames.get(gameId) || [];
    pendingPlayers.push(inviteAddress.toLowerCase());
    pendingGames.set(gameId, pendingPlayers);
  }
  
  // Confirm game creation to the client
  client.ws.send(JSON.stringify({
    type: 'gameCreated',
    gameId,
    inviteCode,
    isPublic
  }));

  // Send initial game state
  client.ws.send(JSON.stringify({
    type: 'gameState',
    game: {
      id: game.gameId,
      playerWhite: game.playerWhite,
      playerBlack: null,
      status: 'waiting',
      fen: game.fen,
      timeLimit: game.timeLimit,
      moveHistory: [],
      chatMessages: []
    }
  }));
}

async function handleJoinGame(message: WebSocketMessage, client: Client, storage: IStorage) {
  if (!client.address) {
    return sendErrorToClient(client, 'You must authenticate first');
  }

  const { gameId } = message;
  
  if (!gameId) {
    return sendErrorToClient(client, 'Game ID is required');
  }
  
  // Get the game
  const game = await storage.getGameById(gameId);
  
  if (!game) {
    return sendErrorToClient(client, 'Game not found');
  }
  
  // Check if game is already full
  if (game.playerBlack && game.playerWhite) {
    return sendErrorToClient(client, 'Game is already full');
  }
  
  // Check if game is already in progress
  if (game.status !== 'waiting') {
    return sendErrorToClient(client, 'Game is already in progress');
  }
  
  // Make sure player isn't joining their own game
  if (game.playerWhite === client.address) {
    return sendErrorToClient(client, 'Cannot join your own game');
  }
  
  // Join as black player
  const updatedGame = await storage.updateGame(gameId, {
    playerBlack: client.address,
    status: 'active',
    startTime: new Date()
  });
  
  if (!updatedGame) {
    return sendErrorToClient(client, 'Failed to join game');
  }
  
  // Send confirmation to joining player
  client.ws.send(JSON.stringify({
    type: 'gameJoined',
    gameId
  }));
  
  // Notify both players with updated game state
  await broadcastGameState(updatedGame, storage);
}

async function handleMakeMove(message: WebSocketMessage, client: Client, storage: IStorage) {
  if (!client.address) {
    return sendErrorToClient(client, 'You must authenticate first');
  }

  const { gameId, from, to, promotion = 'q' } = message;
  
  if (!gameId || !from || !to) {
    return sendErrorToClient(client, 'Game ID, from, and to are required');
  }
  
  // Make the move
  const updatedGame = await storage.makeMove(gameId, client.address, from, to, promotion);
  
  if (!updatedGame) {
    return sendErrorToClient(client, 'Invalid move or not your turn');
  }
  
  // Create last move info
  const chess = new Chess(updatedGame.fen);
  const history = chess.history({ verbose: true });
  const lastMove = history[history.length - 1];
  
  const lastMoveInfo = {
    player: client.address,
    from: lastMove.from,
    to: lastMove.to,
    notation: lastMove.san,
    timestamp: Date.now()
  };
  
  // Broadcast updated game state to both players
  await broadcastGameState(updatedGame, storage, lastMoveInfo);
}

async function handleResign(message: WebSocketMessage, client: Client, storage: IStorage) {
  if (!client.address) {
    return sendErrorToClient(client, 'You must authenticate first');
  }

  const { gameId } = message;
  
  if (!gameId) {
    return sendErrorToClient(client, 'Game ID is required');
  }
  
  // Resign the game
  const updatedGame = await storage.resignGame(gameId, client.address);
  
  if (!updatedGame) {
    return sendErrorToClient(client, 'Cannot resign game');
  }
  
  // Broadcast updated game state
  await broadcastGameState(updatedGame, storage);
}

async function handleOfferDraw(message: WebSocketMessage, client: Client, storage: IStorage) {
  if (!client.address) {
    return sendErrorToClient(client, 'You must authenticate first');
  }

  const { gameId } = message;
  
  if (!gameId) {
    return sendErrorToClient(client, 'Game ID is required');
  }
  
  // Offer draw
  const updatedGame = await storage.offerDraw(gameId, client.address);
  
  if (!updatedGame) {
    return sendErrorToClient(client, 'Cannot offer draw');
  }
  
  // Notify the opponent
  const game = await storage.getGameById(gameId);
  if (game) {
    const opponentAddress = game.playerWhite === client.address ? game.playerBlack : game.playerWhite;
    
    if (opponentAddress) {
      const opponentClientId = addressToClientId.get(opponentAddress);
      
      if (opponentClientId) {
        const opponentClient = clients.get(opponentClientId);
        
        if (opponentClient && opponentClient.ws.readyState === WebSocket.OPEN) {
          opponentClient.ws.send(JSON.stringify({
            type: 'drawOffered',
            gameId,
            offeredBy: client.address
          }));
        }
      }
    }
  }
  
  // Broadcast updated game state
  await broadcastGameState(updatedGame, storage);
}

async function handleRespondToDrawOffer(message: WebSocketMessage, client: Client, storage: IStorage) {
  if (!client.address) {
    return sendErrorToClient(client, 'You must authenticate first');
  }

  const { gameId, accept } = message;
  
  if (!gameId || accept === undefined) {
    return sendErrorToClient(client, 'Game ID and accept are required');
  }
  
  // Respond to draw offer
  const updatedGame = await storage.respondToDrawOffer(gameId, client.address, accept);
  
  if (!updatedGame) {
    return sendErrorToClient(client, 'Cannot respond to draw offer');
  }
  
  // Broadcast updated game state
  await broadcastGameState(updatedGame, storage);
}

async function handleChatMessage(message: WebSocketMessage, client: Client, storage: IStorage) {
  if (!client.address) {
    return sendErrorToClient(client, 'You must authenticate first');
  }

  const { gameId, content } = message;
  
  if (!gameId || !content) {
    return sendErrorToClient(client, 'Game ID and message content are required');
  }
  
  // Get the game
  const game = await storage.getGameById(gameId);
  
  if (!game) {
    return sendErrorToClient(client, 'Game not found');
  }
  
  // Make sure player is part of this game
  if (game.playerWhite !== client.address && game.playerBlack !== client.address) {
    return sendErrorToClient(client, 'You are not part of this game');
  }
  
  // Add chat message
  const chatMessage: InsertChatMessage = {
    gameId,
    sender: client.address,
    content
  };
  
  const savedMessage = await storage.addChatMessage(chatMessage);
  
  // Get updated chat messages
  const chatMessages = await storage.getChatMessages(gameId);
  
  // Broadcast to both players
  if (game.playerWhite) {
    const whiteClientId = addressToClientId.get(game.playerWhite);
    if (whiteClientId) {
      const whiteClient = clients.get(whiteClientId);
      if (whiteClient && whiteClient.ws.readyState === WebSocket.OPEN) {
        whiteClient.ws.send(JSON.stringify({
          type: 'chatMessages',
          gameId,
          messages: chatMessages
        }));
      }
    }
  }
  
  if (game.playerBlack) {
    const blackClientId = addressToClientId.get(game.playerBlack);
    if (blackClientId) {
      const blackClient = clients.get(blackClientId);
      if (blackClient && blackClient.ws.readyState === WebSocket.OPEN) {
        blackClient.ws.send(JSON.stringify({
          type: 'chatMessages',
          gameId,
          messages: chatMessages
        }));
      }
    }
  }
}

async function handleTimeOut(message: WebSocketMessage, client: Client, storage: IStorage) {
  if (!client.address) {
    return sendErrorToClient(client, 'You must authenticate first');
  }

  const { gameId, player } = message;
  
  if (!gameId || !player) {
    return sendErrorToClient(client, 'Game ID and player are required');
  }
  
  // Get the game
  const game = await storage.getGameById(gameId);
  
  if (!game || game.status !== 'active') {
    return sendErrorToClient(client, 'Game not found or not active');
  }
  
  // Make sure player is part of this game
  if (game.playerWhite !== client.address && game.playerBlack !== client.address) {
    return sendErrorToClient(client, 'You are not part of this game');
  }
  
  // Make sure the timed-out player is the one who should be moving
  const chess = new Chess(game.fen);
  const playerTurn = chess.turn() === 'w' ? game.playerWhite : game.playerBlack;
  
  if (player !== playerTurn) {
    return sendErrorToClient(client, 'Not this player\'s turn');
  }
  
  // Determine winner (the player who didn't time out)
  const winner = player === game.playerWhite ? game.playerBlack : game.playerWhite;
  
  // Update game status
  const updatedGame = await storage.updateGame(gameId, {
    status: 'completed',
    winner,
    endTime: new Date()
  });
  
  if (!updatedGame) {
    return sendErrorToClient(client, 'Failed to update game');
  }
  
  // Update player stats
  if (winner) {
    await storage.updateUserStats(winner, 'win');
  }
  await storage.updateUserStats(player, 'loss');
  
  // Broadcast updated game state
  await broadcastGameState(updatedGame, storage);
}

async function broadcastGameState(game: any, storage: IStorage, lastMove?: any) {
  // Get chat messages
  const chatMessages = await storage.getChatMessages(game.gameId);
  
  // Prepare game state
  const gameState = {
    id: game.gameId,
    playerWhite: game.playerWhite,
    playerBlack: game.playerBlack,
    status: game.status,
    winner: game.winner,
    fen: game.fen,
    timeLimit: game.timeLimit,
    startTime: game.startTime,
    drawOfferedBy: game.drawOfferedBy,
    moveHistory: game.moveHistory || [],
    chatMessages,
    lastMove,
    boardTheme: game.boardTheme || "standard",
    pieceTheme: game.pieceTheme || "standard",
    videoEnabled: game.videoEnabled || false
  };
  
  // Send to white player
  if (game.playerWhite) {
    const whiteClientId = addressToClientId.get(game.playerWhite);
    if (whiteClientId) {
      const whiteClient = clients.get(whiteClientId);
      if (whiteClient && whiteClient.ws.readyState === WebSocket.OPEN) {
        whiteClient.ws.send(JSON.stringify({
          type: 'gameState',
          game: gameState
        }));
      }
    }
  }
  
  // Send to black player
  if (game.playerBlack) {
    const blackClientId = addressToClientId.get(game.playerBlack);
    if (blackClientId) {
      const blackClient = clients.get(blackClientId);
      if (blackClient && blackClient.ws.readyState === WebSocket.OPEN) {
        blackClient.ws.send(JSON.stringify({
          type: 'gameState',
          game: gameState
        }));
      }
    }
  }
}

// WebRTC signaling handlers for video chat
async function handleRTCOffer(message: WebSocketMessage, client: Client, storage: IStorage) {
  if (!client.address) {
    return sendErrorToClient(client, 'You must authenticate first');
  }

  const { gameId, offer } = message;
  
  if (!gameId || !offer) {
    return sendErrorToClient(client, 'Game ID and offer are required');
  }
  
  // Get the game
  const game = await storage.getGameById(gameId);
  
  if (!game) {
    return sendErrorToClient(client, 'Game not found');
  }
  
  // Make sure player is part of this game
  if (game.playerWhite !== client.address && game.playerBlack !== client.address) {
    return sendErrorToClient(client, 'You are not part of this game');
  }
  
  // Make sure video is enabled for this game
  if (!game.videoEnabled) {
    return sendErrorToClient(client, 'Video is not enabled for this game');
  }
  
  // Determine the recipient (opponent)
  const recipient = game.playerWhite === client.address ? game.playerBlack : game.playerWhite;
  
  if (!recipient) {
    return sendErrorToClient(client, 'Opponent not found');
  }
  
  // Forward the offer to the opponent
  const recipientClientId = addressToClientId.get(recipient);
  if (!recipientClientId) {
    return sendErrorToClient(client, 'Opponent not connected');
  }
  
  const recipientClient = clients.get(recipientClientId);
  if (!recipientClient || recipientClient.ws.readyState !== WebSocket.OPEN) {
    return sendErrorToClient(client, 'Opponent not connected');
  }
  
  // Send the offer
  recipientClient.ws.send(JSON.stringify({
    type: 'rtcOffer',
    gameId,
    offer,
    from: client.address
  }));
}

async function handleRTCAnswer(message: WebSocketMessage, client: Client, storage: IStorage) {
  if (!client.address) {
    return sendErrorToClient(client, 'You must authenticate first');
  }

  const { gameId, answer } = message;
  
  if (!gameId || !answer) {
    return sendErrorToClient(client, 'Game ID and answer are required');
  }
  
  // Get the game
  const game = await storage.getGameById(gameId);
  
  if (!game) {
    return sendErrorToClient(client, 'Game not found');
  }
  
  // Make sure player is part of this game
  if (game.playerWhite !== client.address && game.playerBlack !== client.address) {
    return sendErrorToClient(client, 'You are not part of this game');
  }
  
  // Determine the recipient (opponent)
  const recipient = game.playerWhite === client.address ? game.playerBlack : game.playerWhite;
  
  if (!recipient) {
    return sendErrorToClient(client, 'Opponent not found');
  }
  
  // Forward the answer to the opponent
  const recipientClientId = addressToClientId.get(recipient);
  if (!recipientClientId) {
    return sendErrorToClient(client, 'Opponent not connected');
  }
  
  const recipientClient = clients.get(recipientClientId);
  if (!recipientClient || recipientClient.ws.readyState !== WebSocket.OPEN) {
    return sendErrorToClient(client, 'Opponent not connected');
  }
  
  // Send the answer
  recipientClient.ws.send(JSON.stringify({
    type: 'rtcAnswer',
    gameId,
    answer,
    from: client.address
  }));
}

async function handleRTCIceCandidate(message: WebSocketMessage, client: Client, storage: IStorage) {
  if (!client.address) {
    return sendErrorToClient(client, 'You must authenticate first');
  }

  const { gameId, candidate } = message;
  
  if (!gameId || !candidate) {
    return sendErrorToClient(client, 'Game ID and ICE candidate are required');
  }
  
  // Get the game
  const game = await storage.getGameById(gameId);
  
  if (!game) {
    return sendErrorToClient(client, 'Game not found');
  }
  
  // Make sure player is part of this game
  if (game.playerWhite !== client.address && game.playerBlack !== client.address) {
    return sendErrorToClient(client, 'You are not part of this game');
  }
  
  // Determine the recipient (opponent)
  const recipient = game.playerWhite === client.address ? game.playerBlack : game.playerWhite;
  
  if (!recipient) {
    return sendErrorToClient(client, 'Opponent not found');
  }
  
  // Forward the ICE candidate to the opponent
  const recipientClientId = addressToClientId.get(recipient);
  if (!recipientClientId) {
    return sendErrorToClient(client, 'Opponent not connected');
  }
  
  const recipientClient = clients.get(recipientClientId);
  if (!recipientClient || recipientClient.ws.readyState !== WebSocket.OPEN) {
    return sendErrorToClient(client, 'Opponent not connected');
  }
  
  // Send the ICE candidate
  recipientClient.ws.send(JSON.stringify({
    type: 'rtcIceCandidate',
    gameId,
    candidate,
    from: client.address
  }));
}

function sendErrorToClient(client: Client, message: string) {
  if (client.ws.readyState === WebSocket.OPEN) {
    client.ws.send(JSON.stringify({
      type: 'error',
      message
    }));
  }
}
