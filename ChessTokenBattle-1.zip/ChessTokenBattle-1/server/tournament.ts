import { IStorage } from "./storage";
import { WebSocket } from "ws";

type Client = {
  id: string;
  ws: WebSocket;
  address: string | null;
};

type Puzzle = {
  id: string;
  fen: string;
  moves: string[];
  rating: number;
  themes: string[];
  solution: string[];
};

type Tournament = {
  id: string;
  name: string;
  status: "waiting" | "active" | "completed";
  puzzleCount: number;
  currentPuzzleIndex: number;
  puzzles: Puzzle[];
  startTime?: number;
  endTime?: number;
  timeLimit: number; // в секундах
  entryFee: number;
  participants: TournamentParticipant[];
  winner?: string;
};

type TournamentParticipant = {
  address: string;
  score: number;
  currentPuzzleIndex: number;
  solveTime: number;
  isActive: boolean;
};

// Хранилище турниров
const tournaments = new Map<string, Tournament>();
const puzzles = new Map<string, Puzzle>();

// Инициализация демонстрационных данных
function initDemoPuzzles() {
  // Простая задача: мат в 1 ход
  const puzzle1: Puzzle = {
    id: "puzzle1",
    fen: "r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5Q2/PPPP1PPP/RNB1K1NR w KQkq - 0 1",
    moves: ["f3f7"],
    rating: 800,
    themes: ["mate", "oneMove"],
    solution: ["f3f7"]
  };
  
  // Задача посложнее: найти форк
  const puzzle2: Puzzle = {
    id: "puzzle2",
    fen: "r1bqkb1r/pppp1ppp/2n2n2/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 0 1",
    moves: ["f3g5", "f8c5", "g5f7"],
    rating: 1200,
    themes: ["fork", "attack"],
    solution: ["f3g5"]
  };
  
  // Жертва для атаки
  const puzzle3: Puzzle = {
    id: "puzzle3",
    fen: "r1bqkbnr/ppp2ppp/2np4/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 0 1",
    moves: ["f3e5", "d6e5", "d2d4"],
    rating: 1400,
    themes: ["sacrifice", "attack"],
    solution: ["f3e5"]
  };
  
  // Мат в 2 хода
  const puzzle4: Puzzle = {
    id: "puzzle4",
    fen: "r1bqkbnr/ppp2ppp/2np4/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 0 1",
    moves: ["c4f7", "e8f7", "d1d7"],
    rating: 1600,
    themes: ["mate", "sacrifice"],
    solution: ["c4f7"]
  };
  
  // Сложная стратегическая задача
  const puzzle5: Puzzle = {
    id: "puzzle5",
    fen: "rnbqkbnr/pp3ppp/2p5/3pp3/2PP4/5N2/PP2PPPP/RNBQKB1R w KQkq - 0 1",
    moves: ["c4d5", "c6d5", "d4e5"],
    rating: 1800,
    themes: ["pawnStructure", "center"],
    solution: ["c4d5"]
  };
  
  puzzles.set("puzzle1", puzzle1);
  puzzles.set("puzzle2", puzzle2);
  puzzles.set("puzzle3", puzzle3);
  puzzles.set("puzzle4", puzzle4);
  puzzles.set("puzzle5", puzzle5);
  
  // Добавим турнир для демонстрации
  const demoTournament: Tournament = {
    id: "tour1",
    name: "Скоростные тактики",
    status: "waiting",
    puzzleCount: 5,
    currentPuzzleIndex: 0,
    puzzles: [puzzle1, puzzle2, puzzle3, puzzle4, puzzle5],
    timeLimit: 300, // 5 минут
    entryFee: 1,
    participants: []
  };
  
  tournaments.set("tour1", demoTournament);
}

// Обработчик WebSocket сообщений для турниров
export async function handleTournamentMessage(message: any, client: Client, storage: IStorage, clients: Map<string, Client>) {
  if (!client.address) {
    return sendErrorToClient(client, "Not authenticated");
  }
  
  switch (message.type) {
    case 'joinTournament':
      await handleJoinTournament(message, client, storage);
      break;
      
    case 'submitPuzzleSolution':
      await handleSubmitPuzzleSolution(message, client, storage, clients);
      break;
      
    case 'getTournamentsList':
      await handleGetTournamentsList(client);
      break;
      
    case 'getUserTournamentHistory':
      await handleGetUserTournamentHistory(client, storage);
      break;
      
    case 'startTournament':
      await handleStartTournament(message.tournamentId, clients);
      break;
      
    default:
      sendErrorToClient(client, `Unknown tournament message type: ${message.type}`);
  }
}

// Обработчик присоединения к турниру
async function handleJoinTournament(message: any, client: Client, storage: IStorage) {
  const { address } = message;
  
  // В реальном приложении здесь было бы больше проверок и логики
  if (!tournaments.has("tour1")) {
    initDemoPuzzles();
  }
  
  const tournament = tournaments.get("tour1");
  if (!tournament) {
    return sendErrorToClient(client, "Tournament not found");
  }
  
  // Проверка, что у пользователя достаточно токенов
  const user = await storage.getUserByWallet(address);
  if (!user || (user.igyBalance || 0) < tournament.entryFee) {
    return sendErrorToClient(client, "Insufficient balance to join tournament");
  }
  
  // Проверяем, не участвует ли уже пользователь
  if (tournament.participants.some(p => p.address === address)) {
    // Уже участвует, просто отправляем статус
    client.ws.send(JSON.stringify({
      type: 'tournamentUpdate',
      tournament
    }));
    
    // Если турнир активен, отправляем текущую задачу
    if (tournament.status === "active") {
      const currentPuzzle = tournament.puzzles[tournament.currentPuzzleIndex];
      client.ws.send(JSON.stringify({
        type: 'puzzleUpdate',
        puzzle: {
          id: currentPuzzle.id,
          fen: currentPuzzle.fen,
          rating: currentPuzzle.rating,
          themes: currentPuzzle.themes
        }
      }));
    }
    
    return;
  }
  
  // Добавляем пользователя в список участников
  tournament.participants.push({
    address,
    score: 0,
    currentPuzzleIndex: 0,
    solveTime: 0,
    isActive: true
  });
  
  // Списываем токены со счета пользователя
  await storage.updateUserBalance(address, (user.igyBalance || 0) - tournament.entryFee);
  
  // Отправляем обновление состояния турнира
  client.ws.send(JSON.stringify({
    type: 'tournamentUpdate',
    tournament
  }));
  
  // Если достаточно участников, начинаем турнир
  if (tournament.participants.length >= 2 && tournament.status === "waiting") {
    startTournament("tour1");
  }
}

// Обработчик отправки решения задачи
async function handleSubmitPuzzleSolution(message: any, client: Client, storage: IStorage, clients: Map<string, Client>) {
  const { address, puzzleId, move } = message;
  
  if (!tournaments.has("tour1")) {
    return sendErrorToClient(client, "Tournament not found");
  }
  
  const tournament = tournaments.get("tour1")!;
  
  // Проверяем, участвует ли пользователь в турнире
  const participantIndex = tournament.participants.findIndex(p => p.address === address);
  if (participantIndex === -1) {
    return sendErrorToClient(client, "You are not a participant in this tournament");
  }
  
  const participant = tournament.participants[participantIndex];
  
  // Проверяем, что турнир активен
  if (tournament.status !== "active") {
    return sendErrorToClient(client, "Tournament is not active");
  }
  
  // Проверяем, что пользователь решает текущую задачу
  if (participant.currentPuzzleIndex !== tournament.currentPuzzleIndex) {
    return sendErrorToClient(client, "You are not on the current puzzle");
  }
  
  // Получаем текущую задачу
  const currentPuzzle = tournament.puzzles[tournament.currentPuzzleIndex];
  
  // Проверяем правильность решения
  const isCorrect = currentPuzzle.solution.includes(move);
  
  // Обновляем счет и индекс текущей задачи для пользователя
  if (isCorrect) {
    // Баллы на основе времени решения и сложности задачи
    const basePoints = currentPuzzle.rating / 10;
    const timePoints = Math.max(0, 50 - participant.solveTime); // Меньше времени = больше очков
    const points = Math.round(basePoints + timePoints);
    
    participant.score += points;
    participant.currentPuzzleIndex++;
    
    // Проверяем, решил ли пользователь все задачи
    if (participant.currentPuzzleIndex >= tournament.puzzleCount) {
      participant.isActive = false;
      
      // Проверяем, закончился ли турнир
      const activeParticipants = tournament.participants.filter(p => p.isActive);
      if (activeParticipants.length === 0) {
        endTournament("tour1", clients, storage);
      }
    }
    
    // Отправляем результат пользователю
    client.ws.send(JSON.stringify({
      type: 'puzzleResult',
      correct: true,
      points,
      nextPuzzle: participant.currentPuzzleIndex < tournament.puzzleCount 
        ? {
            id: tournament.puzzles[participant.currentPuzzleIndex].id,
            fen: tournament.puzzles[participant.currentPuzzleIndex].fen,
            rating: tournament.puzzles[participant.currentPuzzleIndex].rating,
            themes: tournament.puzzles[participant.currentPuzzleIndex].themes
          }
        : null
    }));
  } else {
    // Неправильное решение - отнимаем очки
    participant.score = Math.max(0, participant.score - 20);
    
    // Отправляем результат пользователю
    client.ws.send(JSON.stringify({
      type: 'puzzleResult',
      correct: false,
      solution: currentPuzzle.solution.join(', ')
    }));
  }
  
  // Обновляем состояние турнира для всех участников
  broadcastTournamentUpdate("tour1", clients);
}

// Получить список турниров
async function handleGetTournamentsList(client: Client) {
  if (!tournaments.has("tour1")) {
    initDemoPuzzles();
  }
  
  const tournamentsList = Array.from(tournaments.values()).map(tournament => ({
    id: tournament.id,
    name: tournament.name,
    status: tournament.status,
    startTime: tournament.startTime,
    endTime: tournament.endTime,
    timeLimit: tournament.timeLimit,
    entryFee: tournament.entryFee,
    puzzleCount: tournament.puzzleCount,
    participantCount: tournament.participants.length,
    prizePool: tournament.participants.length * tournament.entryFee,
    winner: tournament.winner
  }));
  
  client.ws.send(JSON.stringify({
    type: 'tournamentsList',
    tournaments: tournamentsList
  }));
}

// Получить историю турниров пользователя
async function handleGetUserTournamentHistory(client: Client, storage: IStorage) {
  if (!client.address) {
    return sendErrorToClient(client, "Not authenticated");
  }
  
  // В реальном приложении здесь был бы запрос к базе данных
  // Для демонстрации отправляем пустой массив
  client.ws.send(JSON.stringify({
    type: 'userTournamentHistory',
    history: []
  }));
}

// Обработка начала турнира
async function handleStartTournament(tournamentId: string, clients: Map<string, Client>) {
  startTournament(tournamentId);
  broadcastTournamentUpdate(tournamentId, clients);
}

// Начать турнир
function startTournament(tournamentId: string) {
  const tournament = tournaments.get(tournamentId);
  if (!tournament) return;
  
  tournament.status = "active";
  tournament.startTime = Date.now();
  tournament.currentPuzzleIndex = 0;
  
  // Сброс счета участников перед началом
  tournament.participants.forEach(p => {
    p.score = 0;
    p.currentPuzzleIndex = 0;
    p.solveTime = 0;
    p.isActive = true;
  });
}

// Завершить турнир
async function endTournament(tournamentId: string, clients: Map<string, Client>, storage: IStorage) {
  const tournament = tournaments.get(tournamentId);
  if (!tournament) return;
  
  tournament.status = "completed";
  tournament.endTime = Date.now();
  
  // Определяем победителя (участника с наибольшим счетом)
  let winner: TournamentParticipant | null = null;
  let highestScore = -1;
  
  for (const participant of tournament.participants) {
    if (participant.score > highestScore) {
      highestScore = participant.score;
      winner = participant;
    }
  }
  
  if (winner) {
    tournament.winner = winner.address;
    
    // Призовой фонд - сумма взносов всех участников
    const prize = tournament.participants.length * tournament.entryFee;
    
    // Начисляем призовые победителю
    const user = await storage.getUserByWallet(winner.address);
    if (user) {
      await storage.updateUserBalance(winner.address, (user.igyBalance || 0) + prize);
    }
    
    // Отправляем уведомление о завершении турнира
    clients.forEach(client => {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify({
          type: 'tournamentEnd',
          tournamentId,
          winner: winner?.address,
          prize
        }));
      }
    });
  }
}

// Отправить обновление состояния турнира всем участникам
function broadcastTournamentUpdate(tournamentId: string, clients: Map<string, Client>) {
  const tournament = tournaments.get(tournamentId);
  if (!tournament) return;
  
  // Отправляем обновленное состояние турнира всем клиентам
  const tournamentData = {
    id: tournament.id,
    name: tournament.name,
    status: tournament.status,
    puzzleCount: tournament.puzzleCount,
    currentPuzzleIndex: tournament.currentPuzzleIndex,
    startTime: tournament.startTime,
    endTime: tournament.endTime,
    timeLimit: tournament.timeLimit,
    entryFee: tournament.entryFee,
    participants: tournament.participants,
    winner: tournament.winner
  };
  
  clients.forEach(client => {
    if (client.ws.readyState === WebSocket.OPEN) {
      // Отправляем общее состояние турнира
      client.ws.send(JSON.stringify({
        type: 'tournamentUpdate',
        tournament: tournamentData
      }));
      
      // Если турнир активен, отправляем текущую задачу
      if (tournament.status === "active") {
        const currentPuzzle = tournament.puzzles[tournament.currentPuzzleIndex];
        
        // Отправляем задачу без решения
        client.ws.send(JSON.stringify({
          type: 'puzzleUpdate',
          puzzle: {
            id: currentPuzzle.id,
            fen: currentPuzzle.fen,
            rating: currentPuzzle.rating,
            themes: currentPuzzle.themes
          }
        }));
      }
    }
  });
}

function sendErrorToClient(client: Client, message: string) {
  if (client.ws.readyState === WebSocket.OPEN) {
    client.ws.send(JSON.stringify({
      type: 'error',
      message
    }));
  }
}