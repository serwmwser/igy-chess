import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupWebSocketServer } from "./websocket";
import { Chess } from "chess.js";
import { v4 as uuidv4 } from "uuid";
import { ethers, JsonRpcProvider, Contract, formatUnits } from "ethers";

// IGY Token contract information
const IGY_TOKEN_ADDRESS = "0x6d278Ec8Bb6FC8d06c081e4688759546CC73eaB8";
const IGY_TOKEN_ABI = [
  "function balanceOf(address owner) view returns (uint256)",
  "function decimals() view returns (uint8)"
];

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Set up WebSocket server
  setupWebSocketServer(httpServer, storage);
  
  // API endpoint to get user profile
  app.get("/api/users/:address", async (req, res) => {
    try {
      const { address } = req.params;
      const user = await storage.getUserByWallet(address);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // API endpoint to get user stats
  app.get("/api/users/:address/stats", async (req, res) => {
    try {
      const { address } = req.params;
      const user = await storage.getUserByWallet(address);
      
      if (!user) {
        return res.json({ wins: 0, losses: 0, draws: 0 });
      }
      
      res.json({
        wins: user.wins,
        losses: user.losses,
        draws: user.draws
      });
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // API endpoint to get IGY token balance
  app.get("/api/users/:address/balance", async (req, res) => {
    try {
      const { address } = req.params;
      
      // Connect to Polygon network
      const provider = new JsonRpcProvider("https://polygon-rpc.com");
      
      // Create contract instance
      const tokenContract = new Contract(
        IGY_TOKEN_ADDRESS,
        IGY_TOKEN_ABI,
        provider
      );
      
      // Get token balance
      const balance = await tokenContract.balanceOf(address);
      const decimals = await tokenContract.decimals();
      
      // Format balance to human-readable format
      const formattedBalance = formatUnits(balance, decimals);
      
      res.json({ balance: formattedBalance });
    } catch (error) {
      console.error("Error fetching IGY balance:", error);
      res.status(500).json({ message: "Error fetching balance" });
    }
  });

  // API endpoint to get leaderboard
  app.get("/api/leaderboard", async (req, res) => {
    try {
      const leaderboard = await storage.getLeaderboard();
      res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // API endpoint to get game information
  app.get("/api/games/:gameId", async (req, res) => {
    try {
      const { gameId } = req.params;
      const game = await storage.getGameById(gameId);
      
      if (!game) {
        return res.status(404).json({ message: "Game not found" });
      }
      
      // Convert internal game representation to client-friendly format
      const gameInfo = {
        id: game.gameId,
        playerWhite: game.playerWhite,
        playerBlack: game.playerBlack,
        status: game.status,
        winner: game.winner,
        fen: game.fen,
        timeLimit: game.timeLimit,
        startTime: game.startTime,
        drawOfferedBy: game.drawOfferedBy,
        moveHistory: game.moveHistory || []
      };
      
      res.json(gameInfo);
    } catch (error) {
      console.error("Error fetching game:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // API endpoint to get active game for a user
  app.get("/api/users/:address/games/active", async (req, res) => {
    try {
      const { address } = req.params;
      const activeGame = await storage.getActiveGameForUser(address);
      
      if (!activeGame) {
        return res.json(null);
      }
      
      // Get chat messages for this game
      const chatMessages = await storage.getChatMessages(activeGame.gameId);
      
      // Format game data
      const gameData = {
        id: activeGame.gameId,
        playerWhite: activeGame.playerWhite,
        playerBlack: activeGame.playerBlack,
        status: activeGame.status,
        winner: activeGame.winner,
        fen: activeGame.fen,
        timeLimit: activeGame.timeLimit,
        startTime: activeGame.startTime,
        drawOfferedBy: activeGame.drawOfferedBy,
        moveHistory: activeGame.moveHistory || [],
        chatMessages: chatMessages,
        boardTheme: activeGame.boardTheme,
        pieceTheme: activeGame.pieceTheme,
        videoEnabled: activeGame.videoEnabled
      };
      
      res.json(gameData);
    } catch (error) {
      console.error("Error fetching active game:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // API endpoint to get daily tasks
  app.get("/api/daily-tasks", async (req, res) => {
    try {
      const tasks = await storage.getDailyTasks();
      res.json(tasks.filter(task => task.active));
    } catch (error) {
      console.error("Error fetching daily tasks:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // API endpoint to get user's daily task progress
  app.get("/api/users/:userId/daily-tasks/progress", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Get all tasks
      const tasks = await storage.getDailyTasks();
      
      // Get user's progress for today
      const progress = await storage.getUserTaskProgress(userId);
      
      // Combine task info with progress
      const result = tasks
        .filter(task => task.active)
        .map(task => {
          const taskProgress = progress.find(p => p.taskId === task.id) || {
            userId,
            taskId: task.id,
            currentCount: 0,
            completed: false,
            completedAt: null,
            lastUpdated: null,
            date: new Date()
          };
          
          return {
            ...task,
            progress: {
              currentCount: taskProgress.currentCount,
              completed: taskProgress.completed,
              completedAt: taskProgress.completedAt
            }
          };
        });
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching task progress:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // API endpoint to update task progress
  app.post("/api/users/:userId/daily-tasks/:taskId/progress", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const taskId = parseInt(req.params.taskId);
      
      if (isNaN(userId) || isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid user ID or task ID" });
      }
      
      const task = await storage.getDailyTask(taskId);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      // Update progress
      const updatedProgress = await storage.updateTaskProgress(userId, taskId, 1);
      
      res.json({
        success: true,
        progress: updatedProgress,
        task: task
      });
    } catch (error) {
      console.error("Error updating task progress:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // API endpoint to complete a task directly
  app.post("/api/users/:userId/daily-tasks/:taskId/complete", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const taskId = parseInt(req.params.taskId);
      
      if (isNaN(userId) || isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid user ID or task ID" });
      }
      
      const task = await storage.getDailyTask(taskId);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      // Complete the task
      const updatedProgress = await storage.completeUserTask(userId, taskId);
      
      res.json({
        success: true,
        progress: updatedProgress,
        task: task
      });
    } catch (error) {
      console.error("Error completing task:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // API endpoint to get board themes
  app.get("/api/themes/board", async (req, res) => {
    try {
      const themes = await storage.getBoardThemes();
      res.json(themes);
    } catch (error) {
      console.error("Error fetching board themes:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // API endpoint to get piece themes
  app.get("/api/themes/piece", async (req, res) => {
    try {
      const themes = await storage.getPieceThemes();
      res.json(themes);
    } catch (error) {
      console.error("Error fetching piece themes:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // API endpoint to purchase a theme
  app.post("/api/users/:address/themes/purchase", async (req, res) => {
    try {
      const { address } = req.params;
      const { themeType, themeId } = req.body;
      
      if (!themeType || !themeId) {
        return res.status(400).json({ message: "Missing theme type or ID" });
      }
      
      if (themeType !== 'board' && themeType !== 'piece') {
        return res.status(400).json({ message: "Invalid theme type" });
      }
      
      // Purchase the theme
      const success = await storage.purchaseTheme(address, themeType, themeId);
      
      if (!success) {
        return res.status(400).json({ message: "Failed to purchase theme" });
      }
      
      // Get updated user
      const user = await storage.getUserByWallet(address);
      
      res.json({
        success: true,
        message: "Theme purchased successfully",
        preferences: user?.preferences
      });
    } catch (error) {
      console.error("Error purchasing theme:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // API endpoint to update user preferences
  app.patch("/api/users/:address/preferences", async (req, res) => {
    try {
      const { address } = req.params;
      const preferences = req.body;
      
      // Basic validation
      if (!preferences || Object.keys(preferences).length === 0) {
        return res.status(400).json({ message: "No preferences provided" });
      }
      
      // Update preferences
      const user = await storage.updateUserPreferences(address, preferences);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        success: true,
        preferences: user.preferences
      });
    } catch (error) {
      console.error("Error updating preferences:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // API endpoint for purchasing IGY tokens
  app.post("/api/tokens/purchase", async (req, res) => {
    try {
      const { walletAddress, amount } = req.body;
      
      if (!walletAddress || !amount || amount <= 0) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid request parameters" 
        });
      }
      
      // Get user information
      const user = await storage.getUserByWallet(walletAddress);
      
      if (!user) {
        return res.status(404).json({ 
          success: false, 
          message: "User not found" 
        });
      }
      
      // In a real application, there would be a POL transaction check through blockchain
      // and only after confirmation - IGY refill
      
      // Constants for tokens and admin wallet
      const ADMIN_WALLET = "0xc2e5650f84eeb9e4011afbb398108ea302cb17a6";
      
      // Simulation of transaction verification and IGY replenishment
      // In a real application, there would be a call to the IGY contract for transferFrom on behalf of the admin
      const success = await storage.addTokens(
        walletAddress, 
        Number(amount), 
        "purchase_from_pol"
      );
      
      if (!success) {
        return res.status(400).json({
          success: false,
          message: "Failed to add tokens to user balance"
        });
      }
      
      // Get updated user
      const updatedUser = await storage.getUserByWallet(walletAddress);
      
      return res.status(200).json({
        success: true,
        message: "Tokens purchased successfully",
        newBalance: updatedUser?.igyBalance || 0
      });
    } catch (error) {
      console.error("Error purchasing tokens:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to process token purchase"
      });
    }
  });
  
  // API endpoint to get transaction history
  app.get("/api/users/:address/transactions", async (req, res) => {
    try {
      const { address } = req.params;
      const history = await storage.getTransactionHistory(address);
      
      res.json(history);
    } catch (error) {
      console.error("Error fetching transaction history:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // API endpoint to transfer tokens to another user
  app.post("/api/tokens/transfer", async (req, res) => {
    try {
      const { fromAddress, toAddress, amount, reason } = req.body;
      
      if (!fromAddress || !toAddress || !amount || amount <= 0) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid request parameters" 
        });
      }
      
      const success = await storage.transferTokens(
        fromAddress,
        toAddress,
        Number(amount),
        reason || "user_transfer"
      );
      
      if (!success) {
        return res.status(400).json({
          success: false,
          message: "Transfer failed. Check that the sender has sufficient balance."
        });
      }
      
      // Get updated user balances
      const sender = await storage.getUserByWallet(fromAddress);
      const recipient = await storage.getUserByWallet(toAddress);
      
      return res.status(200).json({
        success: true,
        message: "Tokens transferred successfully",
        senderBalance: sender?.igyBalance || 0,
        recipientBalance: recipient?.igyBalance || 0
      });
    } catch (error) {
      console.error("Error transferring tokens:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to process token transfer"
      });
    }
  });
  
  // API endpoint to withdraw tokens to wallet
  app.post("/api/tokens/withdraw", async (req, res) => {
    try {
      const { walletAddress, amount } = req.body;
      
      if (!walletAddress || !amount || amount <= 0) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid request parameters" 
        });
      }
      
      // Get user information
      const user = await storage.getUserByWallet(walletAddress);
      
      if (!user) {
        return res.status(404).json({ 
          success: false, 
          message: "User not found" 
        });
      }
      
      // In a real application, there would be an IGY token transfer to the user's wallet
      // For now, just deduct from the in-app balance
      const success = await storage.chargeTokens(
        walletAddress,
        Number(amount),
        "withdraw_to_wallet"
      );
      
      if (!success) {
        return res.status(400).json({
          success: false,
          message: "Withdrawal failed. Check that you have sufficient balance."
        });
      }
      
      // Get updated user
      const updatedUser = await storage.getUserByWallet(walletAddress);
      
      return res.status(200).json({
        success: true,
        message: "Tokens withdrawn successfully",
        newBalance: updatedUser?.igyBalance || 0
      });
    } catch (error) {
      console.error("Error withdrawing tokens:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to process token withdrawal"
      });
    }
  });
  
  // API endpoint to create messenger profile
  app.post("/api/messenger/profile", async (req, res) => {
    try {
      const { userId, displayName, avatarUrl, bio, interests, location, contactInfo, privacySettings } = req.body;
      
      if (!userId || !displayName) {
        return res.status(400).json({ 
          success: false, 
          message: "User ID and display name are required" 
        });
      }
      
      // Check if user has enough tokens
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }
      
      // Creating a messenger profile costs 1 IGY token
      const MESSENGER_REGISTRATION_COST = 1;
      
      const canCharge = await storage.chargeTokens(
        user.walletAddress,
        MESSENGER_REGISTRATION_COST,
        "messenger_registration"
      );
      
      if (!canCharge) {
        return res.status(400).json({
          success: false,
          message: "Insufficient balance. You need 1 IGY token to create a messenger profile."
        });
      }
      
      // Create the profile
      const profile = await storage.createMessengerProfile({
        userId,
        displayName,
        bio: bio || null,
        avatarUrl: avatarUrl || null,
        interests: interests || [],
        location: location || null,
        contactInfo: contactInfo || null,
        privacySettings: privacySettings || {
          showOnlineStatus: true,
          allowDirectMessages: true,
          allowFriendRequests: true
        }
      });
      
      return res.status(201).json({
        success: true,
        message: "Messenger profile created successfully",
        profile
      });
    } catch (error) {
      console.error("Error creating messenger profile:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to create messenger profile"
      });
    }
  });
  
  // API endpoint to get messenger profile
  app.get("/api/messenger/profile/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid user ID"
        });
      }
      
      const profile = await storage.getMessengerProfile(userId);
      
      if (!profile) {
        return res.status(404).json({
          success: false,
          message: "Profile not found"
        });
      }
      
      return res.json(profile);
    } catch (error) {
      console.error("Error getting messenger profile:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to get messenger profile"
      });
    }
  });
  
  // API endpoint to update messenger profile
  app.patch("/api/messenger/profile/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const updates = req.body;
      
      if (isNaN(userId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid user ID"
        });
      }
      
      const existingProfile = await storage.getMessengerProfile(userId);
      
      if (!existingProfile) {
        return res.status(404).json({
          success: false,
          message: "Profile not found"
        });
      }
      
      const updatedProfile = await storage.updateMessengerProfile(userId, updates);
      
      return res.json({
        success: true,
        message: "Profile updated successfully",
        profile: updatedProfile
      });
    } catch (error) {
      console.error("Error updating messenger profile:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to update messenger profile"
      });
    }
  });
  
  // API endpoint to create a conversation
  app.post("/api/messenger/conversations", async (req, res) => {
    try {
      const { name, type, createdBy, participants, isEncrypted, metadata } = req.body;
      
      if (!createdBy || !participants || !Array.isArray(participants) || participants.length === 0) {
        return res.status(400).json({
          success: false,
          message: "Missing required fields"
        });
      }
      
      // Create the conversation
      const conversation = await storage.createConversation({
        name: name || null,
        type: type || "private",
        createdBy,
        isEncrypted: isEncrypted || false,
        metadata: metadata || {}
      });
      
      // Add participants
      const participantPromises = participants.map(userId => {
        return storage.addParticipant({
          conversationId: conversation.conversationId,
          userId,
          role: userId === createdBy ? "admin" : "member"
        });
      });
      
      await Promise.all(participantPromises);
      
      // Get the full conversation with participants
      const conversationParticipants = await storage.getConversationParticipants(conversation.conversationId);
      
      return res.status(201).json({
        success: true,
        message: "Conversation created successfully",
        conversation: {
          ...conversation,
          participants: conversationParticipants
        }
      });
    } catch (error) {
      console.error("Error creating conversation:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to create conversation"
      });
    }
  });
  
  // API endpoint to send a message
  app.post("/api/messenger/conversations/:conversationId/messages", async (req, res) => {
    try {
      const { conversationId } = req.params;
      const { senderId, content, messageType, replyToId, metadata } = req.body;
      
      if (!senderId || !content) {
        return res.status(400).json({
          success: false,
          message: "Sender ID and content are required"
        });
      }
      
      // Check if conversation exists
      const conversation = await storage.getConversation(conversationId);
      
      if (!conversation) {
        return res.status(404).json({
          success: false,
          message: "Conversation not found"
        });
      }
      
      // Check if sender is a participant in the conversation
      const participants = await storage.getConversationParticipants(conversationId);
      const isSenderParticipant = participants.some(p => p.userId === senderId);
      
      if (!isSenderParticipant) {
        return res.status(403).json({
          success: false,
          message: "Sender is not a participant in this conversation"
        });
      }
      
      // Create the message
      const message = await storage.sendMessage({
        conversationId,
        senderId,
        messageType: messageType || "text",
        content,
        replyToId: replyToId || null,
        metadata: metadata || {}
      });
      
      return res.status(201).json({
        success: true,
        message: "Message sent successfully",
        data: message
      });
    } catch (error) {
      console.error("Error sending message:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to send message"
      });
    }
  });
  
  // API endpoint to get conversation messages
  app.get("/api/messenger/conversations/:conversationId/messages", async (req, res) => {
    try {
      const { conversationId } = req.params;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : undefined;
      
      // Check if conversation exists
      const conversation = await storage.getConversation(conversationId);
      
      if (!conversation) {
        return res.status(404).json({
          success: false,
          message: "Conversation not found"
        });
      }
      
      const messages = await storage.getConversationMessages(conversationId, limit, offset);
      
      return res.json(messages);
    } catch (error) {
      console.error("Error getting conversation messages:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to get conversation messages"
      });
    }
  });
  
  // API endpoint to get user conversations
  app.get("/api/messenger/users/:userId/conversations", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid user ID"
        });
      }
      
      const conversations = await storage.getUserConversations(userId);
      
      // For each conversation, get the participants and the last message
      const conversationsWithDetails = await Promise.all(
        conversations.map(async (conversation) => {
          const participants = await storage.getConversationParticipants(conversation.conversationId);
          const messages = await storage.getConversationMessages(conversation.conversationId, 1);
          
          return {
            ...conversation,
            participants,
            lastMessage: messages.length > 0 ? messages[0] : null
          };
        })
      );
      
      return res.json(conversationsWithDetails);
    } catch (error) {
      console.error("Error getting user conversations:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to get user conversations"
      });
    }
  });
  
  // API endpoint to send a friend request
  app.post("/api/messenger/friend-requests", async (req, res) => {
    try {
      const { requesterId, addresseeId } = req.body;
      
      if (!requesterId || !addresseeId) {
        return res.status(400).json({
          success: false,
          message: "Requester ID and addressee ID are required"
        });
      }
      
      // Check if the users exist
      const requester = await storage.getUser(requesterId);
      const addressee = await storage.getUser(addresseeId);
      
      if (!requester || !addressee) {
        return res.status(404).json({
          success: false,
          message: "One or both users not found"
        });
      }
      
      // Create the friend request
      const friendship = await storage.sendFriendRequest({
        requesterId,
        addresseeId,
        status: "pending"
      });
      
      return res.status(201).json({
        success: true,
        message: "Friend request sent successfully",
        friendship
      });
    } catch (error) {
      console.error("Error sending friend request:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to send friend request"
      });
    }
  });
  
  // API endpoint to respond to a friend request
  app.patch("/api/messenger/friend-requests/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (isNaN(id)) {
        return res.status(400).json({
          success: false,
          message: "Invalid friendship ID"
        });
      }
      
      if (!status || !["accepted", "rejected", "blocked"].includes(status)) {
        return res.status(400).json({
          success: false,
          message: "Invalid status. Must be 'accepted', 'rejected', or 'blocked'."
        });
      }
      
      const friendship = await storage.respondToFriendRequest(id, status as 'accepted' | 'rejected' | 'blocked');
      
      if (!friendship) {
        return res.status(404).json({
          success: false,
          message: "Friendship not found"
        });
      }
      
      // If accepted, create a conversation between the two users
      if (status === "accepted") {
        // Check if a private conversation already exists
        const requesterConversations = await storage.getUserConversations(friendship.requesterId);
        const existingConversation = requesterConversations.find(c => {
          return c.type === "private" && c.metadata && 
                 c.metadata.participants && 
                 c.metadata.participants.includes(friendship.addresseeId);
        });
        
        if (!existingConversation) {
          // Create a new private conversation
          const conversation = await storage.createConversation({
            name: null,
            type: "private",
            createdBy: friendship.requesterId,
            isEncrypted: false,
            metadata: {
              participants: [friendship.requesterId, friendship.addresseeId]
            }
          });
          
          // Add participants
          await storage.addParticipant({
            conversationId: conversation.conversationId,
            userId: friendship.requesterId,
            role: "member"
          });
          
          await storage.addParticipant({
            conversationId: conversation.conversationId,
            userId: friendship.addresseeId,
            role: "member"
          });
        }
      }
      
      return res.json({
        success: true,
        message: `Friend request ${status}`,
        friendship
      });
    } catch (error) {
      console.error("Error responding to friend request:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to respond to friend request"
      });
    }
  });
  
  // API endpoint to get user friends
  app.get("/api/messenger/users/:userId/friends", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid user ID"
        });
      }
      
      const friends = await storage.getUserFriends(userId);
      
      return res.json(friends);
    } catch (error) {
      console.error("Error getting user friends:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to get user friends"
      });
    }
  });
  
  // API endpoint to upload a file for a message
  app.post("/api/messenger/files", async (req, res) => {
    try {
      const { messageId, userId, fileName, fileSize, mimeType, filePath, thumbnailPath, isPublic, expiresAt } = req.body;
      
      if (!userId || !fileName || !fileSize || !mimeType || !filePath) {
        return res.status(400).json({
          success: false,
          message: "Missing required fields"
        });
      }
      
      // In a real application, you would handle file upload here
      // For now, we just store the file metadata
      
      const fileAttachment = await storage.uploadFile({
        messageId: messageId || null,
        userId,
        fileName,
        fileSize,
        mimeType,
        filePath,
        thumbnailPath: thumbnailPath || null,
        isPublic: isPublic || false,
        expiresAt: expiresAt ? new Date(expiresAt) : null
      });
      
      return res.status(201).json({
        success: true,
        message: "File uploaded successfully",
        file: fileAttachment
      });
    } catch (error) {
      console.error("Error uploading file:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to upload file"
      });
    }
  });
  
  // API endpoint to get a file
  app.get("/api/messenger/files/:fileId", async (req, res) => {
    try {
      const fileId = parseInt(req.params.fileId);
      
      if (isNaN(fileId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid file ID"
        });
      }
      
      const file = await storage.getFile(fileId);
      
      if (!file) {
        return res.status(404).json({
          success: false,
          message: "File not found"
        });
      }
      
      // In a real application, you would serve the file here
      // For now, we just return the file metadata
      
      return res.json(file);
    } catch (error) {
      console.error("Error getting file:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to get file"
      });
    }
  });
  
  // API endpoint to get files for a message
  app.get("/api/messenger/messages/:messageId/files", async (req, res) => {
    try {
      const messageId = parseInt(req.params.messageId);
      
      if (isNaN(messageId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid message ID"
        });
      }
      
      const files = await storage.getMessageFiles(messageId);
      
      return res.json(files);
    } catch (error) {
      console.error("Error getting message files:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to get message files"
      });
    }
  });

  // API endpoint to get user details including messenger access status
  app.get("/api/user/details", async (req, res) => {
    try {
      const { walletAddress } = req.query;
      
      if (!walletAddress) {
        return res.status(400).json({
          success: false,
          message: "Wallet address is required"
        });
      }
      
      const user = await storage.getUserByWallet(walletAddress as string);
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }
      
      return res.json({
        id: user.id,
        walletAddress: user.walletAddress,
        username: user.username,
        hasMessengerAccess: user.hasMessengerAccess,
        paidInvites: user.paidInvites,
        invitedBy: user.invitedBy,
        igyBalance: user.igyBalance
      });
    } catch (error) {
      console.error("Error getting user details:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to get user details"
      });
    }
  });

  // API endpoint to pay for messenger access
  app.post("/api/messenger/pay-for-access", async (req, res) => {
    try {
      const { walletAddress } = req.body;
      
      if (!walletAddress) {
        return res.status(400).json({
          success: false,
          message: "Wallet address is required"
        });
      }
      
      const user = await storage.getUserByWallet(walletAddress);
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }
      
      // Check if user already has access
      if (user.hasMessengerAccess) {
        return res.status(400).json({
          success: false,
          message: "User already has messenger access"
        });
      }
      
      // Check if user has enough tokens
      if (user.igyBalance < 1) {
        return res.status(400).json({
          success: false,
          message: "Insufficient tokens. 1 IGY token is required for messenger access."
        });
      }
      
      // Charge 1 token for messenger access
      const charged = await storage.chargeTokens(
        walletAddress,
        1,
        "messenger_access_fee"
      );
      
      if (!charged) {
        return res.status(400).json({
          success: false,
          message: "Failed to charge token"
        });
      }
      
      // Update user to grant messenger access
      const updatedUser = await storage.updateUserPreferences(walletAddress, {
        hasMessengerAccess: true
      });
      
      if (!updatedUser) {
        return res.status(500).json({
          success: false,
          message: "Failed to update user preferences"
        });
      }
      
      return res.status(200).json({
        success: true,
        message: "Messenger access granted successfully",
        hasMessengerAccess: updatedUser.hasMessengerAccess,
        igyBalance: updatedUser.igyBalance
      });
    } catch (error) {
      console.error("Error paying for messenger access:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to process payment for messenger access"
      });
    }
  });

  // API endpoint to create a messenger profile
  app.post("/api/messenger/create-profile", async (req, res) => {
    try {
      const { userId, displayName, bio, avatarUrl, location, interests, contactInfo } = req.body;
      
      if (!userId || !displayName) {
        return res.status(400).json({
          success: false,
          message: "User ID and display name are required"
        });
      }
      
      // Create messenger profile
      const profile = await storage.createMessengerProfile({
        userId: userId,
        displayName: displayName,
        bio: bio || "",
        avatarUrl: avatarUrl || "",
        location: location || "",
        interests: interests || [],
        contactInfo: contactInfo || {},
        privacySettings: {
          allowFriendRequests: true,
          showOnlineStatus: true,
          allowDirectMessages: true
        }
      });
      
      return res.status(201).json({
        success: true,
        message: "Messenger profile created successfully",
        profile: profile
      });
    } catch (error) {
      console.error("Error creating messenger profile:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to create messenger profile"
      });
    }
  });

  // API эндпоинт для добавления токенов пользователю (для игры 2048 и других мини-игр)
  app.post("/api/tokens/add", async (req, res) => {
    try {
      const { walletAddress, amount, reason } = req.body;
      
      if (!walletAddress || !amount || amount <= 0) {
        return res.status(400).json({ 
          success: false, 
          message: "Invalid request parameters" 
        });
      }
      
      // Добавляем токены пользователю
      const success = await storage.addTokens(
        walletAddress, 
        Number(amount), 
        reason || "game_reward"
      );
      
      if (!success) {
        return res.status(400).json({
          success: false,
          message: "Failed to add tokens to user balance"
        });
      }
      
      // Получаем обновленную информацию о пользователе
      const updatedUser = await storage.getUserByWallet(walletAddress);
      
      return res.status(200).json({
        success: true,
        message: "Tokens added successfully",
        newBalance: updatedUser?.igyBalance || 0
      });
    } catch (error) {
      console.error("Error adding tokens:", error);
      return res.status(500).json({
        success: false,
        message: "Failed to add tokens"
      });
    }
  });

  return httpServer;
}
