#!/bin/bash

# Проверка наличия Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js не установлен. Пожалуйста, установите Node.js версии 20 или выше."
    exit 1
fi

# Проверка версии Node.js
NODE_VERSION=$(node -v | cut -d "v" -f 2 | cut -d "." -f 1)
if [ "$NODE_VERSION" -lt 20 ]; then
    echo "❌ Требуется Node.js версии 20 или выше. Текущая версия: $(node -v)"
    exit 1
fi

# Проверка наличия npm
if ! command -v npm &> /dev/null; then
    echo "❌ npm не установлен. Пожалуйста, установите npm."
    exit 1
fi

# Проверка и установка зависимостей
if [ ! -d "node_modules" ]; then
    echo "📦 Установка зависимостей..."
    npm install --production
    if [ $? -ne 0 ]; then
        echo "❌ Ошибка при установке зависимостей."
        exit 1
    fi
    echo "✅ Зависимости успешно установлены."
else
    echo "✅ Зависимости уже установлены."
fi

# Запуск приложения
echo "🚀 Запуск IGY Chess..."
PORT=${PORT:-5000}
echo "📡 Приложение будет доступно на порту $PORT"
NODE_ENV=production node index.js