#!/bin/bash

# Start the production server
node dist/index.js