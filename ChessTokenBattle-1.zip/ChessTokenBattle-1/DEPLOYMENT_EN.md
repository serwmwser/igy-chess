# IGY Chess Deployment Guide

## Build Archive Contents

The `igy-chess-build.tar.gz` archive contains all the necessary files to run the application in a production environment:

- `dist/index.js` - compiled server code
- `dist/public/` - compiled client files (HTML, CSS, JavaScript, images)
- `start.sh` - script to start the application

## Deployment Steps

1. Extract the archive:
   ```
   tar -xzvf igy-chess-build.tar.gz
   ```

2. Install the necessary dependencies:
   ```
   npm install
   ```

3. Configure environment variables (if needed):
   - Create a `.env` file in the project root directory with the required values
   - Example `.env` file contents:
     ```
     PORT=5000
     DATABASE_URL=postgresql://user:password@localhost:5432/igy_chess
     ```

4. Start the application:
   ```
   ./start.sh
   ```
   or
   ```
   node dist/index.js
   ```

5. The application will be available at: http://localhost:5000 (or at the port specified in the environment variables)

## System Requirements

- Node.js 18.x or higher
- NPM 9.x or higher
- Minimum 1 GB of RAM
- 500 MB of free disk space

## Verification

After starting, you can verify the application is working:

- Frontend: open http://localhost:5000 in your browser
- API: check the availability of http://localhost:5000/api/health

## IGY Token Contract

The IGY token contract is deployed on the Polygon network at:
`0x6d278Ec8Bb6FC8d06c081e4688759546CC73eaB8`

## Technical Support

If you encounter any problems with deploying or using the application, please contact technical support.